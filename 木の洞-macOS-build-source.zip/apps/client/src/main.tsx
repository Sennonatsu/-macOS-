import { Component, type ErrorInfo, type ReactNode } from "react";
import { createRoot, hydrateRoot } from 'react-dom/client'
import App from './App.tsx'
import './index.css'
import { syncAuthTokenFromUrl } from "@/lib/api";

// Prerender (scripts/prerender.mjs) bakes the home page into #root at build time
// so crawlers see real content. When that markup is present we hydrate it back
// into the normal CSR app; otherwise we do a clean client render.
const rootEl = document.getElementById("root")!;
document.getElementById("desktop-startup-fallback")?.remove();

class StartupErrorBoundary extends Component<
  { children: ReactNode },
  { error: Error | null }
> {
  state = { error: null as Error | null };

  static getDerivedStateFromError(error: Error) {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    console.error("木の洞启动失败", error, info);
  }

  render() {
    if (!this.state.error) return this.props.children;
    return (
      <main style={{
        minHeight: "100vh",
        display: "grid",
        placeItems: "center",
        padding: 32,
        background: "#f7f7f3",
        color: "#252521",
        fontFamily: "-apple-system, BlinkMacSystemFont, sans-serif",
      }}>
        <section style={{ maxWidth: 560 }}>
          <h1 style={{ fontSize: 24, marginBottom: 12 }}>木の洞启动时遇到问题</h1>
          <p style={{ lineHeight: 1.7 }}>
            请截取此页面发给开发者。你的词库和学习记录不会因此被删除。
          </p>
          <pre style={{
            whiteSpace: "pre-wrap",
            wordBreak: "break-word",
            padding: 16,
            borderRadius: 12,
            background: "#ecece6",
          }}>
            {this.state.error.message}
          </pre>
        </section>
      </main>
    );
  }
}

const app = (
  <StartupErrorBoundary>
    <App />
  </StartupErrorBoundary>
);

async function bootstrap() {
  await syncAuthTokenFromUrl();
  if (rootEl.hasChildNodes()) {
    hydrateRoot(rootEl, app);
  } else {
    createRoot(rootEl).render(app);
  }
}

void bootstrap().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error("木の洞初始化失败", error);
  rootEl.innerHTML = `
    <main style="min-height:100vh;display:grid;place-items:center;padding:32px;background:#f7f7f3;color:#252521;font-family:-apple-system,BlinkMacSystemFont,sans-serif">
      <section style="max-width:560px">
        <h1 style="font-size:24px;margin-bottom:12px">木の洞无法完成初始化</h1>
        <p style="line-height:1.7">请截取此页面发给开发者。你的本地数据不会被删除。</p>
        <pre style="white-space:pre-wrap;word-break:break-word;padding:16px;border-radius:12px;background:#ecece6">${escapeHtml(message)}</pre>
      </section>
    </main>
  `;
});

function escapeHtml(value: string) {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
