import type { StudyLanguage, WordCard } from "@/types";
import { createId } from "./storage";

export type DuplicateMode = "skip" | "overwrite" | "copy";

const headers = ["word", "kana", "meaning", "partOfSpeech", "example", "exampleTranslation", "tags", "language", "note", "favorite"];

function escape(value: string) {
  return `"${value.replace(/"/g, '""')}"`;
}

export function exportWordsCsv(words: WordCard[]) {
  const rows = [
    ["word", "kana", "meaning", "partOfSpeech", "example", "exampleTranslation", "tags", "language", "note", "favorite", "status", "repetitions", "dueDate"],
    ...words.map((word) => [
      word.word,
      word.kana,
      word.meaning,
      word.partOfSpeech,
      word.example,
      word.exampleTranslation,
      word.tags.join("|"),
      word.language ?? "ja",
      word.note ?? "",
      word.favorite ? "true" : "false",
      word.status,
      String(word.repetitions),
      word.dueDate ?? "",
    ]),
  ];
  return "\ufeff" + rows.map((row) => row.map(escape).join(",")).join("\n");
}

function parseLine(line: string) {
  const values: string[] = [];
  let current = "";
  let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"') {
      if (quoted && line[i + 1] === '"') {
        current += '"';
        i += 1;
      } else quoted = !quoted;
    } else if (char === "," && !quoted) {
      values.push(current.trim());
      current = "";
    } else current += char;
  }
  values.push(current.trim());
  return values;
}

export function parseWordsCsv(text: string, deckId: string, defaultLanguage: StudyLanguage = "ja"): Omit<WordCard, "id" | "createdAt" | "reviewHistory" | "status" | "difficulty" | "stability" | "repetitions" | "interval" | "dueDate" | "lastReview">[] {
  const lines = text.replace(/^\ufeff/, "").split(/\r?\n/).filter(Boolean);
  if (lines.length < 2) return [];
  const first = parseLine(lines[0]).map((value) => value.trim());
  const hasHeader = first.some((value) => headers.includes(value));
  const dataLines = hasHeader ? lines.slice(1) : lines;
  const indexOf = (name: string) => {
    const index = first.indexOf(name);
    return hasHeader ? index : headers.indexOf(name);
  };
  const valueOf = (row: string[], name: string) => {
    const index = indexOf(name);
    return index >= 0 ? row[index] ?? "" : "";
  };
  return dataLines.map((line) => {
    const row = parseLine(line);
    const language = valueOf(row, "language").toLowerCase() === "en" ? "en" : defaultLanguage;
    return {
      word: valueOf(row, "word"),
      kana: valueOf(row, "kana"),
      meaning: valueOf(row, "meaning"),
      partOfSpeech: valueOf(row, "partOfSpeech"),
      example: valueOf(row, "example"),
      exampleTranslation: valueOf(row, "exampleTranslation"),
      tags: valueOf(row, "tags").split(/[|，、]/).map((tag) => tag.trim()).filter(Boolean),
      deckIds: [deckId],
      language,
      note: valueOf(row, "note"),
      favorite: valueOf(row, "favorite").toLowerCase() === "true",
    };
  }).filter((word) => word.word && word.meaning);
}

export function materializeImportedWord(input: ReturnType<typeof parseWordsCsv>[number], existing?: WordCard, mode: DuplicateMode = "copy"): WordCard {
  return {
    id: mode === "overwrite" && existing ? existing.id : createId(),
    ...input,
    status: existing && mode === "overwrite" ? existing.status : "NEW",
    difficulty: existing && mode === "overwrite" ? existing.difficulty : 2.5,
    stability: existing && mode === "overwrite" ? existing.stability : 0,
    repetitions: existing && mode === "overwrite" ? existing.repetitions : 0,
    interval: existing && mode === "overwrite" ? existing.interval : 0,
    dueDate: existing && mode === "overwrite" ? existing.dueDate : null,
    lastReview: existing && mode === "overwrite" ? existing.lastReview : null,
    reviewHistory: existing && mode === "overwrite" ? existing.reviewHistory : [],
    createdAt: existing?.createdAt ?? new Date().toISOString(),
  };
}
