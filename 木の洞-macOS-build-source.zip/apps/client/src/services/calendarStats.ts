import type { Deck, ReviewRecord, WordCard } from "@/types";

export interface CalendarWrongEntry {
  key: string;
  word: WordCard | null;
  attempts: number;
}

export interface CalendarDayStats {
  dateKey: string;
  totalAttempts: number;
  correctAttempts: number;
  wrongAttempts: number;
  wrongWordCount: number;
  newWords: number;
  reviewedWords: number;
  newGoal: number;
  reviewGoal: number;
  completion: number;
  accuracy: number;
  records: ReviewRecord[];
  wrongEntries: CalendarWrongEntry[];
}

export interface CalendarGridDay {
  date: Date;
  dateKey: string;
  inCurrentMonth: boolean;
}

export function getLocalDateKey(date: Date): string {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function wordCanonicalKey(word: WordCard): string {
  return `${word.language ?? "ja"}::${word.word.trim().toLocaleLowerCase()}::${word.kana.trim().toLocaleLowerCase()}`;
}

function reviewDateKey(review: ReviewRecord): string | null {
  const date = new Date(review.reviewedAt);
  return Number.isNaN(date.getTime()) ? null : getLocalDateKey(date);
}

function emptyStats(dateKey: string, newGoal: number, reviewGoal: number): CalendarDayStats {
  return {
    dateKey,
    totalAttempts: 0,
    correctAttempts: 0,
    wrongAttempts: 0,
    wrongWordCount: 0,
    newWords: 0,
    reviewedWords: 0,
    newGoal,
    reviewGoal,
    completion: 0,
    accuracy: 0,
    records: [],
    wrongEntries: [],
  };
}

export function buildCalendarStats(
  words: WordCard[],
  decks: Deck[],
  reviews: ReviewRecord[],
  deckId?: string,
): Map<string, CalendarDayStats> {
  const wordById = new Map(words.map((word) => [word.id, word]));
  const wordKeyById = new Map(words.map((word) => [word.id, wordCanonicalKey(word)]));
  const scopedWords = deckId ? words.filter((word) => word.deckIds.includes(deckId)) : words;
  const scopedWordByKey = new Map(scopedWords.map((word) => [wordCanonicalKey(word), word]));
  const scopedKeys = new Set(scopedWordByKey.keys());
  const firstReviewByKey = new Map<string, string>();
  const sortedReviews = [...reviews].sort((a, b) => a.reviewedAt.localeCompare(b.reviewedAt));

  for (const review of sortedReviews) {
    const key = review.canonicalKey ?? wordKeyById.get(review.wordId) ?? review.wordId;
    if (!firstReviewByKey.has(key)) firstReviewByKey.set(key, review.id);
  }

  const scopedDecks = deckId ? decks.filter((deck) => deck.id === deckId) : decks;
  const newGoal = scopedDecks.reduce((sum, deck) => sum + Math.max(0, deck.dailyNewLimit ?? 0), 0);
  const reviewGoal = scopedDecks.reduce((sum, deck) => sum + Math.max(0, deck.dailyReviewLimit ?? 0), 0);
  const recordsByDate = new Map<string, ReviewRecord[]>();

  for (const review of reviews) {
    const key = review.canonicalKey ?? wordKeyById.get(review.wordId) ?? review.wordId;
    if (deckId && !scopedKeys.has(key)) continue;
    const dateKey = reviewDateKey(review);
    if (!dateKey) continue;
    const dayRecords = recordsByDate.get(dateKey) ?? [];
    dayRecords.push(review);
    recordsByDate.set(dateKey, dayRecords);
  }

  const result = new Map<string, CalendarDayStats>();
  for (const [dateKey, records] of recordsByDate) {
    const newKeys = new Set<string>();
    const reviewedKeys = new Set<string>();
    const wrongByKey = new Map<string, CalendarWrongEntry>();

    for (const review of records) {
      const key = review.canonicalKey ?? wordKeyById.get(review.wordId) ?? review.wordId;
      const isLegacyFirstReview = review.wasNew === undefined && firstReviewByKey.get(key) === review.id;
      if (review.wasNew || isLegacyFirstReview) newKeys.add(key);
      else reviewedKeys.add(key);

      if (review.rating === "AGAIN") {
        const existing = wrongByKey.get(key);
        if (existing) existing.attempts += 1;
        else wrongByKey.set(key, { key, word: scopedWordByKey.get(key) ?? wordById.get(review.wordId) ?? null, attempts: 1 });
      }
    }

    for (const key of newKeys) reviewedKeys.delete(key);

    const totalAttempts = records.length;
    const wrongAttempts = records.filter((review) => review.rating === "AGAIN").length;
    const correctAttempts = totalAttempts - wrongAttempts;
    const plannedTotal = newGoal + reviewGoal;
    const completedPlanned = Math.min(newKeys.size, newGoal) + Math.min(reviewedKeys.size, reviewGoal);
    const completion = plannedTotal > 0
      ? Math.min(100, Math.round((completedPlanned / plannedTotal) * 100))
      : totalAttempts > 0 ? 100 : 0;

    result.set(dateKey, {
      dateKey,
      totalAttempts,
      correctAttempts,
      wrongAttempts,
      wrongWordCount: wrongByKey.size,
      newWords: newKeys.size,
      reviewedWords: reviewedKeys.size,
      newGoal,
      reviewGoal,
      completion,
      accuracy: totalAttempts > 0 ? Math.round((correctAttempts / totalAttempts) * 100) : 0,
      records: [...records].sort((a, b) => b.reviewedAt.localeCompare(a.reviewedAt)),
      wrongEntries: [...wrongByKey.values()].sort((a, b) => b.attempts - a.attempts),
    });
  }

  return result;
}

export function getCalendarDayStats(
  stats: Map<string, CalendarDayStats>,
  dateKey: string,
  decks: Deck[],
): CalendarDayStats {
  const existing = stats.get(dateKey);
  if (existing) return existing;
  return emptyStats(
    dateKey,
    decks.reduce((sum, deck) => sum + Math.max(0, deck.dailyNewLimit ?? 0), 0),
    decks.reduce((sum, deck) => sum + Math.max(0, deck.dailyReviewLimit ?? 0), 0),
  );
}

export function getMonthGrid(month: Date): CalendarGridDay[] {
  const firstDay = new Date(month.getFullYear(), month.getMonth(), 1);
  const gridStart = new Date(firstDay);
  gridStart.setDate(firstDay.getDate() - firstDay.getDay());

  return Array.from({ length: 42 }, (_, index) => {
    const date = new Date(gridStart);
    date.setDate(gridStart.getDate() + index);
    return {
      date,
      dateKey: getLocalDateKey(date),
      inCurrentMonth: date.getMonth() === month.getMonth(),
    };
  });
}
