import { describe, expect, it } from "vitest";
import type { Deck, ReviewRecord, WordCard } from "@/types";
import { buildCalendarStats, getCalendarDayStats, getLocalDateKey, getMonthGrid } from "./calendarStats";

const deck: Deck = {
  id: "deck-1",
  name: "日语",
  language: "ja",
  menuId: "menu-japanese",
  dailyNewLimit: 2,
  dailyReviewLimit: 2,
  dailyGroupCount: 1,
  wordsPerGroup: 10,
  order: "due_first",
  learningMode: "TYPE_ANSWER",
  reviewMode: "TYPE_ANSWER",
  autoSpeak: false,
  voice: "natural",
  createdAt: "2026-09-01T00:00:00.000Z",
};

function word(id: string, value: string): WordCard {
  return {
    id,
    language: "ja",
    word: value,
    kana: value,
    meaning: value,
    partOfSpeech: "名词",
    example: "",
    exampleTranslation: "",
    tags: [],
    deckIds: ["deck-1"],
    status: "LEARNING",
    difficulty: 0,
    stability: 0,
    repetitions: 1,
    interval: 1,
    dueDate: null,
    lastReview: null,
    createdAt: "2026-09-01T00:00:00.000Z",
    reviewHistory: [],
  };
}

function review(id: string, wordId: string, rating: ReviewRecord["rating"], reviewedAt: string, wasNew?: boolean): ReviewRecord {
  return { id, wordId, rating, reviewedAt, previousInterval: 0, newInterval: 1, wasNew };
}

describe("calendarStats", () => {
  it("uses local calendar dates rather than UTC slices", () => {
    const date = new Date(2026, 8, 26, 0, 30);
    expect(getLocalDateKey(date)).toBe("2026-09-26");
  });

  it("deduplicates new words and separates review words", () => {
    const words = [word("a", "食べる"), word("a-copy", "食べる"), word("b", "飲む")];
    const stats = buildCalendarStats(words, [deck], [
      { ...review("r1", "a", "GOOD", "2026-09-26T08:00:00.000Z", true), canonicalKey: "ja::食べる::食べる" },
      { ...review("r2", "a-copy", "EASY", "2026-09-26T09:00:00.000Z", true), canonicalKey: "ja::食べる::食べる" },
      review("r3", "b", "GOOD", "2026-09-25T08:00:00.000Z", true),
      review("r4", "b", "HARD", "2026-09-26T10:00:00.000Z", false),
    ]);
    const day = getCalendarDayStats(stats, "2026-09-26", [deck]);
    expect(day.newWords).toBe(1);
    expect(day.reviewedWords).toBe(1);
  });

  it("tracks wrong attempts and unique wrong words", () => {
    const words = [word("a", "食べる")];
    const stats = buildCalendarStats(words, [deck], [
      review("r1", "a", "AGAIN", "2026-09-26T08:00:00.000Z", true),
      review("r2", "a", "AGAIN", "2026-09-26T09:00:00.000Z", false),
    ]);
    const day = getCalendarDayStats(stats, "2026-09-26", [deck]);
    expect(day.wrongAttempts).toBe(2);
    expect(day.wrongWordCount).toBe(1);
    expect(day.wrongEntries[0].attempts).toBe(2);
  });

  it("caps completion at 100 percent and handles zero-goal days", () => {
    const words = [word("a", "食べる"), word("b", "飲む")];
    const stats = buildCalendarStats(words, [deck], [
      review("r1", "a", "GOOD", "2026-09-26T08:00:00.000Z", true),
      review("r2", "b", "GOOD", "2026-09-26T09:00:00.000Z", true),
    ]);
    expect(getCalendarDayStats(stats, "2026-09-26", [deck]).completion).toBeLessThanOrEqual(100);

    const noGoalDeck = { ...deck, dailyNewLimit: 0, dailyReviewLimit: 0 };
    const zeroGoalStats = buildCalendarStats(words, [noGoalDeck], [
      review("r3", "a", "GOOD", "2026-09-27T08:00:00.000Z", false),
    ]);
    expect(getCalendarDayStats(zeroGoalStats, "2026-09-27", [noGoalDeck]).completion).toBe(100);
    expect(getCalendarDayStats(zeroGoalStats, "2026-09-28", [noGoalDeck]).completion).toBe(0);
  });

  it("builds a six-week month grid beginning on Sunday", () => {
    const grid = getMonthGrid(new Date(2026, 8, 1));
    expect(grid).toHaveLength(42);
    expect(grid[0].date.getDay()).toBe(0);
    expect(grid.some((day) => day.dateKey === "2026-09-01" && day.inCurrentMonth)).toBe(true);
  });

  it("scopes daily details and goals to the selected deck", () => {
    const englishDeck: Deck = { ...deck, id: "deck-2", name: "英语", language: "en", dailyNewLimit: 8, dailyReviewLimit: 12 };
    const japaneseWord = word("a", "食べる");
    const englishWord = { ...word("b", "apple"), language: "en" as const, deckIds: ["deck-2"] };
    const stats = buildCalendarStats(
      [japaneseWord, englishWord],
      [deck, englishDeck],
      [
        review("r1", "a", "GOOD", "2026-09-26T08:00:00.000Z", true),
        review("r2", "b", "AGAIN", "2026-09-26T09:00:00.000Z", true),
      ],
      "deck-2",
    );
    const day = getCalendarDayStats(stats, "2026-09-26", [englishDeck]);
    expect(day.newWords).toBe(1);
    expect(day.totalAttempts).toBe(1);
    expect(day.wrongWordCount).toBe(1);
    expect(day.newGoal).toBe(8);
    expect(day.reviewGoal).toBe(12);
  });
});
