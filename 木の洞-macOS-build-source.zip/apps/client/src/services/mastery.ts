import type { WordCard } from "@/types";

const MASTERED_INTERVAL_DAYS = 21;
const DAY_MS = 24 * 60 * 60 * 1000;

/**
 * Records an explicit "I know this" action without inventing a review attempt.
 * In particular, it leaves reviewHistory untouched so today's new-word goal
 * (which is based on first-review records) does not increase.
 */
export function createMasteredWord(word: WordCard, now = new Date()): WordCard {
  const interval = Math.max(MASTERED_INTERVAL_DAYS, word.interval);
  return {
    ...word,
    status: "MATURE",
    interval,
    stability: Math.max(interval, word.stability),
    repetitions: Math.max(7, word.repetitions),
    reviewCycle: 7,
    dueDate: new Date(now.getTime() + interval * DAY_MS).toISOString(),
  };
}
