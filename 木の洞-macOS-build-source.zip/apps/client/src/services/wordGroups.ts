import type { Deck, WordCard } from "@/types";

const numerals = ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十"];

export function fallbackUnitLabel(index: number) {
  const number = index + 1;
  return number <= numerals.length ? `第${numerals[number - 1]}单元` : `第${number}单元`;
}

/**
 * 让已有旧数据也能显示目录：优先使用单词显式 unit，
 * 没有 unit 时按词库设置的 wordsPerGroup 顺序推导。
 */
export function buildWordGroups(deck: Deck, words: WordCard[]) {
  const size = Math.max(1, deck.wordsPerGroup || 10);
  const groups = new Map<string, WordCard[]>();
  if (deck.units?.length) deck.units.forEach((unit) => groups.set(unit, []));
  words.forEach((word, index) => {
    const explicitUnit = word.unit?.trim();
    const label = explicitUnit && (!deck.units?.length || deck.units.includes(explicitUnit))
      ? explicitUnit
      : explicitUnit && deck.units?.length
        ? "未分类"
        : fallbackUnitLabel(Math.floor(index / size));
    groups.set(label, [...(groups.get(label) ?? []), word]);
  });
  return [...groups.entries()].map(([label, groupWords]) => ({ label, words: groupWords }));
}

export function getWordUnit(deck: Deck, words: WordCard[], word: WordCard) {
  const index = words.findIndex((item) => item.id === word.id);
  const explicitUnit = word.unit?.trim();
  if (explicitUnit && (!deck.units?.length || deck.units.includes(explicitUnit))) return explicitUnit;
  if (explicitUnit && deck.units?.length) return "未分类";
  return fallbackUnitLabel(Math.floor(Math.max(0, index) / Math.max(1, deck.wordsPerGroup || 10)));
}
