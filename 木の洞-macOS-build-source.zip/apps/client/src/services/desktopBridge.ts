import { invoke, isTauri } from "@tauri-apps/api/core";

export interface DesktopRuntimeInfo {
  desktop: boolean;
  productName: string;
  accountSystemName: string;
  version: string;
  platform: string;
  cloudSyncEnabled: boolean;
}

export function isDesktopRuntime() {
  return typeof window !== "undefined" && isTauri();
}

export async function invokeDesktop<T>(
  command: string,
  args?: Record<string, unknown>,
): Promise<T> {
  if (!isDesktopRuntime()) throw new Error("当前功能仅在木の洞桌面 App 中可用");
  return invoke<T>(command, args);
}
