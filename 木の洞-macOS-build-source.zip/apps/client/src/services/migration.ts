import { mergePortableSnapshot, readCurrentSnapshot } from "./storage";
import type { AppSettings, Deck, ReviewRecord, WordCard } from "@/types";

const FORMAT = "kinodou-migration";
const ITERATIONS = 250_000;

interface PortablePayload {
  format: typeof FORMAT;
  version: 1;
  exportedAt: string;
  product: "木の洞";
  data: {
    words: WordCard[];
    decks: Deck[];
    reviews: ReviewRecord[];
    settings: AppSettings;
  };
}

interface EncryptedEnvelope {
  format: typeof FORMAT;
  version: 1;
  encryption: "AES-GCM-256";
  iterations: number;
  salt: string;
  iv: string;
  payload: string;
}

function bytesToBase64(bytes: Uint8Array) {
  let binary = "";
  for (let index = 0; index < bytes.length; index += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(index, index + 0x8000));
  }
  return btoa(binary);
}

function base64ToBytes(value: string) {
  const binary = atob(value);
  const bytes = new Uint8Array(binary.length);
  for (let index = 0; index < binary.length; index += 1) {
    bytes[index] = binary.charCodeAt(index);
  }
  return bytes;
}

async function deriveKey(passphrase: string, salt: Uint8Array, usage: KeyUsage[]) {
  const passphraseBytes = new TextEncoder().encode(passphrase);
  const passphraseBuffer = passphraseBytes.buffer.slice(
    passphraseBytes.byteOffset,
    passphraseBytes.byteOffset + passphraseBytes.byteLength,
  ) as ArrayBuffer;
  const saltBuffer = salt.buffer.slice(
    salt.byteOffset,
    salt.byteOffset + salt.byteLength,
  ) as ArrayBuffer;
  const source = await crypto.subtle.importKey(
    "raw",
    passphraseBuffer,
    "PBKDF2",
    false,
    ["deriveKey"],
  );
  return crypto.subtle.deriveKey(
    { name: "PBKDF2", hash: "SHA-256", salt: saltBuffer, iterations: ITERATIONS },
    source,
    { name: "AES-GCM", length: 256 },
    false,
    usage,
  );
}

export async function exportMigrationPackage(passphrase: string) {
  if (passphrase.length < 8) throw new Error("迁移密码至少需要 8 位。");
  const snapshot = await readCurrentSnapshot();
  const payload: PortablePayload = {
    format: FORMAT,
    version: 1,
    exportedAt: new Date().toISOString(),
    product: "木の洞",
    data: snapshot,
  };
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(passphrase, salt, ["encrypt"]);
  const encrypted = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv: iv.buffer as ArrayBuffer },
    key,
    new TextEncoder().encode(JSON.stringify(payload)),
  );
  const envelope: EncryptedEnvelope = {
    format: FORMAT,
    version: 1,
    encryption: "AES-GCM-256",
    iterations: ITERATIONS,
    salt: bytesToBase64(salt),
    iv: bytesToBase64(iv),
    payload: bytesToBase64(new Uint8Array(encrypted)),
  };
  const blob = new Blob([JSON.stringify(envelope)], {
    type: "application/vnd.kinodou.migration+json",
  });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = `木の洞-数据迁移-${new Date().toISOString().slice(0, 10)}.kino`;
  anchor.click();
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export async function importMigrationPackage(file: File, passphrase: string) {
  if (passphrase.length < 8) throw new Error("请输入导出时设置的迁移密码。");
  let envelope: EncryptedEnvelope;
  try {
    envelope = JSON.parse(await file.text()) as EncryptedEnvelope;
  } catch {
    throw new Error("迁移包格式无效。");
  }
  if (
    envelope.format !== FORMAT ||
    envelope.version !== 1 ||
    envelope.encryption !== "AES-GCM-256"
  ) {
    throw new Error("这不是受支持的木の洞迁移包。");
  }
  try {
    const salt = base64ToBytes(envelope.salt);
    const iv = base64ToBytes(envelope.iv);
    const key = await deriveKey(passphrase, salt, ["decrypt"]);
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-GCM", iv: iv.buffer as ArrayBuffer },
      key,
      base64ToBytes(envelope.payload),
    );
    const payload = JSON.parse(
      new TextDecoder().decode(decrypted),
    ) as PortablePayload;
    if (payload.format !== FORMAT || payload.product !== "木の洞") {
      throw new Error("迁移包内容无效。");
    }
    return mergePortableSnapshot(payload.data);
  } catch (error) {
    if (error instanceof Error && error.message.includes("迁移包内容")) throw error;
    throw new Error("迁移密码不正确，或文件已经损坏。");
  }
}
