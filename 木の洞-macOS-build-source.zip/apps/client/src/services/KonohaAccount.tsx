import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  invokeDesktop,
  isDesktopRuntime,
  type DesktopRuntimeInfo,
} from "./desktopBridge";
import { deleteStorageScope } from "./storage";

export interface KonohaAccount {
  id: string;
  username: string;
  email?: string | null;
  avatarDataUrl?: string | null;
  createdAt: string;
  updatedAt: string;
  lastLoginAt?: string | null;
  active: boolean;
  sessionStatus: "ready" | "expired";
}

interface RegisterInput {
  username: string;
  password: string;
  email?: string;
}

interface LoginInput {
  username: string;
  password: string;
  remember: boolean;
}

interface RegisterResult {
  account: KonohaAccount;
  recoveryCode: string;
}

interface KonohaAccountContextValue {
  ready: boolean;
  desktop: boolean;
  runtime: DesktopRuntimeInfo | null;
  accounts: KonohaAccount[];
  currentAccount: KonohaAccount | null;
  addAccountOpen: boolean;
  setAddAccountOpen: (open: boolean) => void;
  refreshAccounts: () => Promise<void>;
  register: (input: RegisterInput) => Promise<RegisterResult>;
  login: (input: LoginInput) => Promise<KonohaAccount>;
  switchAccount: (userId: string) => Promise<KonohaAccount>;
  logout: () => Promise<void>;
  removeLocalAccount: (userId: string) => Promise<void>;
  updateProfile: (input: {
    email?: string | null;
    avatarDataUrl?: string | null;
  }) => Promise<KonohaAccount>;
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;
  resetPassword: (
    username: string,
    recoveryCode: string,
    newPassword: string,
  ) => Promise<void>;
  deleteAccount: (password: string) => Promise<void>;
}

const KonohaAccountContext = createContext<KonohaAccountContextValue | null>(null);

function messageFromError(error: unknown) {
  if (typeof error === "string") return error;
  if (error instanceof Error) return error.message;
  if (error && typeof error === "object" && "message" in error) {
    return String((error as { message: unknown }).message);
  }
  return "木の叶账号操作失败";
}

export function KonohaAccountProvider({ children }: { children: ReactNode }) {
  const desktop = isDesktopRuntime();
  const [ready, setReady] = useState(!desktop);
  const [runtime, setRuntime] = useState<DesktopRuntimeInfo | null>(null);
  const [accounts, setAccounts] = useState<KonohaAccount[]>([]);
  const [currentAccount, setCurrentAccount] = useState<KonohaAccount | null>(null);
  const [addAccountOpen, setAddAccountOpen] = useState(false);

  const refreshAccounts = useCallback(async () => {
    if (!desktop) return;
    const [nextAccounts, active] = await Promise.all([
      invokeDesktop<KonohaAccount[]>("konoha_accounts"),
      invokeDesktop<KonohaAccount | null>("konoha_current_account"),
    ]);
    setAccounts(nextAccounts);
    setCurrentAccount(active);
  }, [desktop]);

  useEffect(() => {
    if (!desktop) return;
    void Promise.all([
      invokeDesktop<DesktopRuntimeInfo>("desktop_runtime_info"),
      refreshAccounts(),
    ])
      .then(([info]) => setRuntime(info))
      .finally(() => setReady(true));
  }, [desktop, refreshAccounts]);

  const register = useCallback(
    async (input: RegisterInput) => {
      try {
        const result = await invokeDesktop<RegisterResult>("konoha_register", { input });
        await refreshAccounts();
        return result;
      } catch (error) {
        throw new Error(messageFromError(error));
      }
    },
    [refreshAccounts],
  );

  const login = useCallback(
    async (input: LoginInput) => {
      try {
        const account = await invokeDesktop<KonohaAccount>("konoha_login", { input });
        await refreshAccounts();
        setAddAccountOpen(false);
        return account;
      } catch (error) {
        throw new Error(messageFromError(error));
      }
    },
    [refreshAccounts],
  );

  const switchAccount = useCallback(
    async (userId: string) => {
      try {
        const account = await invokeDesktop<KonohaAccount>("konoha_switch_account", {
          userId,
        });
        await refreshAccounts();
        return account;
      } catch (error) {
        throw new Error(messageFromError(error));
      }
    },
    [refreshAccounts],
  );

  const logout = useCallback(async () => {
    await invokeDesktop("konoha_logout");
    await refreshAccounts();
  }, [refreshAccounts]);

  const removeLocalAccount = useCallback(
    async (userId: string) => {
      await invokeDesktop("konoha_remove_local_account", { userId });
      await refreshAccounts();
    },
    [refreshAccounts],
  );

  const updateProfile = useCallback(
    async (input: { email?: string | null; avatarDataUrl?: string | null }) => {
      if (!currentAccount) throw new Error("请先登录木の叶账号");
      const account = await invokeDesktop<KonohaAccount>("konoha_update_profile", {
        userId: currentAccount.id,
        input,
      });
      await refreshAccounts();
      return account;
    },
    [currentAccount, refreshAccounts],
  );

  const changePassword = useCallback(
    async (currentPassword: string, newPassword: string) => {
      if (!currentAccount) throw new Error("请先登录木の叶账号");
      await invokeDesktop("konoha_change_password", {
        userId: currentAccount.id,
        currentPassword,
        newPassword,
      });
    },
    [currentAccount],
  );

  const resetPassword = useCallback(
    async (username: string, recoveryCode: string, newPassword: string) => {
      await invokeDesktop("konoha_reset_password", {
        username,
        recoveryCode,
        newPassword,
      });
    },
    [],
  );

  const deleteAccount = useCallback(
    async (password: string) => {
      if (!currentAccount) throw new Error("请先登录木の叶账号");
      await invokeDesktop("konoha_delete_account", {
        userId: currentAccount.id,
        password,
      });
      await deleteStorageScope(currentAccount.id);
      await refreshAccounts();
    },
    [currentAccount, refreshAccounts],
  );

  const value = useMemo<KonohaAccountContextValue>(
    () => ({
      ready,
      desktop,
      runtime,
      accounts,
      currentAccount,
      addAccountOpen,
      setAddAccountOpen,
      refreshAccounts,
      register,
      login,
      switchAccount,
      logout,
      removeLocalAccount,
      updateProfile,
      changePassword,
      resetPassword,
      deleteAccount,
    }),
    [
      ready,
      desktop,
      runtime,
      accounts,
      currentAccount,
      addAccountOpen,
      refreshAccounts,
      register,
      login,
      switchAccount,
      logout,
      removeLocalAccount,
      updateProfile,
      changePassword,
      resetPassword,
      deleteAccount,
    ],
  );

  return (
    <KonohaAccountContext.Provider value={value}>
      {children}
    </KonohaAccountContext.Provider>
  );
}

export function useKonohaAccount() {
  const value = useContext(KonohaAccountContext);
  if (!value) throw new Error("useKonohaAccount 必须在 KonohaAccountProvider 中使用");
  return value;
}
