import type { LocalAsset, StudyLanguage, VoicePreference, WordCard } from "@/types";
import { invokeDesktop, isDesktopRuntime } from "@/services/desktopBridge";

export interface TTSOptions {
  voice?: VoicePreference;
  language?: StudyLanguage;
  rate?: number;
  pitch?: number;
}

export interface TTSProvider {
  speak(text: string, options?: TTSOptions): Promise<boolean>;
  stop(): void;
  isAvailable(): boolean;
}

const femaleVoiceHints = /\bfemale\b|\bwoman\b|\bgirl\b|女|女性|kyoko|haruka|sayaka|nanami|yuna|aoi|samantha|victoria|karen|zira|aria|jenny|susan/i;
const maleVoiceHints = /\bmale\b|\bman\b|\bboy\b|男|男性|ichiro|otoya|hattori|takumi|keita|ryota|david|mark|daniel|alex|tom|fred/i;
const naturalVoiceHints = /natural|enhanced|premium|neural|高品质|自然/i;

function getVoices(language: StudyLanguage) {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return [];
  const locale = language === "en" ? "en" : "ja";
  return window.speechSynthesis.getVoices().filter((voice) => new RegExp(`^${locale}(?:-|_)`, "i").test(voice.lang));
}

function waitForVoices(language: StudyLanguage, timeoutMs = 350): Promise<SpeechSynthesisVoice[]> {
  const initial = getVoices(language);
  if (initial.length) return Promise.resolve(initial);
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return Promise.resolve([]);
  return new Promise((resolve) => {
    let settled = false;
    const finish = () => {
      if (settled) return;
      settled = true;
      window.speechSynthesis.removeEventListener("voiceschanged", finish);
      resolve(getVoices(language));
    };
    window.speechSynthesis.addEventListener("voiceschanged", finish);
    window.setTimeout(finish, timeoutMs);
  });
}

function voiceScore(voice: SpeechSynthesisVoice, preference: VoicePreference, language: StudyLanguage) {
  const localBonus = voice.localService ? 4 : 0;
  const preferredLocale = language === "en" ? "en-us" : "ja-jp";
  const localeBonus = voice.lang.toLowerCase() === preferredLocale ? 3 : 0;
  const qualityBonus = naturalVoiceHints.test(voice.name) ? 4 : 0;
  if (preference === "female") return (femaleVoiceHints.test(voice.name) ? 20 : 0) + localBonus + localeBonus + qualityBonus;
  if (preference === "male") return (maleVoiceHints.test(voice.name) ? 20 : 0) + localBonus + localeBonus + qualityBonus;
  return localBonus + localeBonus + qualityBonus;
}

function pickVoice(voices: SpeechSynthesisVoice[], preference: VoicePreference = "natural", language: StudyLanguage = "ja") {
  return [...voices].sort((a, b) => voiceScore(b, preference, language) - voiceScore(a, preference, language))[0] ?? null;
}

let activeResolve: ((value: boolean) => void) | null = null;
let playbackRequestId = 0;
let activeAudio: HTMLAudioElement | null = null;
let activeAudioUrl: string | null = null;
let activeAudioResolve: ((value: boolean) => void) | null = null;

function clearActiveAudio() {
  if (activeAudio) {
    activeAudio.pause();
    activeAudio.src = "";
    activeAudio = null;
  }
  if (activeAudioUrl) {
    URL.revokeObjectURL(activeAudioUrl);
    activeAudioUrl = null;
  }
}

export const browserTTSProvider: TTSProvider = {
  async speak(text, options = {}) {
    if (typeof window === "undefined" || !("speechSynthesis" in window) || !text.trim()) return false;
    const requestId = ++playbackRequestId;
    const resolvePrevious = activeResolve;
    activeResolve = null;
    resolvePrevious?.(false);
    const resolvePreviousAudio = activeAudioResolve;
    activeAudioResolve = null;
    resolvePreviousAudio?.(false);
    clearActiveAudio();
    window.speechSynthesis.cancel();
    const language = options.language ?? "ja";
    const voices = await waitForVoices(language);
    if (requestId !== playbackRequestId) return false;
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language === "en" ? "en-US" : "ja-JP";
    utterance.rate = options.rate ?? (language === "en" ? 0.94 : 0.88);
    utterance.pitch = options.pitch ?? 1.02;
    utterance.volume = 1;
    const voice = pickVoice(voices, options.voice, language);
    if (voice) utterance.voice = voice;
    return new Promise((resolve) => {
      activeResolve = resolve;
      const finish = (value: boolean) => {
        if (activeResolve !== resolve) return;
        activeResolve = null;
        resolve(value);
      };
      utterance.onend = () => finish(true);
      utterance.onerror = () => finish(false);
      window.speechSynthesis.speak(utterance);
    });
  },
  stop() {
    playbackRequestId += 1;
    const resolveCurrent = activeResolve;
    activeResolve = null;
    resolveCurrent?.(false);
    const resolveCurrentAudio = activeAudioResolve;
    activeAudioResolve = null;
    resolveCurrentAudio?.(false);
    clearActiveAudio();
    if (typeof window !== "undefined" && "speechSynthesis" in window) window.speechSynthesis.cancel();
  },
  isAvailable() {
    return typeof window !== "undefined" && "speechSynthesis" in window;
  },
};

/**
 * TTS boundary for future server-side AI providers.
 * Uses the device's matching Japanese or English voice without exposing API keys.
 */
export async function generateWordAudio(text: string, options?: TTSOptions) {
  return browserTTSProvider.speak(text, options);
}

export function normalizeAudioLookupKey(value: string) {
  return value.normalize("NFKC").trim().toLocaleLowerCase();
}

export function findImportedWordAudio(
  assets: LocalAsset[],
  word: Pick<WordCard, "word" | "language">,
) {
  const language = word.language === "en" ? "en" : "ja";
  const lookupKey = normalizeAudioLookupKey(word.word);
  return assets.find(
    (asset) =>
      asset.kind === "word-audio" &&
      asset.language === language &&
      asset.lookupKey === lookupKey,
  );
}

export async function playImportedAudio(data: Blob) {
  if (typeof window === "undefined") return false;
  const requestId = ++playbackRequestId;
  const resolvePrevious = activeResolve;
  activeResolve = null;
  resolvePrevious?.(false);
  const resolvePreviousAudio = activeAudioResolve;
  activeAudioResolve = null;
  resolvePreviousAudio?.(false);
  if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  clearActiveAudio();
  const url = URL.createObjectURL(data);
  const audio = new Audio(url);
  activeAudio = audio;
  activeAudioUrl = url;
  return new Promise<boolean>((resolve) => {
    activeAudioResolve = resolve;
    const finish = (value: boolean) => {
      if (requestId !== playbackRequestId || activeAudio !== audio) {
        resolve(false);
        return;
      }
      activeAudioResolve = null;
      clearActiveAudio();
      resolve(value);
    };
    audio.onended = () => finish(true);
    audio.onerror = () => finish(false);
    void audio.play().catch(() => finish(false));
  });
}

interface DesktopTtsResult {
  source: "browser" | "cache" | "provider";
  dataUrl?: string | null;
  mimeType?: string | null;
  cacheKey?: string | null;
}

async function playAudioUrl(url: string) {
  if (typeof window === "undefined") return false;
  const requestId = ++playbackRequestId;
  const resolvePrevious = activeResolve;
  activeResolve = null;
  resolvePrevious?.(false);
  const resolvePreviousAudio = activeAudioResolve;
  activeAudioResolve = null;
  resolvePreviousAudio?.(false);
  if ("speechSynthesis" in window) window.speechSynthesis.cancel();
  clearActiveAudio();
  const audio = new Audio(url);
  activeAudio = audio;
  return new Promise<boolean>((resolve) => {
    activeAudioResolve = resolve;
    const finish = (value: boolean) => {
      if (requestId !== playbackRequestId || activeAudio !== audio) {
        resolve(false);
        return;
      }
      activeAudioResolve = null;
      clearActiveAudio();
      resolve(value);
    };
    audio.onended = () => finish(true);
    audio.onerror = () => finish(false);
    void audio.play().catch(() => finish(false));
  });
}

export async function playVocabularyAudio(
  word: Pick<WordCard, "word" | "language">,
  assets: LocalAsset[],
  options?: Omit<TTSOptions, "language"> & { desktopUserId?: string },
) {
  const imported = findImportedWordAudio(assets, word);
  if (imported) return playImportedAudio(imported.data);
  const language = word.language === "en" ? "en" : "ja";
  return playConfiguredTextAudio(word.word, language, options);
}

export async function playConfiguredTextAudio(
  text: string,
  language: StudyLanguage,
  options?: Omit<TTSOptions, "language"> & { desktopUserId?: string },
) {
  if (options?.desktopUserId && isDesktopRuntime()) {
    try {
      const result = await invokeDesktop<DesktopTtsResult>("konoha_synthesize_tts", {
        input: {
          userId: options.desktopUserId,
          text,
          language,
        },
      });
      if (result.dataUrl) return playAudioUrl(result.dataUrl);
    } catch {
      // Provider failure falls back to the device voice so studying can continue offline.
    }
  }
  const ttsOptions: TTSOptions = {
    voice: options?.voice,
    rate: options?.rate,
    pitch: options?.pitch,
  };
  return generateWordAudio(text, {
    ...ttsOptions,
    language,
  });
}

export async function generateExampleAudio(text: string, options?: TTSOptions) {
  const defaultRate = options?.language === "en" ? 0.88 : 0.82;
  return browserTTSProvider.speak(text, { ...options, rate: options?.rate ?? defaultRate });
}

export function stopAudio() {
  browserTTSProvider.stop();
}
