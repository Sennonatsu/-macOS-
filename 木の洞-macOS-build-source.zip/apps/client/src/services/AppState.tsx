import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { calculateNextReview, isDue } from "./scheduler";
import { createMasteredWord } from "./mastery";
import { bootstrapStorage, createId, defaultSettings, deleteDeck as deleteStoredDeck, deleteLocalAsset as deleteStoredLocalAsset, deleteReview as deleteStoredReview, deleteWord as deleteStoredWord, saveDeck, saveLocalAsset as saveStoredLocalAsset, saveReview, saveSettings, saveWord, setStorageScope } from "./storage";
import { useKonohaAccount } from "./KonohaAccount";
import type { AppSettings, Deck, LibraryMenu, LocalAsset, Rating, ReviewRecord, StudyLanguage, WordCard } from "@/types";

interface AppStateValue {
  ready: boolean;
  words: WordCard[];
  decks: Deck[];
  reviews: ReviewRecord[];
  localAssets: LocalAsset[];
  settings: AppSettings;
  updateSettings: (next: Partial<AppSettings>) => Promise<void>;
  saveLocalAsset: (asset: LocalAsset) => Promise<void>;
  removeLocalAsset: (id: string) => Promise<void>;
  addLibraryMenu: (name: string, language?: StudyLanguage) => Promise<LibraryMenu | null>;
  removeLibraryMenu: (id: string) => Promise<void>;
  upsertWord: (word: WordCard) => Promise<void>;
  relearnWords: (wordIds: string[]) => Promise<number>;
  removeWord: (id: string) => Promise<void>;
  addDeck: (name: string, description?: string, menuId?: string | null, language?: StudyLanguage) => Promise<Deck | null>;
  updateDeck: (deck: Deck) => Promise<void>;
  removeDeck: (id: string, deleteOnlyWords: boolean) => Promise<void>;
  markWordAudio: (wordId: string, field: "wordGeneratedAt" | "kanaGeneratedAt" | "exampleGeneratedAt", voice?: Deck["voice"]) => Promise<void>;
  reviewWord: (word: WordCard, rating: Rating, responseTimeMs?: number, deckId?: string) => Promise<WordCard>;
  markWordMastered: (word: WordCard) => Promise<WordCard>;
  queue: WordCard[];
  dueCount: number;
  newCount: number;
  completedToday: number;
  todayReviews: ReviewRecord[];
  newLearnedToday: number;
  streak: number;
}

const AppStateContext = createContext<AppStateValue | null>(null);

function dateKey(date: Date) {
  return date.toISOString().slice(0, 10);
}

function canonicalKey(word: Pick<WordCard, "word" | "kana" | "language">) {
  return `${word.language ?? "ja"}::${word.word.trim().toLocaleLowerCase()}::${word.kana.trim().toLocaleLowerCase()}`;
}

function computeStreak(reviews: ReviewRecord[]) {
  const days = new Set(reviews.map((review) => dateKey(new Date(review.reviewedAt))));
  let streak = 0;
  const cursor = new Date();
  while (days.has(dateKey(cursor))) {
    streak += 1;
    cursor.setDate(cursor.getDate() - 1);
  }
  return streak;
}

export function AppStateProvider({ children }: { children: ReactNode }) {
  const { desktop, currentAccount } = useKonohaAccount();
  const [ready, setReady] = useState(false);
  const [words, setWords] = useState<WordCard[]>([]);
  const [decks, setDecks] = useState<Deck[]>([]);
  const [reviews, setReviews] = useState<ReviewRecord[]>([]);
  const [localAssets, setLocalAssets] = useState<LocalAsset[]>([]);
  const [settings, setSettings] = useState<AppSettings>(defaultSettings);

  useEffect(() => {
    let cancelled = false;
    setReady(false);
    setStorageScope(desktop ? currentAccount?.id : null);
    void bootstrapStorage().then((data) => {
      if (cancelled) return;
      setWords(data.words);
      setDecks(data.decks);
      setReviews(data.reviews);
      setLocalAssets(data.assets);
      setSettings(data.settings);
      setReady(true);
    });
    return () => {
      cancelled = true;
    };
  }, [currentAccount?.id, desktop]);

  useEffect(() => {
    if (!ready) return;
    const root = document.documentElement;
    const shouldDark = settings.theme === "dark" || (settings.theme === "system" && window.matchMedia("(prefers-color-scheme: dark)").matches);
    root.classList.toggle("dark", shouldDark);
    root.dataset.colorStyle = settings.colorStyle;
    root.dataset.accent = settings.accentColor;
    root.dataset.accentMode = settings.accentFollowColorStyle ? "follow" : "fixed";
    root.style.setProperty("--ui-scale", String(settings.uiScale));
  }, [ready, settings.theme, settings.colorStyle, settings.accentColor, settings.accentFollowColorStyle, settings.uiScale]);

  useEffect(() => {
    if (!ready) return;
    const root = document.documentElement;
    const asset = localAssets.find((item) => item.id === settings.customFontAssetId && item.kind === "font");
    if (!asset || typeof FontFace === "undefined") {
      root.style.removeProperty("--user-font-family");
      return;
    }
    const family = `KinoImportedFont-${asset.id.replace(/[^a-zA-Z0-9_-]/g, "")}`;
    const url = URL.createObjectURL(asset.data);
    const face = new FontFace(family, `url("${url}")`);
    let disposed = false;
    void face.load().then((loaded) => {
      if (disposed) return;
      document.fonts.add(loaded);
      root.style.setProperty("--user-font-family", `"${family}"`);
    }).catch(() => {
      if (!disposed) root.style.removeProperty("--user-font-family");
    });
    return () => {
      disposed = true;
      document.fonts.delete(face);
      URL.revokeObjectURL(url);
      root.style.removeProperty("--user-font-family");
    };
  }, [localAssets, ready, settings.customFontAssetId]);

  const upsertWord = useCallback(async (word: WordCard) => {
    const normalized = { ...word, language: word.language === "en" ? "en" as const : "ja" as const, deckIds: word.deckIds ?? (word.deckId ? [word.deckId] : []) };
    const sameWord = words.filter((item) => item.id !== normalized.id && canonicalKey(item) === canonicalKey(normalized));
    const inherited = sameWord.sort((a, b) => (b.stability - a.stability) || (b.repetitions - a.repetitions) || (b.interval - a.interval))[0];
    const prepared = inherited && normalized.status === "NEW"
      ? {
          ...normalized,
          status: inherited.status,
          difficulty: inherited.difficulty,
          stability: inherited.stability,
          repetitions: inherited.repetitions,
          reviewCycle: inherited.reviewCycle,
          interval: inherited.interval,
          dueDate: inherited.dueDate,
          lastReview: inherited.lastReview,
          reviewHistory: [...inherited.reviewHistory],
        }
      : normalized;
    await saveWord(prepared);
    setWords((current) => {
      const index = current.findIndex((item) => item.id === prepared.id);
      if (index === -1) return [prepared, ...current];
      const next = [...current];
      next[index] = prepared;
      return next;
    });
  }, [words]);

  const relearnWords = useCallback(async (wordIds: string[]) => {
    const selectedIds = new Set(wordIds);
    const resetAt = new Date().toISOString();
    const updated = words
      .filter((word) => selectedIds.has(word.id))
      .map((word) => ({
        ...word,
        status: "NEW" as const,
        difficulty: 2.5,
        stability: 0,
        repetitions: 0,
        interval: 0,
        reviewCycle: 0,
        dueDate: null,
        lastReview: null,
        relearnedAt: resetAt,
      }));
    if (!updated.length) return 0;
    await Promise.all(updated.map((word) => saveWord(word)));
    const updates = new Map(updated.map((word) => [word.id, word]));
    setWords((current) => current.map((word) => updates.get(word.id) ?? word));
    return updated.length;
  }, [words]);

  const removeWord = useCallback(async (id: string) => {
    await deleteStoredWord(id);
    const relatedReviews = reviews.filter((review) => review.wordId === id);
    await Promise.all(relatedReviews.map((review) => deleteStoredReview(review.id)));
    setWords((current) => current.filter((word) => word.id !== id));
    setReviews((current) => current.filter((review) => review.wordId !== id));
  }, [reviews]);

  const updateSettings = useCallback(async (next: Partial<AppSettings>) => {
    const updated = { ...settings, ...next };
    await saveSettings(updated);
    setSettings(updated);
  }, [settings]);

  const saveLocalAsset = useCallback(async (asset: LocalAsset) => {
    await saveStoredLocalAsset(asset);
    setLocalAssets((current) => {
      const index = current.findIndex((item) => item.id === asset.id);
      if (index === -1) return [...current, asset];
      const next = [...current];
      next[index] = asset;
      return next;
    });
  }, []);

  const removeLocalAsset = useCallback(async (id: string) => {
    await deleteStoredLocalAsset(id);
    setLocalAssets((current) => current.filter((item) => item.id !== id));
  }, []);

  const addLibraryMenu = useCallback(async (name: string, language: StudyLanguage = "ja") => {
    const cleanName = name.trim();
    if (!cleanName || settings.libraryMenus.some((menu) => menu.name.toLocaleLowerCase() === cleanName.toLocaleLowerCase())) return null;
    const menu: LibraryMenu = {
      id: createId(),
      name: cleanName,
      shortLabel: cleanName.slice(0, 1) || "词",
      language,
      createdAt: new Date().toISOString(),
    };
    const updated = { ...settings, libraryMenus: [...settings.libraryMenus, menu] };
    await saveSettings(updated);
    setSettings(updated);
    return menu;
  }, [settings]);

  const removeLibraryMenu = useCallback(async (id: string) => {
    const updatedSettings = { ...settings, libraryMenus: settings.libraryMenus.filter((menu) => menu.id !== id) };
    const updatedDecks = decks.map((deck) => deck.menuId === id ? { ...deck, menuId: null, updatedAt: new Date().toISOString() } : deck);
    await Promise.all([saveSettings(updatedSettings), ...updatedDecks.filter((deck) => deck.menuId === null && decks.find((item) => item.id === deck.id)?.menuId === id).map((deck) => saveDeck(deck))]);
    setSettings(updatedSettings);
    setDecks(updatedDecks);
  }, [decks, settings]);

  const addDeck = useCallback(async (name: string, description?: string, menuId?: string | null, language: StudyLanguage = "ja") => {
    const cleanName = name.trim();
    if (!cleanName) return null;
    const compatibleMenuId = settings.libraryMenus.some((menu) => menu.id === menuId && (menu.language ?? "ja") === language)
      ? menuId ?? null
      : settings.libraryMenus.find((menu) => (menu.language ?? "ja") === language)?.id ?? null;
    const deck: Deck = { id: createId(), name: cleanName, language, menuId: compatibleMenuId, description, dailyNewLimit: 20, dailyReviewLimit: 50, relearningStepsMinutes: [...defaultSettings.relearningStepsMinutes], reviewIntervals: [{ value: 10, unit: "minutes" }, { value: 1, unit: "days" }, { value: 4, unit: "days" }, { value: 7, unit: "days" }, { value: 10, unit: "days" }, { value: 15, unit: "days" }, { value: 20, unit: "days" }], dailyGroupCount: 5, wordsPerGroup: 10, order: "due_first", learningMode: "TYPE_ANSWER", reviewMode: "TYPE_ANSWER", autoSpeak: false, voice: "natural", createdAt: new Date().toISOString(), lastStudiedAt: null };
    await saveDeck(deck);
    setDecks((current) => [...current, deck]);
    return deck;
  }, [settings.libraryMenus]);

  const updateDeck = useCallback(async (deck: Deck) => {
    const compatibleMenuId = settings.libraryMenus.some((menu) => menu.id === deck.menuId && (menu.language ?? "ja") === deck.language)
      ? deck.menuId
      : settings.libraryMenus.find((menu) => (menu.language ?? "ja") === deck.language)?.id ?? null;
    const updated = { ...deck, menuId: compatibleMenuId, updatedAt: new Date().toISOString() };
    await saveDeck(updated);
    setDecks((current) => current.map((item) => item.id === updated.id ? updated : item));
  }, [settings.libraryMenus]);

  const removeDeck = useCallback(async (id: string, deleteOnlyWords: boolean) => {
    const related = words.filter((word) => word.deckIds.includes(id));
    await deleteStoredDeck(id);
    if (deleteOnlyWords) {
      await Promise.all(related.map((word) => deleteStoredWord(word.id)));
      setWords((current) => current.filter((word) => !word.deckIds.includes(id)));
    } else {
      const remainingWords = related.map((word) => ({ ...word, deckIds: word.deckIds.filter((deckId) => deckId !== id) }));
      await Promise.all(remainingWords.map((word) => saveWord(word)));
      setWords((current) => current.map((word) => word.deckIds.includes(id) ? { ...word, deckIds: word.deckIds.filter((deckId) => deckId !== id) } : word));
    }
    setDecks((current) => current.filter((deck) => deck.id !== id));
  }, [words]);

  const markWordAudio = useCallback(async (wordId: string, field: "wordGeneratedAt" | "kanaGeneratedAt" | "exampleGeneratedAt", voice: Deck["voice"] = "natural") => {
    const current = words.find((word) => word.id === wordId);
    if (!current) return;
    const updated = { ...current, audio: { ...current.audio, [field]: new Date().toISOString(), voice } };
    await saveWord(updated);
    setWords((items) => items.map((word) => word.id === wordId ? updated : word));
  }, [words]);

  const reviewWord = useCallback(async (word: WordCard, rating: Rating, responseTimeMs?: number, deckId?: string) => {
    const activeDeck = deckId ? decks.find((deck) => deck.id === deckId) : decks.find((deck) => word.deckIds.includes(deck.id));
    const result = calculateNextReview(word, rating, new Date(), activeDeck?.relearningStepsMinutes ?? settings.relearningStepsMinutes, activeDeck?.reviewIntervals);
    const reviewedAt = new Date().toISOString();
    const key = canonicalKey(word);
    const review: ReviewRecord = {
      id: createId(),
      wordId: word.id,
      rating,
      reviewedAt,
      previousInterval: word.interval,
      newInterval: result.interval,
      wasNew: word.status === "NEW",
      responseTimeMs,
      canonicalKey: key,
    };
    const sameWordCards = words.filter((item) => canonicalKey(item) === key);
    const syncedReviews = sameWordCards.map((item) => item.id === word.id ? review : { ...review, id: createId(), wordId: item.id });
    const syncedCards = sameWordCards.map((item) => {
      const itemReview = syncedReviews.find((itemReview) => itemReview.wordId === item.id) ?? review;
      return {
        ...item,
        ...result,
        lastReview: reviewedAt,
        reviewHistory: [...item.reviewHistory, itemReview],
      };
    });
    const deckIds = [...new Set(syncedCards.flatMap((item) => item.deckIds))];
    const deckUpdates = decks.filter((deck) => deckIds.includes(deck.id)).map((deck) => ({ ...deck, lastStudiedAt: reviewedAt, updatedAt: reviewedAt }));
    await Promise.all([...syncedCards.map((item) => saveWord(item)), ...syncedReviews.map((itemReview) => saveReview(itemReview)), ...deckUpdates.map((deck) => saveDeck(deck))]);
    setWords((current) => current.map((item) => syncedCards.find((synced) => synced.id === item.id) ?? item));
    setReviews((current) => [...current, ...syncedReviews]);
    setDecks((current) => current.map((deck) => deckUpdates.find((item) => item.id === deck.id) ?? deck));
    return syncedCards.find((item) => item.id === word.id) ?? { ...word, ...result, lastReview: reviewedAt };
  }, [decks, settings.relearningStepsMinutes, words]);

  const markWordMastered = useCallback(async (word: WordCard) => {
    const key = canonicalKey(word);
    const updatedCards = words
      .filter((item) => canonicalKey(item) === key)
      .map((item) => createMasteredWord(item));
    if (!updatedCards.length) return word;
    await Promise.all(updatedCards.map((item) => saveWord(item)));
    setWords((current) => current.map((item) => updatedCards.find((updated) => updated.id === item.id) ?? item));
    return updatedCards.find((item) => item.id === word.id) ?? word;
  }, [words]);

  const now = new Date();
  const due = useMemo(() => words.filter((word) => word.status !== "NEW" && word.status !== "SUSPENDED" && isDue(word, now)), [words]);
  const fresh = useMemo(() => words.filter((word) => word.status === "NEW"), [words]);
  const learning = useMemo(() => words.filter((word) => word.status === "LEARNING" || word.status === "RELEARNING"), [words]);
  const uniqueByCanonical = (items: WordCard[]) => {
    const seen = new Set<string>();
    return items.filter((item) => {
      const key = canonicalKey(item);
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  };
  const queue = useMemo(() => {
    const dueItems = settings.order === "new_first" ? [] : uniqueByCanonical(due).slice(0, settings.dailyReviewLimit);
    const plannedNewItems = decks.flatMap((deck) =>
      uniqueByCanonical(
        fresh.filter((word) => word.deckIds.includes(deck.id)),
      ).slice(0, Math.max(0, deck.dailyNewLimit)),
    );
    const newItems = uniqueByCanonical([
      ...plannedNewItems,
      ...fresh.filter((word) => !word.deckIds.some((deckId) => decks.some((deck) => deck.id === deckId))),
    ]);
    const dueKeys = new Set(dueItems.map(canonicalKey));
    const learningItems = uniqueByCanonical(learning.filter((word) => !dueKeys.has(canonicalKey(word)))).slice(0, settings.dailyReviewLimit);
    const combined = settings.order === "new_first" ? [...newItems, ...dueItems, ...learningItems] : [...dueItems, ...learningItems, ...newItems];
    if (settings.order === "random") return [...combined].sort(() => Math.random() - 0.5);
    return combined;
  }, [due, fresh, learning, settings]);
  const todayKey = dateKey(new Date());
  const todayReviews = useMemo(() => reviews.filter((review) => dateKey(new Date(review.reviewedAt)) === todayKey), [reviews, todayKey]);
  const newLearnedToday = useMemo(() => {
    const wordKeys = new Map(words.map((word) => [word.id, canonicalKey(word)]));
    const firstReviewByWord = new Map<string, ReviewRecord>();
    for (const review of [...reviews].sort((a, b) => a.reviewedAt.localeCompare(b.reviewedAt))) {
      const key = review.canonicalKey ?? wordKeys.get(review.wordId) ?? review.wordId;
      if (!firstReviewByWord.has(key)) firstReviewByWord.set(key, review);
    }
    const learnedKeys = new Set<string>();
    for (const review of todayReviews) {
      const key = review.canonicalKey ?? wordKeys.get(review.wordId) ?? review.wordId;
      const isLegacyFirstReview = review.wasNew === undefined && firstReviewByWord.get(key)?.id === review.id;
      if (review.wasNew || isLegacyFirstReview) learnedKeys.add(key);
    }
    return learnedKeys.size;
  }, [reviews, todayReviews, words]);

  const value = useMemo<AppStateValue>(() => ({
    ready,
    words,
    decks,
    reviews,
    localAssets,
    settings,
    updateSettings,
    saveLocalAsset,
    removeLocalAsset,
    addLibraryMenu,
    removeLibraryMenu,
    upsertWord,
    relearnWords,
    removeWord,
    addDeck,
    updateDeck,
    removeDeck,
    markWordAudio,
    reviewWord,
    markWordMastered,
    queue,
    dueCount: due.length,
    newCount: fresh.length,
    completedToday: todayReviews.length,
    todayReviews,
    newLearnedToday,
    streak: computeStreak(reviews),
  }), [ready, words, decks, reviews, localAssets, settings, updateSettings, saveLocalAsset, removeLocalAsset, addLibraryMenu, removeLibraryMenu, upsertWord, relearnWords, removeWord, addDeck, updateDeck, removeDeck, markWordAudio, reviewWord, markWordMastered, queue, due.length, fresh.length, todayReviews, newLearnedToday]);

  return <AppStateContext.Provider value={value}>{children}</AppStateContext.Provider>;
}

export function useAppState() {
  const value = useContext(AppStateContext);
  if (!value) throw new Error("useAppState must be used within AppStateProvider");
  return value;
}
