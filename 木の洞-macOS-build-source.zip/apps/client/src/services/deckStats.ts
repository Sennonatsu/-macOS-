import { isDue } from "./scheduler";
import type { Deck, ReviewRecord, WordCard } from "@/types";

export interface DeckStats {
  total: number;
  unseen: number;
  learning: number;
  learned: number;
  mature: number;
  due: number;
  todayNew: number;
  todayReviews: number;
  progress: number;
  estimatedDays: number;
  last7Average: number;
}

const dayKey = (date: Date) => date.toISOString().slice(0, 10);

export function getDeckStats(deck: Deck, words: WordCard[], reviews: ReviewRecord[], now = new Date()): DeckStats {
  const inDeck = words.filter((word) => word.deckIds.includes(deck.id));
  const total = inDeck.length;
  const unseen = inDeck.filter((word) => word.status === "NEW").length;
  const learning = inDeck.filter((word) => word.status === "LEARNING" || word.status === "RELEARNING").length;
  const learned = total - unseen;
  const mature = inDeck.filter((word) => word.status === "MATURE").length;
  const due = inDeck.filter((word) => word.status !== "NEW" && isDue(word, now)).length;
  const today = dayKey(now);
  const todayNew = reviews.filter((review) => review.reviewedAt.slice(0, 10) === today && review.previousInterval === 0 && inDeck.some((word) => word.id === review.wordId)).length;
  const todayReviews = reviews.filter((review) => review.reviewedAt.slice(0, 10) === today && inDeck.some((word) => word.id === review.wordId)).length;
  const recentCounts: number[] = [];
  for (let offset = 0; offset < 7; offset += 1) {
    const date = new Date(now);
    date.setDate(date.getDate() - offset);
    const key = dayKey(date);
    recentCounts.push(reviews.filter((review) => review.reviewedAt.slice(0, 10) === key && inDeck.some((word) => word.id === review.wordId)).length);
  }
  const last7Average = recentCounts.reduce((sum, count) => sum + count, 0) / 7;
  const configuredCapacity = Math.max(1, deck.dailyNewLimit);
  const dailyCapacity = Math.max(1, Math.min(configuredCapacity, Math.round(last7Average || configuredCapacity)));
  const estimatedDays = unseen === 0 ? 0 : Math.ceil(unseen / dailyCapacity);
  return { total, unseen, learning, learned, mature, due, todayNew, todayReviews, progress: total ? Math.round((learned / total) * 100) : 0, estimatedDays, last7Average };
}
