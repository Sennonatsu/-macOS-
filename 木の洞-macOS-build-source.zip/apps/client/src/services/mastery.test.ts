import { describe, expect, it } from "vitest";
import { createMasteredWord } from "./mastery";
import type { WordCard } from "@/types";

const sampleWord: WordCard = {
  id: "word-1",
  language: "ja",
  word: "食べる",
  kana: "たべる",
  meaning: "吃",
  partOfSpeech: "动词",
  example: "",
  exampleTranslation: "",
  tags: [],
  deckIds: ["deck-1"],
  status: "NEW",
  difficulty: 2.5,
  stability: 0,
  repetitions: 0,
  interval: 0,
  dueDate: null,
  lastReview: null,
  createdAt: "2026-09-30T00:00:00.000Z",
  reviewHistory: [],
  favorite: true,
  note: "熟词",
};

describe("createMasteredWord", () => {
  it("marks a word as mature without adding a review record or losing notes", () => {
    const now = new Date("2026-09-30T12:00:00.000Z");
    const result = createMasteredWord(sampleWord, now);

    expect(result.status).toBe("MATURE");
    expect(result.interval).toBe(21);
    expect(result.dueDate).toBe("2026-10-21T12:00:00.000Z");
    expect(result.reviewHistory).toEqual([]);
    expect(result.favorite).toBe(true);
    expect(result.note).toBe("熟词");
  });
});
