import { SAMPLE_DECK, SAMPLE_WORDS } from "@/data/sampleWords";
import type { AppSettings, Deck, LibraryMenu, LocalAsset, NavigationItemId, ReviewInterval, ReviewRecord, WordCard } from "@/types";

const DB_NAME = "kotoba-srs";
let activeDatabaseName = DB_NAME;
const DB_VERSION = 2;
const stores = ["words", "decks", "reviews", "settings", "assets"] as const;
const defaultNavigationOrder: NavigationItemId[] = ["library", "study", "review", "calendar", "notes", "settings"];

const defaultSettings: AppSettings = {
  dailyNewLimit: 20,
  dailyReviewLimit: 50,
  order: "due_first",
  defaultMode: "JP_TO_CN",
  theme: "light",
  colorStyle: "low_saturation",
  accentColor: "blue",
  accentFollowColorStyle: true,
  voice: "natural",
  uiScale: 1,
  skipRelearnConfirmation: false,
  skipDeleteConfirmation: false,
  reviewAlgorithm: "SM2",
  relearningStepsMinutes: [10, 60, 1440],
  libraryMenus: [
    { id: "menu-japanese", name: "日语", shortLabel: "日", language: "ja", createdAt: "2026-01-01T00:00:00.000Z" },
    { id: "menu-english", name: "英语", shortLabel: "英", language: "en", createdAt: "2026-01-01T00:00:00.000Z" },
  ],
  navigationOrder: defaultNavigationOrder,
  navigationExpanded: { library: true, study: false, review: false, notes: false },
  account: { displayName: "", email: "", signedIn: false },
};
export const DEFAULT_REVIEW_INTERVALS: ReviewInterval[] = [
  { value: 10, unit: "minutes" },
  { value: 1, unit: "days" },
  { value: 4, unit: "days" },
  { value: 7, unit: "days" },
  { value: 10, unit: "days" },
  { value: 15, unit: "days" },
  { value: 20, unit: "days" },
];

const hasIndexedDB = () => typeof window !== "undefined" && "indexedDB" in window;

function getDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (!hasIndexedDB()) return reject(new Error("IndexedDB unavailable"));
    const request = window.indexedDB.open(activeDatabaseName, DB_VERSION);
    request.onerror = () => reject(request.error ?? new Error("Unable to open database"));
    request.onupgradeneeded = () => {
      const db = request.result;
      stores.forEach((store) => {
        if (!db.objectStoreNames.contains(store)) {
          db.createObjectStore(store, { keyPath: store === "settings" ? "id" : "id" });
        }
      });
    };
    request.onsuccess = () => resolve(request.result);
  });
}

async function transaction<T>(storeName: (typeof stores)[number], mode: IDBTransactionMode, action: (store: IDBObjectStore) => IDBRequest): Promise<T> {
  const db = await getDb();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, mode);
    const request = action(tx.objectStore(storeName));
    request.onsuccess = () => resolve(request.result as T);
    request.onerror = () => reject(request.error ?? new Error("IndexedDB operation failed"));
    tx.oncomplete = () => db.close();
    tx.onerror = () => reject(tx.error ?? new Error("IndexedDB transaction failed"));
  });
}

async function getAll<T>(storeName: (typeof stores)[number]): Promise<T[]> {
  return transaction<T[]>(storeName, "readonly", (store) => store.getAll());
}

async function put<T extends { id: string }>(storeName: (typeof stores)[number], value: T): Promise<void> {
  await transaction(storeName, "readwrite", (store) => store.put(value));
}

async function remove(storeName: (typeof stores)[number], id: string): Promise<void> {
  await transaction(storeName, "readwrite", (store) => store.delete(id));
}

function id() {
  return typeof crypto !== "undefined" && "randomUUID" in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random()}`;
}

export async function bootstrapStorage(): Promise<{ words: WordCard[]; decks: Deck[]; reviews: ReviewRecord[]; settings: AppSettings; assets: LocalAsset[] }> {
  try {
    const [words, decks, reviews, settingsRows, assets] = await Promise.all([
      getAll<WordCard>("words"),
      getAll<Deck>("decks"),
      getAll<ReviewRecord>("reviews"),
      getAll<AppSettings & { id: string }>("settings"),
      getAll<LocalAsset>("assets"),
    ]);
    const normalizedSettings = normalizeSettings(settingsRows[0] ?? defaultSettings);
    const normalizedDecks = decks
      .map((deck) => normalizeDeck(deck))
      .map((deck) => alignDeckMenu(deck, normalizedSettings.libraryMenus));
    const normalizedWords = words.map((word) => normalizeWord(word, normalizedDecks));
    if (!decks.length) await put("decks", SAMPLE_DECK);
    if (!words.length) await Promise.all(SAMPLE_WORDS.map((word) => put("words", word)));
    if (words.length) await Promise.all(normalizedWords.map((word) => put("words", word)));
    if (decks.length) await Promise.all(normalizedDecks.map((deck) => put("decks", deck)));
    await put("settings", { ...normalizedSettings, id: "app" });
    return {
      words: words.length ? normalizedWords : SAMPLE_WORDS,
      decks: decks.length ? normalizedDecks : [SAMPLE_DECK],
      reviews,
      settings: normalizedSettings,
      assets,
    };
  } catch {
    const raw = window.localStorage.getItem("kotoba-srs-fallback");
    if (raw) {
      const parsed = JSON.parse(raw) as { words: WordCard[]; decks: Deck[]; reviews: ReviewRecord[]; settings: AppSettings };
      const normalizedSettings = normalizeSettings(parsed.settings);
      const normalizedDecks = parsed.decks
        .map((deck) => normalizeDeck(deck))
        .map((deck) => alignDeckMenu(deck, normalizedSettings.libraryMenus));
      const snapshot = {
        words: parsed.words.map((word) => normalizeWord(word, normalizedDecks)),
        decks: normalizedDecks,
        reviews: parsed.reviews,
        settings: normalizedSettings,
      };
      window.localStorage.setItem("kotoba-srs-fallback", JSON.stringify(snapshot));
      return { ...snapshot, assets: [] };
    }
    return { words: SAMPLE_WORDS, decks: [SAMPLE_DECK], reviews: [], settings: defaultSettings, assets: [] };
  }
}

function normalizeSettings(settings: Partial<AppSettings>): AppSettings {
  const normalizedMenus = Array.isArray(settings.libraryMenus)
    ? settings.libraryMenus
        .filter((menu) => menu && typeof menu.id === "string" && typeof menu.name === "string")
        .map((menu) => ({
          id: menu.id,
          name: menu.name.trim(),
          shortLabel: menu.shortLabel?.trim() || menu.name.trim().slice(0, 1) || "词",
          language: menu.language === "en" || /英|English/i.test(menu.name) ? "en" as const : "ja" as const,
          createdAt: menu.createdAt ?? new Date().toISOString(),
        }))
    : defaultSettings.libraryMenus;
  let defaultEnglishMenuId = "menu-english";
  while (normalizedMenus.some((menu) => menu.id === defaultEnglishMenuId)) {
    defaultEnglishMenuId += "-default";
  }
  const libraryMenus = normalizedMenus.some((menu) => menu.language === "en")
    ? normalizedMenus
    : [...normalizedMenus, { id: defaultEnglishMenuId, name: "英语", shortLabel: "英", language: "en" as const, createdAt: new Date().toISOString() }];
  const requestedOrder = Array.isArray(settings.navigationOrder)
    ? (settings.navigationOrder as string[]).map((item) => item === "search" ? "notes" : item)
    : [];
  const navigationOrder = [
    ...requestedOrder.filter((item): item is NavigationItemId => defaultNavigationOrder.includes(item as NavigationItemId)),
    ...defaultNavigationOrder.filter((item) => !requestedOrder.includes(item)),
  ].filter((item, index, items) => items.indexOf(item) === index);
  const navigationExpanded = {
    ...defaultSettings.navigationExpanded,
    ...(settings.navigationExpanded ?? {}),
  };
  const accentColors: AppSettings["accentColor"][] = ["blue", "green", "teal", "indigo", "violet", "rose", "coral", "amber", "black", "gray"];
  return {
    ...defaultSettings,
    ...settings,
    colorStyle: settings.colorStyle === "standard" || settings.colorStyle === "minimal"
      ? settings.colorStyle
      : "low_saturation",
    accentColor: accentColors.includes(settings.accentColor as AppSettings["accentColor"])
      ? settings.accentColor as AppSettings["accentColor"]
      : defaultSettings.accentColor,
    accentFollowColorStyle: settings.accentFollowColorStyle !== false,
    voice: settings.voice ?? defaultSettings.voice,
    uiScale: settings.uiScale === 0.9 || settings.uiScale === 1.1 || settings.uiScale === 1.2 ? settings.uiScale : defaultSettings.uiScale,
    reviewAlgorithm: "SM2",
    relearningStepsMinutes: settings.relearningStepsMinutes?.length ? settings.relearningStepsMinutes : defaultSettings.relearningStepsMinutes,
    libraryMenus,
    navigationOrder,
    navigationExpanded,
    account: { ...defaultSettings.account, ...(settings.account ?? {}) },
    skipRelearnConfirmation: settings.skipRelearnConfirmation === true,
    skipDeleteConfirmation: settings.skipDeleteConfirmation === true,
  };
}

function normalizeWord(word: WordCard & { deckId?: string }, decks: Deck[]): WordCard {
  const deckIds = Array.isArray(word.deckIds) && word.deckIds.length
    ? word.deckIds
    : word.deckId
      ? [word.deckId]
      : [];
  const deckLanguage = decks.find((deck) => deckIds.includes(deck.id))?.language;
  return { ...word, deckIds, language: word.language === "en" ? "en" : deckLanguage ?? "ja" };
}

function normalizeDeck(deck: Partial<Deck> & Pick<Deck, "id" | "name">): Deck {
  const hasMenuId = Object.prototype.hasOwnProperty.call(deck, "menuId");
  const reviewIntervals = Array.isArray(deck.reviewIntervals)
    ? DEFAULT_REVIEW_INTERVALS.map((fallback, index) => {
        const candidate = deck.reviewIntervals?.[index];
        if (!candidate || !Number.isFinite(candidate.value) || candidate.value <= 0) return fallback;
        const unit = candidate.unit === "hours" || candidate.unit === "days" ? candidate.unit : "minutes";
        return { value: candidate.value, unit } as ReviewInterval;
      })
    : DEFAULT_REVIEW_INTERVALS.map((interval) => ({ ...interval }));
  return {
    id: deck.id,
    name: deck.name,
    language: deck.language === "en" ? "en" : "ja",
    menuId: hasMenuId ? deck.menuId ?? null : "menu-japanese",
    description: deck.description,
    coverDataUrl: deck.coverDataUrl,
    dailyNewLimit: deck.dailyNewLimit ?? 20,
    dailyReviewLimit: deck.dailyReviewLimit ?? 50,
    relearningStepsMinutes: deck.relearningStepsMinutes?.length
      ? deck.relearningStepsMinutes
      : defaultSettings.relearningStepsMinutes,
    reviewIntervals,
    dailyGroupCount: deck.dailyGroupCount ?? 5,
    wordsPerGroup: deck.wordsPerGroup ?? 10,
    wordFormLabels: Array.isArray(deck.wordFormLabels)
      ? deck.wordFormLabels.filter((label): label is string => typeof label === "string" && Boolean(label.trim())).map((label) => label.trim())
      : [],
    units: Array.isArray(deck.units) ? deck.units : [],
    order: deck.order ?? "due_first",
    learningMode: deck.learningMode === "LISTENING" ? "LISTENING" : "TYPE_ANSWER",
    reviewMode: deck.reviewMode === "LISTENING" ? "LISTENING" : "TYPE_ANSWER",
    autoSpeak: deck.autoSpeak ?? false,
    voice: deck.voice ?? "natural",
    createdAt: deck.createdAt ?? new Date().toISOString(),
    updatedAt: deck.updatedAt,
    lastStudiedAt: deck.lastStudiedAt ?? null,
  };
}

function alignDeckMenu(deck: Deck, menus: LibraryMenu[]): Deck {
  if (!deck.menuId) return deck;
  const currentMenu = menus.find((menu) => menu.id === deck.menuId);
  if ((currentMenu?.language ?? "ja") === deck.language) return deck;
  const compatibleMenu = menus.find((menu) => (menu.language ?? "ja") === deck.language);
  return { ...deck, menuId: compatibleMenu?.id ?? null };
}

export async function saveWord(word: WordCard) {
  await put("words", word);
}
export async function deleteWord(idValue: string) {
  await remove("words", idValue);
}
export async function deleteReview(idValue: string) {
  await remove("reviews", idValue);
}
export async function saveDeck(deck: Deck) {
  await put("decks", deck);
}
export async function deleteDeck(id: string) {
  await remove("decks", id);
}
export async function saveReview(review: ReviewRecord) {
  await put("reviews", review);
}
export async function saveSettings(settings: AppSettings) {
  await put("settings", { ...settings, id: "app" });
}
export async function saveLocalAsset(asset: LocalAsset) {
  await put("assets", asset);
}
export async function deleteLocalAsset(idValue: string) {
  await remove("assets", idValue);
}

export async function persistSnapshot(snapshot: { words: WordCard[]; decks: Deck[]; reviews: ReviewRecord[]; settings: AppSettings }) {
  try {
    await Promise.all([
      ...snapshot.words.map((word) => put("words", word)),
      ...snapshot.decks.map((deck) => put("decks", deck)),
      ...snapshot.reviews.map((review) => put("reviews", review)),
      put("settings", { ...snapshot.settings, id: "app" }),
    ]);
  } catch {
    window.localStorage.setItem("kotoba-srs-fallback", JSON.stringify(snapshot));
  }
}

export async function readCurrentSnapshot() {
  const [words, decks, reviews, settingsRows] = await Promise.all([
    getAll<WordCard>("words"),
    getAll<Deck>("decks"),
    getAll<ReviewRecord>("reviews"),
    getAll<AppSettings & { id: string }>("settings"),
  ]);
  const settings = normalizeSettings(settingsRows[0] ?? defaultSettings);
  return { words, decks, reviews, settings };
}

export async function mergePortableSnapshot(snapshot: {
  words: WordCard[];
  decks: Deck[];
  reviews: ReviewRecord[];
  settings: AppSettings;
}) {
  const current = await readCurrentSnapshot();
  const mergeById = <T extends { id: string }>(existing: T[], incoming: T[]) => {
    const merged = new Map(existing.map((item) => [item.id, item]));
    incoming.forEach((item) => merged.set(item.id, item));
    return [...merged.values()];
  };
  const decks = mergeById(current.decks, snapshot.decks).map((deck) => normalizeDeck(deck));
  const normalizedSettings = normalizeSettings({ ...current.settings, ...snapshot.settings });
  const normalizedDecks = decks.map((deck) => alignDeckMenu(deck, normalizedSettings.libraryMenus));
  const merged = {
    words: mergeById(current.words, snapshot.words).map((word) => normalizeWord(word, normalizedDecks)),
    decks: normalizedDecks,
    reviews: mergeById(current.reviews, snapshot.reviews),
    settings: normalizedSettings,
  };
  await persistSnapshot(merged);
  return {
    words: merged.words.length,
    decks: merged.decks.length,
    reviews: merged.reviews.length,
  };
}

export function createId() {
  return id();
}

export function setStorageScope(userId?: string | null) {
  const safeId = userId?.replace(/[^a-zA-Z0-9_-]/g, "");
  activeDatabaseName = safeId ? `${DB_NAME}-user-${safeId}` : DB_NAME;
}

export async function deleteStorageScope(userId: string) {
  if (!hasIndexedDB()) return;
  const safeId = userId.replace(/[^a-zA-Z0-9_-]/g, "");
  if (!safeId) return;
  const databaseName = `${DB_NAME}-user-${safeId}`;
  await new Promise<void>((resolve, reject) => {
    const request = window.indexedDB.deleteDatabase(databaseName);
    request.onsuccess = () => resolve();
    request.onerror = () => reject(request.error ?? new Error("Unable to delete account database"));
    request.onblocked = () => reject(new Error("Account database is currently in use"));
  });
}

export { defaultSettings };
