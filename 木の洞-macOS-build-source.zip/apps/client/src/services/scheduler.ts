import type { Rating, ReviewInterval, SchedulerResult, WordCard } from "@/types";

const DAY = 24 * 60 * 60 * 1000;
const MINUTE = 60 * 1000;

const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));

export function intervalToMilliseconds(interval: ReviewInterval): number {
  const unit = interval.unit === "days" ? DAY : interval.unit === "hours" ? 60 * MINUTE : MINUTE;
  return Math.max(1, interval.value) * unit;
}

export function calculateNextReview(
  card: WordCard,
  rating: Rating,
  now = new Date(),
  relearningStepsMinutes = [10, 60, 1440],
  reviewIntervals?: ReviewInterval[],
): SchedulerResult {
  const firstReview = card.repetitions === 0;
  let difficulty = card.difficulty || 2.5;
  let stability = card.stability || 0;
  let repetitions = card.repetitions;
  let interval = card.interval;
  let status = card.status;
  const currentCycle = Math.min(7, Math.max(0, card.reviewCycle ?? card.repetitions));
  let reviewCycle = currentCycle;

  if (rating === "AGAIN") {
    difficulty = clamp(difficulty + 0.25, 1.3, 5);
    stability = Math.max(0.5, stability * 0.45 || 0.5);
    interval = firstReview ? 0 : Math.max(0, Math.round(interval * 0.2));
    repetitions = 0;
    reviewCycle = Math.max(1, currentCycle);
    status = card.status === "REVIEW" || card.status === "MATURE" ? "RELEARNING" : "LEARNING";
  } else {
    const ease = rating === "EASY" ? 1.35 : rating === "HARD" ? 1.12 : 1.0;
    const quality = rating === "EASY" ? 5 : rating === "GOOD" ? 4 : 3;
    difficulty = clamp(difficulty + (quality < 4 ? 0.15 : -0.1), 1.3, 5);
    if (reviewIntervals?.length) {
      const target = reviewIntervals[Math.min(6, currentCycle)] ?? reviewIntervals[reviewIntervals.length - 1];
      interval = Math.max(1, Math.round(intervalToMilliseconds(target) / DAY));
      stability = Math.max(stability, interval);
    } else if (firstReview) {
      interval = rating === "HARD" ? 1 : rating === "EASY" ? 4 : 1;
      stability = rating === "EASY" ? 4 : rating === "HARD" ? 1.5 : 2;
    } else {
      const multiplier = (2.5 - difficulty / 10) * ease;
      interval = Math.max(1, Math.round(interval * multiplier));
      stability = Math.max(stability + 0.5, stability * (rating === "HARD" ? 1.15 : rating === "EASY" ? 1.55 : 1.35));
    }
    repetitions += 1;
    reviewCycle = Math.min(7, currentCycle + 1);
    status = interval >= 21 ? "MATURE" : "REVIEW";
  }

  const previousAgains = [...(card.reviewHistory ?? [])].reverse().findIndex((review) => review.rating !== "AGAIN");
  const againStepIndex = previousAgains === -1
    ? Math.min((card.reviewHistory ?? []).length, relearningStepsMinutes.length - 1)
    : Math.min(0, relearningStepsMinutes.length - 1);
  const againMinutes = Math.max(1, relearningStepsMinutes[againStepIndex] ?? relearningStepsMinutes[0] ?? 10);
  const targetReviewInterval = reviewIntervals?.length && rating !== "AGAIN"
    ? reviewIntervals[Math.min(6, currentCycle)] ?? reviewIntervals[reviewIntervals.length - 1]
    : undefined;
  const due = new Date(now.getTime() + (rating === "AGAIN" ? againMinutes * MINUTE : targetReviewInterval ? intervalToMilliseconds(targetReviewInterval) : interval * DAY));
  return {
    interval,
    dueDate: due.toISOString(),
    difficulty: Number(difficulty.toFixed(2)),
    stability: Number(stability.toFixed(2)),
    repetitions,
    reviewCycle,
    status,
  };
}

export function previewInterval(card: WordCard, rating: Rating, now = new Date(), relearningStepsMinutes = [10, 60, 1440]): string {
  const result = calculateNextReview(card, rating, now, relearningStepsMinutes);
  const diff = new Date(result.dueDate).getTime() - now.getTime();
  if (diff < DAY) return `${Math.max(1, Math.round(diff / MINUTE))}分钟后`;
  if (diff < 7 * DAY) return `${Math.round(diff / DAY)}天后`;
  return `${Math.round(diff / (7 * DAY))}周后`;
}

export function isDue(card: WordCard, now = new Date()): boolean {
  return card.status === "NEW" || !card.dueDate || new Date(card.dueDate).getTime() <= now.getTime();
}

export function formatDueDate(date: string | null): string {
  if (!date) return "未安排";
  const diff = new Date(date).getTime() - Date.now();
  if (diff <= 0) return "现在";
  if (diff < DAY) return `${Math.max(1, Math.round(diff / MINUTE))}分钟后`;
  if (diff < 7 * DAY) return `${Math.round(diff / DAY)}天后`;
  return `${Math.round(diff / (7 * DAY))}周后`;
}
