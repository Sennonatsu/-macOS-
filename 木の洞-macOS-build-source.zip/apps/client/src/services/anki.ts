import initSqlJs from "sql.js";
import { unzipSync } from "fflate";
import type { StudyLanguage } from "@/types";

export type AnkiTargetField =
  | "word"
  | "kana"
  | "meaning"
  | "example"
  | "exampleTranslation"
  | "audio"
  | "ignore";

export interface AnkiFieldMapping {
  word: string;
  kana: string;
  meaning: string;
  example: string;
  exampleTranslation: string;
  audio: string;
}

export interface AnkiRecord {
  id: string;
  deckName: string;
  fields: Record<string, string>;
  tags: string[];
  sounds: string[];
  images: string[];
  language: StudyLanguage;
}

export interface AnkiMediaAsset {
  filename: string;
  data: Blob;
  mimeType: string;
  supported: boolean;
}

export interface AnkiImportData {
  fileName: string;
  deckNames: string[];
  fieldNames: string[];
  records: AnkiRecord[];
  media: AnkiMediaAsset[];
  mapping: AnkiFieldMapping;
  imageCount: number;
  unsupportedAudioCount: number;
}

const AUDIO_EXTENSIONS = new Set(["mp3", "wav", "m4a", "aac", "ogg", "webm", "flac"]);

function decodeText(bytes: Uint8Array) {
  return new TextDecoder("utf-8").decode(bytes);
}

function extension(filename: string) {
  return filename.split(".").pop()?.toLowerCase() ?? "";
}

function mimeFor(filename: string) {
  const ext = extension(filename);
  return {
    mp3: "audio/mpeg",
    wav: "audio/wav",
    m4a: "audio/mp4",
    aac: "audio/aac",
    ogg: "audio/ogg",
    webm: "audio/webm",
    flac: "audio/flac",
  }[ext] ?? "application/octet-stream";
}

function normalizeFieldName(value: string) {
  return value
    .normalize("NFKC")
    .toLocaleLowerCase()
    .replace(/[\s_\-()[\]{}:：/\\]+/g, "");
}

function stripHtml(value: string) {
  if (!value) return "";
  const withBreaks = value
    .replace(/<br\s*\/?>/gi, "\n")
    .replace(/<\/p>|<\/div>|<\/li>/gi, "\n");
  const withoutTags = withBreaks.replace(/<[^>]*>/g, "");
  const textarea = typeof document !== "undefined" ? document.createElement("textarea") : null;
  const decoded = textarea ? (() => {
    textarea.innerHTML = withoutTags;
    return textarea.value;
  })() : withoutTags.replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&lt;/gi, "<").replace(/&gt;/gi, ">");
  return decoded.replace(/\r\n/g, "\n").replace(/[ \t]+\n/g, "\n").trim();
}

function extractMedia(value: string) {
  const sounds = [...value.matchAll(/\[sound:([^\]]+)\]/gi)].map((match) => match[1].trim()).filter(Boolean);
  const images = [...value.matchAll(/<img[^>]+src=["']([^"']+)["']/gi)].map((match) => match[1].trim()).filter(Boolean);
  return { sounds, images, text: stripHtml(value.replace(/\[sound:[^\]]+\]/gi, "").replace(/<img[^>]*>/gi, "")) };
}

function looksJapanese(value: string) {
  return /[\u3040-\u30ff\u3400-\u9fff]/.test(value);
}

function inferLanguage(deckName: string, word: string, fallback: StudyLanguage) {
  if (/英語|英语|english|英単語|英文/i.test(deckName)) return "en";
  if (/日語|日语|japanese|日本語|日文/i.test(deckName)) return "ja";
  return looksJapanese(word) ? "ja" : fallback;
}

function scoreField(name: string, field: Exclude<AnkiTargetField, "ignore">) {
  const n = normalizeFieldName(name);
  const rules: Record<Exclude<AnkiTargetField, "ignore">, RegExp[]> = {
    word: [/word|expression|term|vocab|front|japanese|english|単語|日語|日文|英文|词/,
    ],
    kana: [/kana|reading|yomi|furigana|ruby|phonetic|假名|读音|読み|ふりがな|音标|音標/],
    meaning: [/meaning|definition|gloss|back|translation|translate|中文|释义|解釋|翻译|翻訳|意思/],
    example: [/example|sentence|context|例句|例文|用例/],
    exampleTranslation: [/example.*translation|sentence.*translation|例句.*翻译|例文.*訳|例句翻译/],
    audio: [/audio|sound|voice|pronunciation|发音|配音|音声|音频|音訊/],
  };
  return rules[field].reduce((score, rule) => score + (rule.test(n) ? 3 : 0), 0);
}

export function suggestAnkiMapping(fieldNames: string[]): AnkiFieldMapping {
  const pick = (field: Exclude<AnkiTargetField, "ignore">, excluded: string[] = []) => {
    const candidates = fieldNames
      .filter((name) => !excluded.includes(name))
      .map((name) => ({ name, score: scoreField(name, field) }))
      .sort((a, b) => b.score - a.score);
    return candidates[0]?.score ? candidates[0].name : "";
  };
  const word = pick("word");
  const kana = pick("kana", [word]);
  const meaning = pick("meaning", [word, kana]);
  const example = pick("example", [word, kana, meaning]);
  const exampleTranslation = pick("exampleTranslation", [word, kana, meaning, example]);
  const audio = pick("audio", [word, kana, meaning, example, exampleTranslation]);
  return { word, kana, meaning, example, exampleTranslation, audio };
}

async function initDatabase(data: Uint8Array) {
  const SQL = await initSqlJs({
    locateFile: () => new URL("sql.js/dist/sql-wasm.wasm", import.meta.url).toString(),
  });
  return new SQL.Database(data);
}

function getRows(database: { exec: (sql: string) => Array<{ columns: string[]; values: unknown[][] }> }) {
  const result = database.exec("SELECT id, mid, flds, tags FROM notes");
  if (!result.length) return [];
  const [table] = result;
  return table.values.map((values) => Object.fromEntries(table.columns.map((column, index) => [column, values[index]])));
}

function parseJson<T>(value: string | Uint8Array | null | undefined, fallback: T): T {
  if (!value) return fallback;
  try {
    return JSON.parse(typeof value === "string" ? value : decodeText(value)) as T;
  } catch {
    return fallback;
  }
}

export async function parseAnkiPackage(file: File, fallbackLanguage: StudyLanguage = "ja"): Promise<AnkiImportData> {
  const archive = unzipSync(new Uint8Array(await file.arrayBuffer()));
  const collectionEntry = archive["collection.anki21"] ?? archive["collection.anki2"];
  if (!collectionEntry) throw new Error("这个文件不是有效的 Anki .apkg 词库，未找到 collection.anki2。");
  const database = await initDatabase(collectionEntry);
  try {
    const collectionRows = database.exec("SELECT decks, models FROM col LIMIT 1");
    if (!collectionRows.length || !collectionRows[0].values.length) throw new Error("Anki 词库缺少 collection 数据。");
    const [decksJson, modelsJson] = collectionRows[0].values[0] as [string, string];
    const decks = parseJson<Record<string, { name?: string }>>(decksJson, {});
    const models = parseJson<Record<string, { flds?: Array<{ name?: string; ord?: number }> }>>(modelsJson, {});
    const notes = getRows(database);
    const fieldNames = [...new Set(Object.values(models).flatMap((model) => (model.flds ?? []).map((field) => field.name ?? "").filter(Boolean)))];
    const mapping = suggestAnkiMapping(fieldNames);
    const records: AnkiRecord[] = [];
    for (const note of notes) {
      const mid = String(note.mid ?? "");
      const model = models[mid];
      const modelFields = (model?.flds ?? []).sort((a, b) => (a.ord ?? 0) - (b.ord ?? 0)).map((field) => field.name ?? "");
      const values = String(note.flds ?? "").split("\u001f");
      const fields = Object.fromEntries(modelFields.map((name, index) => [name, values[index] ?? ""]));
      const deckIdRows = database.exec(`SELECT did FROM cards WHERE nid = ${Number(note.id) || 0} LIMIT 1`);
      const deckId = deckIdRows[0]?.values[0]?.[0];
      const deckName = decks[String(deckId)]?.name ?? "Anki 导入";
      const extracted = Object.values(fields).map(extractMedia);
      const sounds = [...new Set(extracted.flatMap((item) => item.sounds))];
      const images = [...new Set(extracted.flatMap((item) => item.images))];
      const wordCandidate = mapping.word ? extractMedia(fields[mapping.word] ?? "").text : Object.values(fields).map((value) => extractMedia(value).text).find(Boolean) ?? "";
      records.push({
        id: String(note.id ?? records.length),
        deckName,
        fields,
        tags: String(note.tags ?? "").split(/\s+/).map((tag) => tag.trim()).filter(Boolean),
        sounds,
        images,
        language: inferLanguage(deckName, wordCandidate, fallbackLanguage),
      });
    }
    const mediaMap = parseJson<Record<string, string>>(archive.media ? decodeText(archive.media) : "", {});
    const media: AnkiMediaAsset[] = Object.entries(mediaMap).map(([archiveName, originalName]) => {
      const bytes = archive[archiveName];
      if (!bytes) return null;
      const supported = AUDIO_EXTENSIONS.has(extension(originalName));
      return { filename: originalName, data: new Blob([bytes as BlobPart], { type: mimeFor(originalName) }), mimeType: mimeFor(originalName), supported };
    }).filter((item): item is AnkiMediaAsset => Boolean(item));
    const unsupportedAudioCount = media.filter((item) => !item.supported && AUDIO_EXTENSIONS.has(extension(item.filename))).length;
    return {
      fileName: file.name,
      deckNames: [...new Set(records.map((record) => record.deckName))],
      fieldNames,
      records,
      media,
      mapping,
      imageCount: records.reduce((count, record) => count + record.images.length, 0),
      unsupportedAudioCount,
    };
  } finally {
    database.close();
  }
}

export function mapAnkiRecord(record: AnkiRecord, mapping: AnkiFieldMapping) {
  const value = (field: string) => field ? extractMedia(record.fields[field] ?? "").text : "";
  const allSounds = [...new Set([
    ...(mapping.audio ? extractMedia(record.fields[mapping.audio] ?? "").sounds : []),
    ...record.sounds,
  ])];
  return {
    word: value(mapping.word) || value(Object.keys(record.fields)[0] ?? ""),
    kana: value(mapping.kana),
    meaning: value(mapping.meaning),
    example: value(mapping.example),
    exampleTranslation: value(mapping.exampleTranslation),
    tags: record.tags,
    sounds: allSounds,
    language: record.language,
    deckName: record.deckName,
  };
}

export function resolveAnkiMedia(data: AnkiImportData, filename: string) {
  const normalized = filename.normalize("NFKC").toLocaleLowerCase();
  return data.media.find((asset) => asset.filename.normalize("NFKC").toLocaleLowerCase() === normalized);
}
