import { Check, FileAudio, Trash2, Type, Upload } from "lucide-react";
import { useMemo, useState, type ChangeEvent } from "react";
import { useAppState } from "@/services/AppState";
import { createId } from "@/services/storage";
import { normalizeAudioLookupKey } from "@/services/tts";
import type { LocalAsset, StudyLanguage } from "@/types";

export default function LocalAssetsSettings() {
  const {
    localAssets,
    settings,
    updateSettings,
    saveLocalAsset,
    removeLocalAsset,
  } = useAppState();
  const [audioLanguage, setAudioLanguage] = useState<StudyLanguage>("ja");
  const [notice, setNotice] = useState("");
  const fontAsset = localAssets.find(
    (asset) => asset.id === settings.customFontAssetId && asset.kind === "font",
  );
  const audioAssets = useMemo(
    () =>
      localAssets
        .filter(
          (asset) =>
            asset.kind === "word-audio" && asset.language === audioLanguage,
        )
        .sort((a, b) => b.importedAt.localeCompare(a.importedAt)),
    [audioLanguage, localAssets],
  );

  async function importFont(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (file.size > 20 * 1024 * 1024) {
      setNotice("字体文件不能超过 20 MB。");
      return;
    }
    const asset: LocalAsset = {
      id: createId(),
      kind: "font",
      name: file.name,
      mimeType: file.type || "font/unknown",
      data: file,
      importedAt: new Date().toISOString(),
    };
    const previousId = settings.customFontAssetId;
    await saveLocalAsset(asset);
    await updateSettings({ customFontAssetId: asset.id });
    if (previousId && previousId !== asset.id) await removeLocalAsset(previousId);
    setNotice(`已应用字体「${file.name}」。`);
  }

  async function clearFont() {
    const assetId = settings.customFontAssetId;
    await updateSettings({ customFontAssetId: undefined });
    if (assetId) await removeLocalAsset(assetId);
    setNotice("已恢复系统默认字体。");
  }

  async function importAudio(event: ChangeEvent<HTMLInputElement>) {
    const files = Array.from(event.target.files ?? []);
    event.target.value = "";
    if (!files.length) return;
    const oversized = files.find((file) => file.size > 25 * 1024 * 1024);
    if (oversized) {
      setNotice(`「${oversized.name}」超过 25 MB，未导入本批素材。`);
      return;
    }
    const known = new Map(audioAssets.map((asset) => [asset.lookupKey, asset]));
    let imported = 0;
    for (const file of files) {
      const fileWord = file.name.replace(/\.[^.]+$/, "").trim();
      const lookupKey = normalizeAudioLookupKey(fileWord);
      if (!lookupKey) continue;
      const existing = known.get(lookupKey);
      const asset: LocalAsset = {
        id: existing?.id ?? createId(),
        kind: "word-audio",
        name: file.name,
        mimeType: file.type || "audio/unknown",
        data: file,
        language: audioLanguage,
        lookupKey,
        importedAt: new Date().toISOString(),
      };
      await saveLocalAsset(asset);
      known.set(lookupKey, asset);
      imported += 1;
    }
    setNotice(
      imported
        ? `已导入 ${imported} 个${audioLanguage === "en" ? "英语" : "日语"}单词配音。`
        : "没有找到可导入的音频文件。",
    );
  }

  return (
    <>
      <div className="setting-section">
        <h2>自定义字体</h2>
        <div className="setting-row">
          <div>
            <strong>导入界面字体</strong>
            <span>支持 WOFF、WOFF2、TTF 或 OTF，导入后立即应用到整个界面</span>
          </div>
          <div className="asset-actions">
            {fontAsset && (
              <span className="asset-current">
                <Type size={14} /> {fontAsset.name}
              </span>
            )}
            <label className="button button-secondary compact file-button">
              <Upload size={15} /> {fontAsset ? "更换字体" : "导入字体"}
              <input
                type="file"
                accept=".woff,.woff2,.ttf,.otf,font/woff,font/woff2,font/ttf,font/otf"
                onChange={(event) => void importFont(event)}
              />
            </label>
            {fontAsset && (
              <button
                className="icon-button"
                onClick={() => void clearFont()}
                aria-label="删除自定义字体"
              >
                <Trash2 size={15} />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className="setting-section">
        <h2>外部 AI 配音素材</h2>
        <div className="audio-import-panel">
          <div className="audio-import-copy">
            <FileAudio size={18} />
            <div>
              <strong>导入单词配音</strong>
              <span>
                文件名需与单词完全一致，例如「食べる.mp3」或「remember.wav」。学习、复习和单词详情会优先播放导入素材。
              </span>
            </div>
          </div>
          <div className="audio-import-controls">
            <select
              value={audioLanguage}
              onChange={(event) =>
                setAudioLanguage(event.target.value as StudyLanguage)
              }
              aria-label="配音素材语言"
            >
              <option value="ja">日语素材</option>
              <option value="en">英语素材</option>
            </select>
            <label className="button button-primary compact file-button">
              <Upload size={15} /> 选择音频
              <input
                type="file"
                multiple
                accept=".mp3,.wav,.m4a,.aac,.ogg,.webm,audio/*"
                onChange={(event) => void importAudio(event)}
              />
            </label>
          </div>
          <div className="audio-asset-summary">
            <span>
              当前已保存 {audioAssets.length} 个
              {audioLanguage === "en" ? "英语" : "日语"}配音
            </span>
            <small>同名单词再次导入会自动替换；每个文件不超过 25 MB。</small>
          </div>
          {audioAssets.length > 0 && (
            <div className="audio-asset-list">
              {audioAssets.slice(0, 12).map((asset) => (
                <div key={asset.id}>
                  <span><FileAudio size={13} /> {asset.name}</span>
                  <button
                    className="icon-button"
                    onClick={() => void removeLocalAsset(asset.id)}
                    aria-label={`删除${asset.name}`}
                  >
                    <Trash2 size={13} />
                  </button>
                </div>
              ))}
              {audioAssets.length > 12 && (
                <small>另有 {audioAssets.length - 12} 个素材已保存</small>
              )}
            </div>
          )}
        </div>
        <p className="settings-note voice-note">
          字体和配音只保存在当前设备的 IndexedDB 中，不会上传。没有匹配素材时，自动使用设备的日语或英语声音。
        </p>
        {notice && <p className="asset-notice"><Check size={14} /> {notice}</p>}
      </div>
    </>
  );
}
