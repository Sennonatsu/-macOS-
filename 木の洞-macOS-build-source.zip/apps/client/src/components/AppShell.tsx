import { BookOpen, Brain, CalendarClock, CalendarDays, ChevronDown, ChevronRight, DoorOpen, GripVertical, ImagePlus, Leaf, NotebookPen, Plus, Settings2, Sparkles, Target, Trash2, UserPlus, X } from "lucide-react";
import { NavLink, useLocation, useNavigate, type NavLinkRenderProps } from "react-router-dom";
import { useEffect, useRef, useState, type MouseEvent as ReactMouseEvent, type PointerEvent as ReactPointerEvent, type ReactNode } from "react";
import { useAppState } from "@/services/AppState";
import { useKonohaAccount } from "@/services/KonohaAccount";
import { AccountAvatar } from "@/components/KonohaAccountGate";
import { getDeckStats } from "@/services/deckStats";
import type { NavigationFolderId, NavigationItemId } from "@/types";
import type { StudyLanguage } from "@/types";

const simpleNavItems = {
  calendar: { to: "/calendar", label: "日历", icon: CalendarDays },
  settings: { to: "/settings", label: "设置", icon: Settings2 },
} as const;

export default function AppShell({ children }: { children: ReactNode }) {
  const { words, decks, reviews, streak, settings, updateSettings, addLibraryMenu, removeLibraryMenu } = useAppState();
  const {
    desktop,
    accounts,
    currentAccount,
    setAddAccountOpen,
    switchAccount,
    logout,
    removeLocalAccount,
  } = useKonohaAccount();
  const location = useLocation();
  const navigate = useNavigate();
  const [expandedFolders, setExpandedFolders] = useState(settings.navigationExpanded);
  const [showMenuModal, setShowMenuModal] = useState(false);
  const [accountMenuOpen, setAccountMenuOpen] = useState(false);
  const [menuName, setMenuName] = useState("");
  const [menuLanguage, setMenuLanguage] = useState<StudyLanguage>("ja");
  const [menuError, setMenuError] = useState("");
  const [navigationOrder, setNavigationOrder] = useState<NavigationItemId[]>(settings.navigationOrder);
  const [draggingId, setDraggingId] = useState<NavigationItemId | null>(null);
  const longPressTimer = useRef<number | null>(null);
  const brandIconRef = useRef<HTMLInputElement>(null);
  const suppressClick = useRef(false);
  const navigationOrderRef = useRef(navigationOrder);
  const activeMenuId = new URLSearchParams(location.search).get("menu");
  const activeStudyDeckId = new URLSearchParams(location.search).get("deck");
  const activeReviewDeckId = location.pathname === "/review" ? activeStudyDeckId : null;
  const activeNotesDeckId = location.pathname === "/notes" ? activeStudyDeckId : null;
  const [progressDeckId, setProgressDeckId] = useState("");
  const progressDeck = decks.find((deck) => deck.id === progressDeckId) ?? decks[0];
  const progressStats = progressDeck ? getDeckStats(progressDeck, words, reviews) : null;
  const dailyNewGoal = Math.max(0, progressDeck?.dailyNewLimit ?? 0);
  const learnedToday = progressStats?.todayNew ?? 0;
  const progress = dailyNewGoal > 0 ? Math.min(100, Math.round((learnedToday / dailyNewGoal) * 100)) : 0;

  useEffect(() => {
    if (!decks.length) {
      setProgressDeckId("");
      return;
    }
    if (!decks.some((deck) => deck.id === progressDeckId)) setProgressDeckId(decks[0].id);
  }, [decks, progressDeckId]);

  useEffect(() => {
    if (!draggingId) {
      setNavigationOrder(settings.navigationOrder);
      navigationOrderRef.current = settings.navigationOrder;
    }
  }, [draggingId, settings.navigationOrder]);

  useEffect(() => {
    if (!draggingId) setExpandedFolders(settings.navigationExpanded);
  }, [draggingId, settings.navigationExpanded]);

  useEffect(() => {
    if (!draggingId) return;
    const move = (event: PointerEvent) => {
      event.preventDefault();
      const target = document.elementFromPoint(event.clientX, event.clientY)?.closest<HTMLElement>("[data-nav-id]");
      const targetId = target?.dataset.navId as NavigationItemId | undefined;
      if (!targetId || targetId === draggingId) return;
      setNavigationOrder((current) => {
        const from = current.indexOf(draggingId);
        const to = current.indexOf(targetId);
        if (from < 0 || to < 0) return current;
        const next = [...current];
        next.splice(from, 1);
        next.splice(to, 0, draggingId);
        navigationOrderRef.current = next;
        return next;
      });
    };
    const finish = () => {
      document.body.classList.remove("nav-is-sorting");
      setDraggingId(null);
      void updateSettings({ navigationOrder: navigationOrderRef.current });
      window.setTimeout(() => { suppressClick.current = false; }, 120);
    };
    document.addEventListener("pointermove", move, { passive: false });
    document.addEventListener("pointerup", finish, { once: true });
    document.addEventListener("pointercancel", finish, { once: true });
    return () => {
      document.removeEventListener("pointermove", move);
      document.removeEventListener("pointerup", finish);
      document.removeEventListener("pointercancel", finish);
    };
  }, [draggingId, updateSettings]);

  function beginLongPress(id: NavigationItemId, event: ReactPointerEvent<HTMLElement>) {
    if (event.button !== 0 || (event.target as HTMLElement).closest("[data-no-drag], .nav-submenu")) return;
    if (longPressTimer.current) window.clearTimeout(longPressTimer.current);
    longPressTimer.current = window.setTimeout(() => {
      suppressClick.current = true;
      navigationOrderRef.current = navigationOrder;
      setDraggingId(id);
      document.body.classList.add("nav-is-sorting");
      navigator.vibrate?.(25);
    }, 420);
  }

  function cancelLongPress() {
    if (longPressTimer.current) window.clearTimeout(longPressTimer.current);
    longPressTimer.current = null;
  }

  function preventSortedClick(event: ReactMouseEvent) {
    if (!suppressClick.current) return;
    event.preventDefault();
    event.stopPropagation();
  }

  function toggleFolder(id: NavigationFolderId) {
    setExpandedFolders((current) => {
      const next = { ...current, [id]: !current[id] };
      void updateSettings({ navigationExpanded: next });
      return next;
    });
  }

  async function createMenu() {
    const menu = await addLibraryMenu(menuName, menuLanguage);
    if (!menu) {
      setMenuError(menuName.trim() ? "这个子菜单已经存在。" : "请输入子菜单名称。");
      return;
    }
    setMenuName("");
    setMenuLanguage("ja");
    setMenuError("");
    setShowMenuModal(false);
    if (!expandedFolders.library) toggleFolder("library");
    navigate(`/decks?menu=${encodeURIComponent(menu.id)}`);
  }

  async function deleteMenu(id: string, name: string) {
    if (!window.confirm(`删除「${name}词库」子菜单？其中的词库会保留并移到未分类。`)) return;
    await removeLibraryMenu(id);
    if (activeMenuId === id) navigate("/decks");
  }

  function uploadBrandIcon(file: File) {
    if (!file.type.startsWith("image/")) return;
    if (file.size > 2 * 1024 * 1024) {
      window.alert("图标文件请控制在 2 MB 以内。");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => void updateSettings({ brandIconDataUrl: String(reader.result) });
    reader.readAsDataURL(file);
  }

  const brand = desktop && currentAccount ? (
    <div className="brand account-brand">
      <button
        className="account-brand-button"
        onClick={() => setAccountMenuOpen((open) => !open)}
        aria-expanded={accountMenuOpen}
        aria-label="打开木の叶账号菜单"
      >
        <AccountAvatar account={currentAccount} />
        <span>
          <strong>木の洞</strong>
          <small>木の叶：{currentAccount.username}</small>
        </span>
        <ChevronDown size={14} />
      </button>
      {accountMenuOpen && (
        <div className="account-switcher">
          <div className="account-switcher-current">
            <AccountAvatar account={currentAccount} size="large" />
            <div>
              <strong>木の叶：{currentAccount.username}</strong>
              <span><i /> 本机数据已保存</span>
              <small>最近登录：{currentAccount.lastLoginAt ? new Date(currentAccount.lastLoginAt).toLocaleString() : "刚刚"}</small>
            </div>
          </div>
          {accounts.length > 1 && (
            <div className="account-switcher-list">
              {accounts.filter((account) => account.id !== currentAccount.id).map((account) => (
                <div key={account.id}>
                  <button
                    className="account-switch-item"
                    onClick={() => {
                      void switchAccount(account.id);
                      setAccountMenuOpen(false);
                    }}
                  >
                    <AccountAvatar account={account} size="small" />
                    <span>木の叶：{account.username}</span>
                    <small>{account.sessionStatus === "ready" ? "快速切换" : "需登录"}</small>
                  </button>
                  <button
                    className="account-remove-local"
                    aria-label={`移除本机账号${account.username}`}
                    title="仅移除本机快速登录，不删除账号数据"
                    onClick={() => {
                      if (window.confirm(`从本机移除木の叶：${account.username}？账号数据不会被删除。`)) {
                        void removeLocalAccount(account.id);
                      }
                    }}
                  >
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
          )}
          <button className="account-menu-action" onClick={() => { setAddAccountOpen(true); setAccountMenuOpen(false); }}>
            <UserPlus size={15} /> 添加木の叶账号
          </button>
          <button className="account-menu-action" onClick={() => { navigate("/settings#konoha-account"); setAccountMenuOpen(false); }}>
            <Settings2 size={15} /> 木の叶账号设置
          </button>
          <button className="account-menu-action" onClick={() => { void logout(); setAccountMenuOpen(false); }}>
            <DoorOpen size={15} /> 退出当前账号
          </button>
          <div className="account-menu-footer"><Leaf size={12} /> 木の叶本地账号</div>
        </div>
      )}
    </div>
  ) : (
    <div className="brand">
      <button className="brand-mark brand-upload" onClick={() => brandIconRef.current?.click()} aria-label="上传自己的图标" title="点击更换图标">
        {settings.brandIconDataUrl ? <img src={settings.brandIconDataUrl} alt="" /> : <Sparkles size={16} strokeWidth={2.5} />}
        <span className="brand-edit-indicator"><ImagePlus size={10} /></span>
      </button>
      <div className="brand-name">木の洞</div>
    </div>
  );

  function sortableSection(id: NavigationItemId, content: ReactNode) {
    return <div
      key={id}
      data-nav-id={id}
      className={`nav-sortable ${draggingId === id ? "dragging" : ""}`}
      onPointerDown={(event) => beginLongPress(id, event)}
      onPointerUp={cancelLongPress}
      onPointerCancel={cancelLongPress}
      onPointerLeave={cancelLongPress}
      onClickCapture={preventSortedClick}
    >
      {content}
    </div>;
  }

  function renderNavigationSection(id: NavigationItemId) {
    if (id === "library") {
      const libraryOpen = expandedFolders.library;
      return sortableSection(id, <div className={`nav-group nav-folder ${libraryOpen ? "open" : "collapsed"}`}>
        <div className="nav-parent-row">
          <NavLink to="/decks" className={({ isActive }: NavLinkRenderProps) => `nav-item nav-parent-link ${isActive ? "active" : ""}`}>
            <BookOpen size={18} strokeWidth={1.8} />
            <span>词库</span>
          </NavLink>
          <span className="nav-drag-handle" aria-hidden="true"><GripVertical size={14} /></span>
          <button data-no-drag className="nav-expand-button" onClick={() => toggleFolder("library")} aria-label={libraryOpen ? "收起词库子菜单" : "展开词库子菜单"} aria-expanded={libraryOpen}>
            <ChevronRight size={15} />
          </button>
        </div>
        {libraryOpen && <div className="nav-submenu">
          {settings.libraryMenus.map((menu) => {
            const isActive = location.pathname === "/decks" && activeMenuId === menu.id;
            const deckCount = decks.filter((deck) => deck.menuId === menu.id).length;
            return <div className={`nav-menu-row ${isActive ? "active" : ""}`} key={menu.id}>
              <NavLink to={`/decks?menu=${encodeURIComponent(menu.id)}`} className="nav-subitem">
                <span className="menu-badge">{menu.shortLabel}</span>
                <span>{menu.name.endsWith("词库") ? menu.name : `${menu.name}词库`}</span>
                <small>{deckCount}</small>
              </NavLink>
              <button data-no-drag className="nav-menu-delete" onClick={() => void deleteMenu(menu.id, menu.name)} aria-label={`删除${menu.name}子菜单`}><Trash2 size={12} /></button>
            </div>;
          })}
          <button data-no-drag className="nav-subitem nav-subitem-add" onClick={() => setShowMenuModal(true)}><Plus size={15} /><span>添加词库子菜单</span></button>
        </div>}
      </div>);
    }

    if (id === "study") {
      const studyOpen = expandedFolders.study;
      return sortableSection(id, <div className={`nav-group nav-folder ${studyOpen ? "open" : "collapsed"}`}>
        <div className="nav-parent-row">
          <NavLink to={decks[0] ? `/study?deck=${encodeURIComponent(decks[0].id)}` : "/study"} className={`nav-item nav-parent-link ${location.pathname === "/study" ? "active" : ""}`}>
            <Brain size={18} strokeWidth={1.8} />
            <span>学习</span>
          </NavLink>
          <span className="nav-drag-handle" aria-hidden="true"><GripVertical size={14} /></span>
          <button data-no-drag className="nav-expand-button" onClick={() => toggleFolder("study")} aria-label={studyOpen ? "收起学习词库" : "展开学习词库"} aria-expanded={studyOpen}>
            <ChevronRight size={15} />
          </button>
        </div>
        {studyOpen && <div className="nav-submenu study-submenu">
          {(["ja", "en"] as StudyLanguage[]).map((language) => {
            const languageDecks = decks.filter((deck) => (deck.language ?? "ja") === language);
            if (!languageDecks.length) return null;
            return <div className="nav-language-group" key={language}>
              <div className="nav-language-label">{language === "en" ? "英语" : "日语"}</div>
              {languageDecks.map((deck) => {
                const count = words.filter((word) => word.deckIds.includes(deck.id) && word.status !== "SUSPENDED").length;
                const isActive = location.pathname === "/study" && activeStudyDeckId === deck.id;
                return <NavLink key={deck.id} to={`/study?deck=${encodeURIComponent(deck.id)}`} className={`study-deck-row ${isActive ? "active" : ""}`} aria-current={isActive ? "page" : undefined}>
                  <span className="menu-badge study-badge">{deck.language === "en" ? "英" : "日"}</span>
                  <span>{deck.name}</span>
                  <small>{count}</small>
                </NavLink>;
              })}
            </div>;
          })}
          {!decks.length && <div className="nav-empty-note">先在词库中创建一个词库</div>}
          <NavLink to="/decks" className="nav-subitem nav-subitem-add"><Plus size={15} /><span>管理学习词库</span></NavLink>
        </div>}
      </div>);
    }

    if (id === "review" || id === "notes") {
      const isReview = id === "review";
      const folderId: NavigationFolderId = isReview ? "review" : "notes";
      const open = expandedFolders[folderId];
      const path = isReview ? "/review" : "/notes";
      const label = isReview ? "复习" : "笔记";
      const Icon = isReview ? CalendarClock : NotebookPen;
      const activeDeckId = isReview ? activeReviewDeckId : activeNotesDeckId;
      const firstTarget = decks[0]
        ? `${path}?deck=${encodeURIComponent(decks[0].id)}`
        : path;

      return sortableSection(id, <div className={`nav-group nav-folder ${open ? "open" : "collapsed"}`}>
        <div className="nav-parent-row">
          <NavLink to={firstTarget} className={`nav-item nav-parent-link ${location.pathname === path ? "active" : ""}`}>
            <Icon size={18} strokeWidth={1.8} />
            <span>{label}</span>
          </NavLink>
          <span className="nav-drag-handle" aria-hidden="true"><GripVertical size={14} /></span>
          <button data-no-drag className="nav-expand-button" onClick={() => toggleFolder(folderId)} aria-label={open ? `收起${label}词库` : `展开${label}词库`} aria-expanded={open}>
            <ChevronRight size={15} />
          </button>
        </div>
        {open && <div className="nav-submenu study-submenu">
          {(["ja", "en"] as StudyLanguage[]).map((language) => {
            const languageDecks = decks.filter((deck) => (deck.language ?? "ja") === language);
            if (!languageDecks.length) return null;
            return <div className="nav-language-group" key={language}>
              <div className="nav-language-label">{language === "en" ? "英语" : "日语"}</div>
              {languageDecks.map((deck) => {
                const deckWords = words.filter((word) => word.deckIds.includes(deck.id) && word.status !== "SUSPENDED");
                const count = isReview
                  ? deckWords.filter((word) => word.status !== "NEW" && word.dueDate && new Date(word.dueDate).getTime() <= Date.now()).length
                  : deckWords.filter((word) => word.favorite || Boolean(word.note?.trim())).length;
                const isActive = location.pathname === path && activeDeckId === deck.id;
                return <NavLink key={deck.id} to={`${path}?deck=${encodeURIComponent(deck.id)}`} className={`study-deck-row ${isActive ? "active" : ""}`} aria-current={isActive ? "page" : undefined}>
                  <span className="menu-badge study-badge">{deck.language === "en" ? "英" : "日"}</span>
                  <span>{deck.name}</span>
                  <small>{count}</small>
                </NavLink>;
              })}
            </div>;
          })}
          {!decks.length && <div className="nav-empty-note">先在词库中创建一个词库</div>}
        </div>}
      </div>);
    }

    const item = simpleNavItems[id];
    const Icon = item.icon;
    return sortableSection(id, <div className="nav-parent-row">
      <NavLink to={item.to} className={({ isActive }: NavLinkRenderProps) => `nav-item nav-parent-link ${isActive ? "active" : ""}`}>
        <Icon size={18} strokeWidth={1.8} />
        <span>{item.label}</span>
      </NavLink>
      <span className="nav-drag-handle" aria-hidden="true"><GripVertical size={14} /></span>
    </div>);
  }

  return (
    <div className="app-shell">
      <aside className="sidebar">
        {brand}
        <nav className="primary-nav" aria-label="主导航">
          {navigationOrder.map(renderNavigationSection)}
        </nav>
        <div className="daily-progress-card" aria-label="每日学习进度">
          <div className="daily-progress-heading">
            <span><Target size={13} /> 每日新词</span>
            <small>{learnedToday} / {dailyNewGoal}</small>
          </div>
          {decks.length > 1 && <select className="daily-progress-switcher" value={progressDeck?.id ?? ""} onChange={(event) => setProgressDeckId(event.target.value)} aria-label="切换每日新词计划">{decks.map((deck) => <option key={deck.id} value={deck.id}>{deck.name}</option>)}</select>}
          {progressDeck && decks.length === 1 && <div className="daily-progress-deck">{progressDeck.name}</div>}
          <div className="daily-progress-ring" style={{ "--daily-progress": `${progress * 3.6}deg` } as React.CSSProperties}>
            <div>
              <strong>{learnedToday}</strong>
              <span>／{dailyNewGoal} 个新词</span>
            </div>
          </div>
          <div className="daily-progress-caption">{!progressDeck ? "先创建一个词库计划" : dailyNewGoal === 0 ? "此词库已暂停新词安排" : progress >= 100 ? "今日新词目标已完成" : `已完成 ${progress}% · 还差 ${Math.max(0, dailyNewGoal - learnedToday)} 个`}</div>
        </div>
        <div className="sidebar-footer">
          <div className="streak-mini"><span className="streak-dot" />连续学习 <strong>{streak} 天</strong></div>
          <div className="sidebar-count">{words.length.toLocaleString()} 个单词</div>
        </div>
      </aside>
      <main className="main-area">
        <header className="mobile-header">
          {brand}
          <NavLink to="/add-word" className="icon-button" aria-label="添加单词"><Plus size={20} /></NavLink>
        </header>
        <div className={`content-wrap ${location.pathname === "/study" ? "study-content" : ""}`}>
          {children}
        </div>
      </main>
      <input ref={brandIconRef} type="file" accept="image/*" hidden onChange={(event) => { const file = event.target.files?.[0]; if (file) uploadBrandIcon(file); event.target.value = ""; }} />
      {showMenuModal && <div className="modal-backdrop" onMouseDown={(event) => { if (event.currentTarget === event.target) setShowMenuModal(false); }}>
        <div className="modal-card library-menu-modal" role="dialog" aria-modal="true" aria-labelledby="library-menu-title">
          <div className="modal-header">
            <div><p className="eyebrow">词库子菜单</p><h2 id="library-menu-title">新建子菜单</h2></div>
            <button className="icon-button" onClick={() => setShowMenuModal(false)} aria-label="关闭"><X size={18} /></button>
          </div>
          <p className="modal-copy">例如输入“日语”或“英语”，左侧会显示对应词库入口，右侧只展示归属该菜单的词库。</p>
          <label className="field">
            <span>子菜单语言</span>
            <select value={menuLanguage} onChange={(event) => setMenuLanguage(event.target.value as StudyLanguage)}>
              <option value="ja">日语</option>
              <option value="en">英语</option>
            </select>
          </label>
          <label className="field">
            <span>子菜单名称</span>
            <input autoFocus value={menuName} maxLength={18} onChange={(event) => { setMenuName(event.target.value); setMenuError(""); }} onKeyDown={(event) => { if (event.key === "Enter") void createMenu(); }} placeholder="例如：英语" />
          </label>
          {menuError && <p className="form-error">{menuError}</p>}
          <div className="import-actions">
            <button className="button button-secondary" onClick={() => setShowMenuModal(false)}>取消</button>
            <button className="button button-primary" onClick={() => void createMenu()}>创建子菜单</button>
          </div>
        </div>
      </div>}
    </div>
  );
}
