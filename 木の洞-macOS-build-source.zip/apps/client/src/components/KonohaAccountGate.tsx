import { CheckCircle2, Eye, EyeOff, Leaf, LockKeyhole, UserRound, X } from "lucide-react";
import { useState, type FormEvent, type ReactNode } from "react";
import { useKonohaAccount } from "@/services/KonohaAccount";

type Mode = "login" | "register" | "reset";

export default function KonohaAccountGate({ children }: { children: ReactNode }) {
  const { ready, desktop, currentAccount, addAccountOpen, setAddAccountOpen } =
    useKonohaAccount();
  if (!desktop) return <>{children}</>;
  if (!ready) {
    return <div className="konoha-loading"><Leaf size={26} /> 正在准备木の叶账号…</div>;
  }
  if (!currentAccount) return <KonohaAuthPanel />;
  return (
    <>
      {children}
      {addAccountOpen && (
        <div className="modal-backdrop konoha-auth-backdrop">
          <KonohaAuthPanel compact onClose={() => setAddAccountOpen(false)} />
        </div>
      )}
    </>
  );
}

function KonohaAuthPanel({
  compact = false,
  onClose,
}: {
  compact?: boolean;
  onClose?: () => void;
}) {
  const { accounts, login, register, resetPassword, switchAccount } =
    useKonohaAccount();
  const [mode, setMode] = useState<Mode>("login");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [recoveryCode, setRecoveryCode] = useState("");
  const [remember, setRemember] = useState(true);
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [createdRecoveryCode, setCreatedRecoveryCode] = useState("");

  async function submit(event: FormEvent) {
    event.preventDefault();
    setError("");
    if ((mode === "register" || mode === "reset") && password !== confirmPassword) {
      setError("两次输入的密码不一致。");
      return;
    }
    setSubmitting(true);
    try {
      if (mode === "register") {
        const result = await register({ username, password, email: email || undefined });
        setCreatedRecoveryCode(result.recoveryCode);
        return;
      }
      if (mode === "reset") {
        await resetPassword(username, recoveryCode, password);
        setMode("login");
        setRecoveryCode("");
        setConfirmPassword("");
        setError("密码已重置，请使用新密码登录。");
        return;
      }
      await login({ username, password, remember });
      onClose?.();
    } catch (submitError) {
      setError(submitError instanceof Error ? submitError.message : "账号操作失败");
    } finally {
      setSubmitting(false);
    }
  }

  if (createdRecoveryCode) {
    return (
      <section className={`konoha-auth-card recovery-card ${compact ? "compact" : ""}`}>
        <div className="recovery-success"><CheckCircle2 size={28} /></div>
        <p className="eyebrow">木の叶账号已创建</p>
        <h1>请保存账号恢复码</h1>
        <p>单机版没有云端邮件服务。忘记密码时，只有下面的恢复码可以重置密码。</p>
        <code>{createdRecoveryCode}</code>
        <button
          className="button button-primary"
          onClick={() => {
            setCreatedRecoveryCode("");
            onClose?.();
          }}
        >
          我已安全保存
        </button>
      </section>
    );
  }

  return (
    <main className={compact ? "konoha-auth-modal" : "konoha-auth-page"}>
      <section className={`konoha-auth-card ${compact ? "compact" : ""}`}>
        {onClose && (
          <button className="icon-button konoha-auth-close" onClick={onClose} aria-label="关闭">
            <X size={17} />
          </button>
        )}
        <div className="konoha-auth-brand"><Leaf size={22} /><span>木の洞</span></div>
        <p className="eyebrow">木の叶账号</p>
        <h1>
          {mode === "login"
            ? "登录木の叶"
            : mode === "register"
              ? "注册木の叶账号"
              : "找回木の叶账号"}
        </h1>
        <p className="konoha-auth-copy">
          {mode === "login"
            ? "每个木の叶账号拥有独立的本地词库、进度、收藏、笔记和设置。"
            : mode === "register"
              ? "木の叶号只保存在这台电脑，密码使用 Argon2 安全散列。"
              : "输入注册时保存的恢复码，为本机账号设置新密码。"}
        </p>

        {mode === "login" && accounts.length > 0 && (
          <div className="quick-account-list">
            {accounts.map((account) => (
              <button
                key={account.id}
                onClick={() =>
                  void switchAccount(account.id).catch((switchError) =>
                    setError(
                      switchError instanceof Error
                        ? switchError.message
                        : "快速登录状态已过期",
                    ),
                  )
                }
              >
                <AccountAvatar account={account} />
                <span><strong>木の叶：{account.username}</strong><small>{account.sessionStatus === "ready" ? "点击快速登录" : "需要重新登录"}</small></span>
              </button>
            ))}
          </div>
        )}

        <form onSubmit={submit} className="konoha-auth-form">
          <label>
            <span>木の叶号</span>
            <div><UserRound size={16} /><input value={username} onChange={(event) => setUsername(event.target.value)} autoComplete="username" placeholder="4–24 位数字或字母" required /></div>
          </label>
          {mode === "register" && (
            <label>
              <span>邮箱（可选）</span>
              <div><span className="field-symbol">@</span><input type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" placeholder="用于账号资料" /></div>
            </label>
          )}
          {mode === "reset" && (
            <label>
              <span>账号恢复码</span>
              <div><LockKeyhole size={16} /><input value={recoveryCode} onChange={(event) => setRecoveryCode(event.target.value)} placeholder="XXXXXX-XXXXXX-XXXXXX" required /></div>
            </label>
          )}
          <label>
            <span>{mode === "reset" ? "新密码" : "密码"}</span>
            <div>
              <LockKeyhole size={16} />
              <input type={showPassword ? "text" : "password"} value={password} onChange={(event) => setPassword(event.target.value)} autoComplete={mode === "login" ? "current-password" : "new-password"} placeholder="至少 8 位，包含字母和数字" required />
              <button type="button" onClick={() => setShowPassword((show) => !show)} aria-label={showPassword ? "隐藏密码" : "显示密码"}>{showPassword ? <EyeOff size={15} /> : <Eye size={15} />}</button>
            </div>
          </label>
          {(mode === "register" || mode === "reset") && (
            <label>
              <span>确认密码</span>
              <div><LockKeyhole size={16} /><input type="password" value={confirmPassword} onChange={(event) => setConfirmPassword(event.target.value)} autoComplete="new-password" required /></div>
            </label>
          )}
          {mode === "login" && (
            <label className="remember-row"><input type="checkbox" checked={remember} onChange={(event) => setRemember(event.target.checked)} /><span>记住登录状态并允许快速切换</span></label>
          )}
          {error && <p className={error.startsWith("密码已重置") ? "konoha-form-success" : "konoha-form-error"}>{error}</p>}
          <button className="button button-primary konoha-submit" disabled={submitting}>
            {submitting ? "请稍候…" : mode === "login" ? "登录" : mode === "register" ? "注册木の叶账号" : "重置密码"}
          </button>
        </form>

        <div className="konoha-auth-links">
          {mode !== "login" ? (
            <button onClick={() => setMode("login")}>返回登录</button>
          ) : (
            <>
              <button onClick={() => setMode("register")}>注册木の叶账号</button>
              <button onClick={() => setMode("reset")}>忘记密码？</button>
            </>
          )}
        </div>
      </section>
    </main>
  );
}

export function AccountAvatar({
  account,
  size = "normal",
}: {
  account: { username: string; avatarDataUrl?: string | null };
  size?: "small" | "normal" | "large";
}) {
  return (
    <span className={`konoha-avatar ${size}`}>
      {account.avatarDataUrl ? (
        <img src={account.avatarDataUrl} alt="" />
      ) : (
        account.username.slice(0, 1).toUpperCase()
      )}
    </span>
  );
}
