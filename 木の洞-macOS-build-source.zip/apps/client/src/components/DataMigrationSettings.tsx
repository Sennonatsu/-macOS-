import { Check, Download, FileKey2, Upload } from "lucide-react";
import { useRef, useState } from "react";
import {
  exportMigrationPackage,
  importMigrationPackage,
} from "@/services/migration";

export default function DataMigrationSettings() {
  const inputRef = useRef<HTMLInputElement>(null);
  const [passphrase, setPassphrase] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  async function exportData() {
    setBusy(true);
    setError("");
    try {
      await exportMigrationPackage(passphrase);
      setNotice("加密迁移包已生成，请妥善保存文件和迁移密码。");
    } catch (exportError) {
      setError(exportError instanceof Error ? exportError.message : "导出失败");
    } finally {
      setBusy(false);
    }
  }

  async function importData(file: File) {
    setBusy(true);
    setError("");
    try {
      const result = await importMigrationPackage(file, passphrase);
      setNotice(
        `迁移完成：${result.decks} 个词库、${result.words} 个单词、${result.reviews} 条学习记录。正在重新载入…`,
      );
      window.setTimeout(() => window.location.reload(), 700);
    } catch (importError) {
      setError(importError instanceof Error ? importError.message : "导入失败");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="setting-section" id="data-migration">
      <h2>网页数据迁移</h2>
      <div className="migration-panel">
        <div className="migration-copy">
          <FileKey2 size={19} />
          <div>
            <strong>加密迁移包</strong>
            <span>在原网页版导出 `.kino` 文件，再登录桌面版对应的木の叶账号导入。迁移会合并词库、单词、复习记录、笔记和设置，不会覆盖其他账号。</span>
          </div>
        </div>
        <label className="field">
          <span>迁移密码</span>
          <input type="password" value={passphrase} onChange={(event) => setPassphrase(event.target.value)} placeholder="至少 8 位；导入时需要使用同一密码" />
        </label>
        <div className="migration-actions">
          <button className="button button-secondary" disabled={busy || passphrase.length < 8} onClick={() => void exportData()}><Download size={15} /> 导出迁移包</button>
          <button className="button button-primary" disabled={busy || passphrase.length < 8} onClick={() => inputRef.current?.click()}><Upload size={15} /> 导入迁移包</button>
          <input ref={inputRef} hidden type="file" accept=".kino,application/json" onChange={(event) => { const file = event.target.files?.[0]; event.target.value = ""; if (file) void importData(file); }} />
        </div>
        <small>外部字体和 AI 音频素材体积可能很大，不包含在迁移包内，需要在新设备重新导入。</small>
      </div>
      {notice && <p className="asset-notice"><Check size={14} /> {notice}</p>}
      {error && <p className="konoha-form-error">{error}</p>}
    </div>
  );
}
