import { Check, KeyRound, Laptop, ShieldCheck, Trash2, Upload, UserRound } from "lucide-react";
import { useEffect, useRef, useState, type ChangeEvent } from "react";
import { useKonohaAccount } from "@/services/KonohaAccount";
import { invokeDesktop } from "@/services/desktopBridge";
import { AccountAvatar } from "./KonohaAccountGate";

interface TtsProfile {
  provider: "default" | "openai" | "elevenlabs" | "google" | "azure" | "custom";
  voice: string;
  language: "ja" | "en";
  speed: number;
  pitch: number;
  style?: string | null;
  customUrl?: string | null;
  hasApiKey: boolean;
}

const defaultTtsProfile: TtsProfile = {
  provider: "default",
  voice: "female",
  language: "ja",
  speed: 1,
  pitch: 1,
  style: "",
  customUrl: "",
  hasApiKey: true,
};

export function KonohaAccountSettings() {
  const {
    desktop,
    currentAccount,
    updateProfile,
    changePassword,
    removeLocalAccount,
    deleteAccount,
  } = useKonohaAccount();
  const avatarRef = useRef<HTMLInputElement>(null);
  const [email, setEmail] = useState(currentAccount?.email ?? "");
  const [avatar, setAvatar] = useState(currentAccount?.avatarDataUrl ?? "");
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [deletePassword, setDeletePassword] = useState("");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    setEmail(currentAccount?.email ?? "");
    setAvatar(currentAccount?.avatarDataUrl ?? "");
  }, [currentAccount?.avatarDataUrl, currentAccount?.email]);

  if (!desktop || !currentAccount) return null;

  function loadAvatar(event: ChangeEvent<HTMLInputElement>) {
    const file = event.target.files?.[0];
    event.target.value = "";
    if (!file) return;
    if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
      setError("头像仅支持 PNG、JPG 或 WEBP。");
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      setError("头像文件不能超过 2 MB。");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setAvatar(String(reader.result));
    reader.readAsDataURL(file);
  }

  async function saveProfile() {
    setError("");
    try {
      await updateProfile({
        email: email.trim() || null,
        avatarDataUrl: avatar || null,
      });
      setNotice("木の叶账号资料已保存。");
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "保存失败");
    }
  }

  async function savePassword() {
    setError("");
    try {
      await changePassword(currentPassword, newPassword);
      setCurrentPassword("");
      setNewPassword("");
      setNotice("密码已修改。");
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "修改密码失败");
    }
  }

  return (
    <div className="setting-section" id="konoha-account">
      <h2>木の叶账号设置</h2>
      <div className="konoha-settings-profile">
        <AccountAvatar account={{ username: currentAccount.username, avatarDataUrl: avatar }} size="large" />
        <div>
          <strong>木の叶：{currentAccount.username}</strong>
          <span>账号数据与其他木の叶账号完全隔离</span>
        </div>
        <button className="button button-secondary compact" onClick={() => avatarRef.current?.click()}>
          <Upload size={14} /> 更换头像
        </button>
        {avatar && <button className="button button-secondary compact" onClick={() => setAvatar("")}>恢复默认</button>}
        <input ref={avatarRef} type="file" hidden accept=".png,.jpg,.jpeg,.webp,image/png,image/jpeg,image/webp" onChange={loadAvatar} />
      </div>
      <div className="konoha-settings-grid">
        <label className="field">
          <span>木の叶号</span>
          <input value={currentAccount.username} disabled />
        </label>
        <label className="field">
          <span>绑定邮箱</span>
          <input type="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="可选" />
        </label>
      </div>
      <button className="button button-primary compact" onClick={() => void saveProfile()}>
        <UserRound size={14} /> 保存账号资料
      </button>

      <div className="account-security-block">
        <div className="account-security-title"><KeyRound size={16} /><strong>修改密码</strong></div>
        <div className="konoha-settings-grid">
          <label className="field"><span>当前密码</span><input type="password" value={currentPassword} onChange={(event) => setCurrentPassword(event.target.value)} /></label>
          <label className="field"><span>新密码</span><input type="password" value={newPassword} onChange={(event) => setNewPassword(event.target.value)} placeholder="至少 8 位，包含字母和数字" /></label>
        </div>
        <button className="button button-secondary compact" disabled={!currentPassword || !newPassword} onClick={() => void savePassword()}>修改密码</button>
      </div>

      <div className="account-device-card">
        <Laptop size={17} />
        <div><strong>当前设备</strong><span>本机快速登录 · 最近登录 {currentAccount.lastLoginAt ? new Date(currentAccount.lastLoginAt).toLocaleString() : "刚刚"}</span></div>
        <small>本机</small>
      </div>

      <div className="account-danger-zone">
        <div>
          <strong>移除本机账号</strong>
          <span>只移除快速登录状态，词库与账号本身不会被删除。</span>
        </div>
        <button className="button button-secondary compact" onClick={() => void removeLocalAccount(currentAccount.id)}>移除本机账号</button>
      </div>
      <div className="account-danger-zone destructive">
        <div>
          <strong>删除木の叶账号</strong>
          <span>永久删除本机账号资料与该账号的词库、进度和笔记，无法撤销。</span>
        </div>
        <input type="password" value={deletePassword} onChange={(event) => setDeletePassword(event.target.value)} placeholder="输入密码确认" />
        <button
          className="button button-danger compact"
          disabled={!deletePassword}
          onClick={() => {
            if (window.confirm(`永久删除木の叶：${currentAccount.username} 及其全部本地数据？`)) {
              void deleteAccount(deletePassword).catch((deleteError) =>
                setError(deleteError instanceof Error ? deleteError.message : "删除失败"),
              );
            }
          }}
        >
          <Trash2 size={14} /> 删除木の叶账号
        </button>
      </div>
      {notice && <p className="asset-notice"><Check size={14} /> {notice}</p>}
      {error && <p className="konoha-form-error">{error}</p>}
    </div>
  );
}

export function DesktopTtsSettings() {
  const { desktop, currentAccount } = useKonohaAccount();
  const [profile, setProfile] = useState<TtsProfile>(defaultTtsProfile);
  const [apiKey, setApiKey] = useState("");
  const [notice, setNotice] = useState("");
  const [error, setError] = useState("");
  const currentAccountId = currentAccount?.id;

  useEffect(() => {
    if (!desktop || !currentAccountId) return;
    void invokeDesktop<TtsProfile>("konoha_tts_profile", { userId: currentAccountId })
      .then(setProfile)
      .catch(() => setProfile(defaultTtsProfile));
  }, [currentAccountId, desktop]);

  if (!desktop || !currentAccount) return null;

  async function save() {
    setError("");
    try {
      const saved = await invokeDesktop<TtsProfile>("konoha_save_tts_profile", {
        userId: currentAccount?.id,
        input: { profile, apiKey: apiKey || null },
      });
      setProfile(saved);
      setApiKey("");
      setNotice("AI 配音设置已安全保存。");
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "保存 TTS 设置失败");
    }
  }

  return (
    <div className="setting-section" id="desktop-tts">
      <h2>AI 配音 Provider</h2>
      <p className="settings-note voice-note">
        第三方 API Key 由 Tauri Rust 后端写入系统钥匙串，不会进入网页代码或 IndexedDB。音频缓存按 Provider、语言、声音、语速和文字分别保存。
      </p>
      <div className="tts-settings-grid">
        <label className="field"><span>TTS Provider</span><select value={profile.provider} onChange={(event) => setProfile((current) => ({ ...current, provider: event.target.value as TtsProfile["provider"] }))}><option value="default">木の洞默认</option><option value="openai">OpenAI</option><option value="elevenlabs">ElevenLabs</option><option value="google">Google Cloud TTS</option><option value="azure">Azure Speech</option><option value="custom">自定义 API</option></select></label>
        <label className="field"><span>声音 / Voice ID</span><input value={profile.voice} onChange={(event) => setProfile((current) => ({ ...current, voice: event.target.value }))} placeholder={profile.provider === "openai" ? "alloy" : "female"} /></label>
        <label className="field"><span>语言</span><select value={profile.language} onChange={(event) => setProfile((current) => ({ ...current, language: event.target.value as "ja" | "en" }))}><option value="ja">日本語</option><option value="en">English</option></select></label>
        <label className="field"><span>语速</span><select value={profile.speed} onChange={(event) => setProfile((current) => ({ ...current, speed: Number(event.target.value) }))}>{[0.5, 0.75, 1, 1.25, 1.5].map((speed) => <option key={speed} value={speed}>{speed.toFixed(2)}×</option>)}</select></label>
        {profile.provider !== "default" && <label className="field"><span>API Secret Key {profile.hasApiKey ? "（已保存）" : ""}</span><input type="password" value={apiKey} onChange={(event) => setApiKey(event.target.value)} placeholder={profile.hasApiKey ? "留空则保持现有密钥" : "仅写入系统钥匙串"} /></label>}
        {(profile.provider === "custom" || profile.provider === "azure") && <label className="field"><span>{profile.provider === "azure" ? "Azure Region" : "自定义 HTTPS API"}</span><input value={profile.customUrl ?? ""} onChange={(event) => setProfile((current) => ({ ...current, customUrl: event.target.value }))} placeholder={profile.provider === "azure" ? "eastus" : "https://api.example.com/tts"} /></label>}
      </div>
      <button className="button button-primary compact" onClick={() => void save()}><ShieldCheck size={14} /> 保存安全配音设置</button>
      {notice && <p className="asset-notice"><Check size={14} /> {notice}</p>}
      {error && <p className="konoha-form-error">{error}</p>}
    </div>
  );
}

interface UpdateStatus {
  configured: boolean;
  currentVersion: string;
  updateAvailable: boolean;
  manifest?: {
    version: string;
    notes?: string | null;
  } | null;
}

export function DesktopVersionSettings() {
  const { desktop, runtime } = useKonohaAccount();
  const [status, setStatus] = useState<UpdateStatus | null>(null);
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState("");
  if (!desktop) return null;

  async function check() {
    setChecking(true);
    setError("");
    try {
      setStatus(await invokeDesktop<UpdateStatus>("desktop_check_update"));
    } catch (checkError) {
      setError(checkError instanceof Error ? checkError.message : "检查更新失败");
    } finally {
      setChecking(false);
    }
  }

  return (
    <div className="setting-section" id="desktop-version">
      <h2>桌面版本</h2>
      <div className="account-device-card">
        <Laptop size={17} />
        <div>
          <strong>木の洞 {runtime?.version ?? "1.0.0"}</strong>
          <span>{runtime?.platform === "macos" ? "macOS" : runtime?.platform === "windows" ? "Windows" : "桌面版"} · 自动更新检测架构已启用</span>
        </div>
        <button className="button button-secondary compact" disabled={checking} onClick={() => void check()}>
          {checking ? "检查中…" : "检查更新"}
        </button>
      </div>
      {status && <p className="settings-note voice-note">{!status.configured ? "当前构建尚未配置正式更新清单地址；发布服务器就绪后可直接启用。" : status.updateAvailable ? `发现新版本 ${status.manifest?.version}` : "当前已经是最新版本。"}</p>}
      {error && <p className="konoha-form-error">{error}</p>}
    </div>
  );
}
