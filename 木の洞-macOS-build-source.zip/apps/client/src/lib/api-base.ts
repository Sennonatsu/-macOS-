type RuntimeAppConfig = { apiBaseUrl?: string };

// Resolution order: build-time VITE_API_BASE_URL > runtime app-config.js
// (written by the publish pipeline after backend deploy) > same-origin.
// The static client and the FC backend live on different domains, so the
// runtime config is what wires production FE -> BE without a rebuild.
const runtimeConfig: RuntimeAppConfig =
  (window as Window & { __SKYBASE_APP_CONFIG__?: RuntimeAppConfig }).__SKYBASE_APP_CONFIG__ ?? {};

const DESKTOP_FALLBACK_API_BASE_URL = "http://127.0.0.1";
const RAW_API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL ??
  runtimeConfig.apiBaseUrl ??
  (import.meta.env.VITE_DESKTOP_APP === "true"
    ? DESKTOP_FALLBACK_API_BASE_URL
    : "");

// Better Auth validates its base URL during module initialization and only
// accepts HTTP(S). Tauri uses a custom app protocol on macOS, so feeding
// window.location.origin into Better Auth would abort the entire JS bundle
// before React can render the local 木の叶 account screen.
export const API_BASE_URL = (RAW_API_BASE_URL || window.location.origin).replace(
  /\/+$/,
  "",
);

export function apiUrl(path: string) {
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  const apiPath = normalizedPath === "/api" || normalizedPath.startsWith("/api/") ? normalizedPath : `/api${normalizedPath}`;
  return `${API_BASE_URL}${apiPath}`;
}

export function authUrl(path = "") {
  const normalizedPath = path ? (path.startsWith("/") ? path : `/${path}`) : "";
  return apiUrl(`/auth${normalizedPath}`);
}
