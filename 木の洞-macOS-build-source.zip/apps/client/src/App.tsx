import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, HashRouter, Navigate, Route, Routes } from "react-router-dom";
import AppShell from "./components/AppShell";
import { AppStateProvider } from "./services/AppState";
import AddWord from "./pages/AddWord";
import DeckDetail from "./pages/DeckDetail";
import Library from "./pages/Library";
import Notes from "./pages/Notes";
import Settings from "./pages/SettingsV2";
import Statistics from "./pages/Statistics";
import Study from "./pages/Study";
import Review from "./pages/Review";
import Calendar from "./pages/Calendar";
import NotFound from "./pages/not-found/Index";
import KonohaAccountGate from "./components/KonohaAccountGate";
import { KonohaAccountProvider } from "./services/KonohaAccount";
import { isDesktopRuntime } from "./services/desktopBridge";

const queryClient = new QueryClient();
const AppRouter = isDesktopRuntime() ? HashRouter : BrowserRouter;

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Sonner />
      <KonohaAccountProvider>
        <KonohaAccountGate>
          <AppStateProvider>
            <AppRouter>
              <AppShell>
                <Routes>
                  <Route path="/" element={<Library />} />
                  <Route path="/study" element={<Study />} />
                  <Route path="/review" element={<Review />} />
                  <Route path="/calendar" element={<Calendar />} />
                  <Route path="/decks" element={<Library />} />
                  <Route path="/decks/:deckId" element={<DeckDetail />} />
                  <Route path="/notes" element={<Notes />} />
                  <Route path="/search" element={<Navigate to="/notes" replace />} />
                  <Route path="/add-word" element={<AddWord />} />
                  <Route path="/statistics" element={<Statistics />} />
                  <Route path="/settings" element={<Settings />} />
                  <Route path="*" element={<NotFound />} />
                </Routes>
              </AppShell>
            </AppRouter>
          </AppStateProvider>
        </KonohaAccountGate>
      </KonohaAccountProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
