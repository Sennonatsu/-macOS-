export type WordStatus = "NEW" | "LEARNING" | "RELEARNING" | "REVIEW" | "MATURE" | "SUSPENDED";
export type Rating = "AGAIN" | "HARD" | "GOOD" | "EASY";
export type LearningMode = "JP_TO_CN" | "CN_TO_JP" | "LISTENING" | "TYPE_ANSWER";
export type TestMode = "LISTENING" | "TYPE_ANSWER";
export type ThemeMode = "light" | "dark" | "system";
export type ColorStyle = "standard" | "low_saturation" | "minimal";
export type AccentColor = "blue" | "green" | "teal" | "indigo" | "violet" | "rose" | "coral" | "amber" | "black" | "gray";
export type VoicePreference = "female" | "male" | "natural";
export type StudyLanguage = "ja" | "en";
export type NavigationItemId = "library" | "study" | "review" | "calendar" | "notes" | "settings";
export type NavigationFolderId = "library" | "study" | "review" | "notes";

export interface LocalAsset {
  id: string;
  kind: "font" | "word-audio";
  name: string;
  mimeType: string;
  data: Blob;
  language?: StudyLanguage;
  /** 音频文件名去除扩展名并标准化后的单词匹配键。 */
  lookupKey?: string;
  importedAt: string;
}

export interface LibraryMenu {
  id: string;
  name: string;
  shortLabel: string;
  /** 决定此子菜单可以归入哪种语言的词库。 */
  language?: StudyLanguage;
  createdAt: string;
}

export interface VerbForms {
  dictionary?: string;
  masu?: string;
  te?: string;
  nai?: string;
  ta?: string;
  custom?: Array<{ label: string; value: string }>;
}

export interface WordCard {
  id: string;
  /** 学习语言；旧数据缺失时按所属词库推导并回退为日语。 */
  language?: StudyLanguage;
  word: string;
  kana: string;
  /** 日语声调/高低アクセント；可填写数字（如 0、2）或自定义记号。 */
  pitchAccent?: string;
  meaning: string;
  partOfSpeech: string;
  example: string;
  exampleTranslation: string;
  tags: string[];
  /** 多对多关系：一个单词可属于多个自定义分类。 */
  deckIds: string[];
  /** 可选的教材单元/自定义分组。未填写时按词库的每组词数自动分组。 */
  unit?: string;
  /** 兼容上一版本的单值字段，读取时会迁移到 deckIds。 */
  deckId?: string;
  status: WordStatus;
  difficulty: number;
  stability: number;
  repetitions: number;
  interval: number;
  /** 记忆路径中的第几个复习周期，最多显示到第 7 周期。 */
  reviewCycle?: number;
  dueDate: string | null;
  lastReview: string | null;
  /** 最近一次由用户主动清除学习周期、重新开始学习的时间。 */
  relearnedAt?: string;
  createdAt: string;
  reviewHistory: ReviewRecord[];
  audio?: {
    wordGeneratedAt?: string;
    kanaGeneratedAt?: string;
    exampleGeneratedAt?: string;
    voice?: VoicePreference;
  };
  note?: string;
  favorite?: boolean;
  verbForms?: VerbForms;
  relatedWords?: string[];
  synonyms?: string[];
  antonyms?: string[];
}

export interface ReviewRecord {
  id: string;
  wordId: string;
  rating: Rating;
  reviewedAt: string;
  previousInterval: number;
  newInterval: number;
  /** 这次记录是否是该单词从 NEW 状态进入首次学习。 */
  wasNew?: boolean;
  responseTimeMs?: number;
  canonicalKey?: string;
}

export interface ReviewInterval {
  value: number;
  unit: "minutes" | "hours" | "days";
}

export interface Deck {
  id: string;
  name: string;
  /** 决定录词字段、学习方向和浏览器发音语言。 */
  language?: StudyLanguage;
  /** 左侧词库子菜单归属；null 表示未分类。 */
  menuId?: string | null;
  description?: string;
  coverDataUrl?: string;
  dailyNewLimit: number;
  dailyReviewLimit: number;
  /** 当前词库答错后的短间隔重学步骤。 */
  relearningStepsMinutes?: number[];
  /** 本词库掌握路径中各周期的复习间隔，从第一次到第七次。 */
  reviewIntervals?: ReviewInterval[];
  /** 每日安排的学习组数，以及每组默认词数。 */
  dailyGroupCount: number;
  wordsPerGroup: number;
  /** 当前词库共享的单词变形标签，新增后会显示在同词库其他单词中。 */
  wordFormLabels?: string[];
  /** 用户可维护的目录子菜单；为空时沿用自动分组。 */
  units?: string[];
  order: "due_first" | "new_first" | "random";
  /** 新词学习测试方式，只允许输入或听音。 */
  learningMode: TestMode;
  /** 到期复习测试方式，只允许输入或听音。 */
  reviewMode?: TestMode;
  autoSpeak: boolean;
  voice: VoicePreference;
  createdAt: string;
  updatedAt?: string;
  lastStudiedAt?: string | null;
}

export interface AppSettings {
  dailyNewLimit: number;
  dailyReviewLimit: number;
  order: "due_first" | "new_first" | "random";
  defaultMode: LearningMode;
  theme: ThemeMode;
  /** 标准色或更克制的灰白低饱和色调。 */
  colorStyle: ColorStyle;
  accentColor: AccentColor;
  /** 是否让主强调色随标准、低饱和、简洁模式切换。 */
  accentFollowColorStyle: boolean;
  voice: VoicePreference;
  uiScale: 0.9 | 1 | 1.1 | 1.2;
  /** 用户上传的品牌图标，以 Data URL 保存在本地设置中。 */
  brandIconDataUrl?: string;
  /** 当前启用的本地字体资源。字体文件本体保存在 IndexedDB assets 表。 */
  customFontAssetId?: string;
  /** 详情页确认行为：用户主动关闭后才会跳过后续提示。 */
  skipRelearnConfirmation?: boolean;
  skipDeleteConfirmation?: boolean;
  reviewAlgorithm: "SM2";
  relearningStepsMinutes: number[];
  /** 用户自定义的词库子菜单，顺序即侧栏显示顺序。 */
  libraryMenus: LibraryMenu[];
  /** 左侧主导航的用户自定义顺序。 */
  navigationOrder: NavigationItemId[];
  /** 词库、学习、复习、笔记四个文件夹各自独立的展开状态。 */
  navigationExpanded: Record<NavigationFolderId, boolean>;
  account: {
    displayName: string;
    email: string;
    signedIn: boolean;
  };
}

export interface SchedulerResult {
  interval: number;
  dueDate: string;
  difficulty: number;
  stability: number;
  repetitions: number;
  reviewCycle: number;
  status: WordStatus;
}
