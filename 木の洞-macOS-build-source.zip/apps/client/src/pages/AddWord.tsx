import { ArrowLeft, Check, Plus, Save, Star, Trash2, Volume2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useAppState } from "@/services/AppState";
import { useKonohaAccount } from "@/services/KonohaAccount";
import { createId } from "@/services/storage";
import { playConfiguredTextAudio, playVocabularyAudio } from "@/services/tts";
import type { StudyLanguage, WordCard } from "@/types";

const blank = (deckIds: string[], language: StudyLanguage = "ja"): WordCard => ({ id: createId(), language, word: "", kana: "", pitchAccent: "", meaning: "", partOfSpeech: "", example: "", exampleTranslation: "", tags: [], deckIds, unit: "", status: "NEW", difficulty: 2.5, stability: 0, repetitions: 0, interval: 0, dueDate: null, lastReview: null, createdAt: new Date().toISOString(), reviewHistory: [], audio: { voice: "natural" } });

export default function AddWord() {
  const { ready, words, decks, localAssets, settings, upsertWord, removeWord } = useAppState();
  const { currentAccount } = useKonohaAccount();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const editId = params.get("id");
  const requestedDeckId = params.get("deck");
  const requestedLanguage = params.get("language") === "en" ? "en" : params.get("language") === "ja" ? "ja" : null;
  const editing = editId ? words.find((word) => word.id === editId) : null;
  const [form, setForm] = useState<WordCard>(() => blank([], requestedLanguage ?? "ja"));
  const initialized = useRef(false);
  const [saved, setSaved] = useState(false);
  const [playing, setPlaying] = useState<"word" | "example" | null>(null);

  useEffect(() => {
    if (!ready || initialized.current) return;
    if (editing) {
      setForm(editing);
      initialized.current = true;
      return;
    }
    const requestedDeck = requestedDeckId ? decks.find((deck) => deck.id === requestedDeckId) : null;
    const language = requestedDeck?.language ?? requestedLanguage ?? decks[0]?.language ?? "ja";
    const initialDeck = requestedDeck ?? decks.find((deck) => (deck.language ?? "ja") === language);
    setForm(blank(initialDeck ? [initialDeck.id] : [], language));
    initialized.current = true;
  }, [decks, editing, ready, requestedDeckId, requestedLanguage]);
  const update = (key: keyof WordCard, value: string | string[] | boolean) => setForm((current) => ({ ...current, [key]: value }));
  const language = form.language ?? "ja";
  const languageName = language === "en" ? "英语" : "日语";
  const availableDecks = decks.filter((deck) => (deck.language ?? "ja") === language);
  const languageLocked = Boolean(editing || requestedDeckId);

  function changeLanguage(nextLanguage: StudyLanguage) {
    setForm((current) => ({
      ...current,
      language: nextLanguage,
      deckIds: current.deckIds.filter((deckId) => (decks.find((deck) => deck.id === deckId)?.language ?? "ja") === nextLanguage),
    }));
  }

  async function submit(continueAdding = false) {
    if (!form.word.trim() || !form.meaning.trim() || !form.deckIds.length) return;
    await upsertWord({ ...form, language, word: form.word.trim(), meaning: form.meaning.trim() });
    setSaved(true);
    if (continueAdding) setForm(blank(form.deckIds, language));
    else navigate("/decks");
  }

  async function preview(text: string, type: "word" | "example") {
    if (!text.trim()) return;
    setPlaying(type);
    await (type === "word"
      ? playVocabularyAudio({ word: text, language }, localAssets, { voice: settings.voice, desktopUserId: currentAccount?.id })
      : playConfiguredTextAudio(text, language, { voice: settings.voice, desktopUserId: currentAccount?.id }));
    setPlaying(null);
  }

  return <div className="page-stack narrow-page">
    <Link to="/decks" className="back-link"><ArrowLeft size={17} /> 返回词库</Link>
    <section className="page-heading compact-heading">
      <div><p className="eyebrow">{editing ? "编辑单词" : "添加单词"}</p><h1>{editing ? `编辑「${editing.word}」` : `记录一个${languageName}单词`}</h1><p className="muted">单词只加入同语言词库，复习进度与笔记会保持联动。</p></div>
      {editing && <button className="button button-danger ghost-danger" onClick={() => { if (window.confirm("确定删除这个单词吗？")) { void removeWord(editing.id); navigate("/decks"); } }}><Trash2 size={16} /> 删除</button>}
    </section>
    <div className="form-card">
      <div className="form-grid">
        <label className="field wide"><span>学习语言</span><select value={language} disabled={languageLocked} onChange={(event) => changeLanguage(event.target.value as StudyLanguage)}><option value="ja">日语</option><option value="en">英语</option></select>{languageLocked && <small className="field-hint">已由当前词库确定，防止单词加入错误语言的词库。</small>}</label>
        <AudioField label={language === "en" ? "英语单词" : "日语单词"} required value={form.word} onChange={(value) => update("word", value)} onPlay={() => void preview(form.word, "word")} playing={playing === "word"} placeholder={language === "en" ? "例如：remember" : "例如：食べる"} />
        <Field label={language === "en" ? "音标 / 发音提示" : "假名"} value={form.kana} onChange={(value) => update("kana", value)} placeholder={language === "en" ? "例如：/rɪˈmembər/" : "例如：たべる"} />
        {language === "ja" && <Field label="音调" value={form.pitchAccent ?? ""} onChange={(value) => update("pitchAccent", value)} placeholder="例如：0（平板）或 2（中高）" />}
        <Field label="中文释义" required value={form.meaning} onChange={(value) => update("meaning", value)} placeholder={language === "en" ? "例如：记得；记住" : "例如：吃"} />
        <Field label="词性" value={form.partOfSpeech} onChange={(value) => update("partOfSpeech", value)} placeholder={language === "en" ? "例如：verb" : "例如：他动词"} />
        <AudioField label="例句" wide value={form.example} onChange={(value) => update("example", value)} onPlay={() => void preview(form.example, "example")} playing={playing === "example"} placeholder={language === "en" ? "Please remember this word." : "毎朝パンを食べます。"} />
        <Field label="例句翻译" wide value={form.exampleTranslation} onChange={(value) => update("exampleTranslation", value)} placeholder={language === "en" ? "请记住这个单词。" : "每天早上吃面包。"} />
        <Field label="标签" wide value={form.tags.join("、")} onChange={(value) => update("tags", value.split(/[，,、\s]+/).filter(Boolean))} placeholder={language === "en" ? "CET4、动词" : "N5、动词"} />
        <Field label="我的笔记" wide value={form.note ?? ""} onChange={(value) => update("note", value)} placeholder="记录联想、易错点或固定搭配" />
        <label className={`favorite-field ${form.favorite ? "selected" : ""}`}><input type="checkbox" checked={Boolean(form.favorite)} onChange={(event) => update("favorite", event.target.checked)} /><Star size={15} fill={form.favorite ? "currentColor" : "none"} /><span>设为重点单词</span></label>
        <div className="field wide"><span>加入{languageName}词库</span><div className="deck-checks">{availableDecks.map((deck) => <label key={deck.id}><input type="checkbox" checked={form.deckIds.includes(deck.id)} onChange={(event) => setForm((current) => ({ ...current, deckIds: event.target.checked ? [...current.deckIds, deck.id] : current.deckIds.filter((id) => id !== deck.id) }))} /><span>{deck.name}</span></label>)}{!availableDecks.length && <span className="form-empty-hint">请先在词库页新建一个{languageName}词库。</span>}</div></div>
      </div>
      <div className="audio-note"><Volume2 size={15} /><span>发音会根据单词语言自动使用设备中的{languageName}声音，不会混用日语和英语语音。</span></div>
      <details className="advanced-fields"><summary>{language === "ja" ? "单词变形（可选）" : "相关词（可选）"}</summary><div className="form-grid">{language === "ja" && <><Field label="辞书形" value={form.verbForms?.dictionary ?? ""} onChange={(value) => setForm((current) => ({ ...current, verbForms: { ...current.verbForms, dictionary: value } }))} /><Field label="ます形" value={form.verbForms?.masu ?? ""} onChange={(value) => setForm((current) => ({ ...current, verbForms: { ...current.verbForms, masu: value } }))} /><Field label="て形" value={form.verbForms?.te ?? ""} onChange={(value) => setForm((current) => ({ ...current, verbForms: { ...current.verbForms, te: value } }))} /><Field label="ない形" value={form.verbForms?.nai ?? ""} onChange={(value) => setForm((current) => ({ ...current, verbForms: { ...current.verbForms, nai: value } }))} /><Field label="た形" value={form.verbForms?.ta ?? ""} onChange={(value) => setForm((current) => ({ ...current, verbForms: { ...current.verbForms, ta: value } }))} /></>}<Field label="相关词" wide={language === "en"} value={form.relatedWords?.join("、") ?? ""} onChange={(value) => setForm((current) => ({ ...current, relatedWords: value.split(/[，,、\s]+/).filter(Boolean) }))} /></div></details>
      <div className="form-footer"><div className={`save-note ${saved ? "visible" : ""}`}><Check size={15} /> 已保存</div><div className="form-actions"><button className="button button-secondary" disabled={!availableDecks.length} onClick={() => void submit(true)}><Plus size={16} /> 保存并继续</button><button className="button button-primary" disabled={!availableDecks.length} onClick={() => void submit()}><Save size={16} /> 保存单词</button></div></div>
    </div>
  </div>;
}

function Field({ label, value, onChange, placeholder, required, wide }: { label: string; value: string; onChange: (value: string) => void; placeholder?: string; required?: boolean; wide?: boolean }) {
  return <label className={`field ${wide ? "wide" : ""}`}><span>{label}{required && <em>*</em>}</span><input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} /></label>;
}

function AudioField({ label, value, onChange, onPlay, playing, placeholder, required, wide }: { label: string; value: string; onChange: (value: string) => void; onPlay: () => void; playing: boolean; placeholder?: string; required?: boolean; wide?: boolean }) {
  return <label className={`field audio-field ${wide ? "wide" : ""}`}><span>{label}{required && <em>*</em>} <button type="button" className={`inline-audio ${playing ? "playing" : ""}`} onClick={onPlay} aria-label={`播放${label}`}><Volume2 size={13} /></button></span><input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} /></label>;
}
