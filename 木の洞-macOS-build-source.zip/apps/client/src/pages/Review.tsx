import { BookOpenCheck, CalendarClock, CheckCircle2, Clock3, RotateCcw } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link, Navigate, useSearchParams } from "react-router-dom";
import { WordDetailModal } from "./DeckDetail";
import { useAppState } from "@/services/AppState";
import { DEFAULT_REVIEW_INTERVALS } from "@/services/storage";
import type { Deck, ReviewInterval, WordCard } from "@/types";

export default function Review() {
  const { words, decks, updateDeck, upsertWord, relearnWords, removeWord } = useAppState();
  const [params] = useSearchParams();
  const selectedDeckId = params.get("deck");
  const selectedDeck = decks.find((deck) => deck.id === selectedDeckId);
  const scopedWords = selectedDeck ? words.filter((word) => word.deckIds.includes(selectedDeck.id)) : [];
  const dueForDeck = (deck: Deck) => words.filter((word) => word.deckIds.includes(deck.id) && word.status !== "SUSPENDED" && word.dueDate && new Date(word.dueDate).getTime() <= Date.now());
  const due = scopedWords.filter((word) => word.dueDate && new Date(word.dueDate).getTime() <= Date.now() && word.status !== "SUSPENDED");
  const learning = scopedWords.filter((word) => word.status === "LEARNING" || word.status === "RELEARNING");
  const mature = scopedWords.filter((word) => word.status === "MATURE");
  const now = new Date();
  const tomorrowStart = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1);
  const tomorrowEnd = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 2);
  const tomorrowDue = scopedWords.filter((word) => {
    if (!word.dueDate || word.status === "SUSPENDED") return false;
    const dueTime = new Date(word.dueDate).getTime();
    return dueTime >= tomorrowStart.getTime() && dueTime < tomorrowEnd.getTime();
  });
  const intervals = selectedDeck?.reviewIntervals ?? DEFAULT_REVIEW_INTERVALS;
  const [draftIntervals, setDraftIntervals] = useState(intervals);
  const [modal, setModal] = useState<"due" | "learning" | "mature" | "tomorrow" | null>(null);
  const [sortKey, setSortKey] = useState<"time" | "score" | "reviews" | "word" | "familiarity">("time");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("asc");
  const [selectedWordId, setSelectedWordId] = useState<string | null>(null);
  const selectedWord = selectedWordId ? words.find((word) => word.id === selectedWordId) ?? null : null;
  useEffect(() => setDraftIntervals(intervals), [selectedDeck?.id, selectedDeck?.updatedAt]);
  async function saveInterval(index: number, interval: ReviewInterval) {
    if (!selectedDeck) return;
    const next = draftIntervals.map((item, itemIndex) => itemIndex === index ? interval : item);
    setDraftIntervals(next);
    await updateDeck({ ...selectedDeck, reviewIntervals: next, updatedAt: new Date().toISOString() });
  }
  const sortedDue = useMemo(() => [...due].sort((a, b) => {
    const value = sortKey === "time"
      ? new Date(a.dueDate ?? 0).getTime() - new Date(b.dueDate ?? 0).getTime()
      : sortKey === "score"
        ? a.stability - b.stability
        : sortKey === "reviews"
          ? a.repetitions - b.repetitions
          : sortKey === "word"
            ? a.word.localeCompare(b.word, "ja")
            : (a.reviewCycle ?? a.repetitions) - (b.reviewCycle ?? b.repetitions);
    return sortDirection === "asc" ? value : -value;
  }), [due, sortDirection, sortKey]);
  const sortedTomorrow = useMemo(() => [...tomorrowDue].sort((a, b) => {
    const value = sortKey === "time"
      ? new Date(a.dueDate ?? 0).getTime() - new Date(b.dueDate ?? 0).getTime()
      : sortKey === "score"
        ? a.stability - b.stability
        : sortKey === "reviews"
          ? a.repetitions - b.repetitions
          : sortKey === "word"
            ? a.word.localeCompare(b.word, "ja")
            : (a.reviewCycle ?? a.repetitions) - (b.reviewCycle ?? b.repetitions);
    return sortDirection === "asc" ? value : -value;
  }), [sortDirection, sortKey, tomorrowDue]);
  const closeModal = () => setModal(null);
  useEffect(() => {
    if (!modal && !selectedWordId) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      if (selectedWordId) setSelectedWordId(null);
      else closeModal();
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [modal, selectedWordId]);
  if (!selectedDeckId && decks[0]) return <Navigate to={`/review?deck=${encodeURIComponent(decks[0].id)}`} replace />;
  if (selectedDeckId && !selectedDeck) return <div className="empty-library"><h3>找不到这个复习词库</h3><p>请从左侧复习子菜单重新选择。</p></div>;
  return <div className="page-stack review-page"><section className="page-heading"><div><p className="eyebrow">{selectedDeck?.language === "en" ? "英语复习" : "日语复习"}</p><h1>{selectedDeck?.name ?? "今天的复习计划"}</h1><p className="muted">选择词库后，只学习该词库的到期内容。</p></div><Link to={`/study?deck=${encodeURIComponent(selectedDeck?.id ?? "")}&session=review`} className="button button-primary"><BookOpenCheck size={17} /> 开始复习测试</Link></section><section className="review-deck-switcher review-panel"><div className="review-panel-heading"><div><h2>词库复习安排</h2><p className="muted">每个词库都有独立的今日数量和复习周期。</p></div></div><div className="review-deck-grid">{decks.map((deck) => <Link key={deck.id} to={`/review?deck=${encodeURIComponent(deck.id)}`} className={`review-deck-card ${deck.id === selectedDeck?.id ? "active" : ""}`}><div><strong>{deck.name}</strong><span>{deck.language === "en" ? "英语" : "日语"} · 今日待复习</span></div><b>{dueForDeck(deck).length}</b></Link>)}</div></section><section className="review-summary-grid"><ReviewStat icon={<CalendarClock size={18} />} label="今日复习" value={due.length} hint="点击查看全部待复习单词" tone="coral" onClick={() => setModal("due")} /><ReviewStat icon={<RotateCcw size={18} />} label="学习中" value={learning.length} hint="点击查看学习中单词" tone="blue" onClick={() => setModal("learning")} /><ReviewStat icon={<CheckCircle2 size={18} />} label="已掌握" value={mature.length} hint="点击查看已掌握单词" tone="green" onClick={() => setModal("mature")} /><ReviewStat icon={<Clock3 size={18} />} label="明日复习" value={tomorrowDue.length} hint="点击查看明天要复习的单词" tone="violet" onClick={() => setModal("tomorrow")} /></section><section className="review-panel"><div className="review-panel-heading"><div><h2>复习周期</h2><p className="muted">复习方式：{selectedDeck?.reviewMode === "LISTENING" ? "听音测试" : "输入测试"}；两轮全对才过关。</p></div><span className="review-edit-hint">点击卡片直接调整</span></div><div className="cycle-grid">{intervals.map((interval, index) => <CycleCard key={`${index}-${interval.value}`} number={String(index + 1)} days={formatInterval(interval)} label={index === 0 ? "第一次学习" : `周期 ${index + 1}`} tone={index === 0 ? "coral" : "blue"} editable interval={draftIntervals[index] ?? interval} onSave={(next) => void saveInterval(index, next)} />)}<CycleCard number="✓" days="已掌握" label="稳定记忆" tone="green" /></div></section>{modal && <FloatingModal title={modal === "due" ? "今日复习" : modal === "learning" ? "学习中" : modal === "mature" ? "已掌握" : "明日复习"} onClose={closeModal}>{modal === "due" ? <DueWordsModal words={sortedDue} sortKey={sortKey} direction={sortDirection} onSort={(key) => { if (sortKey === key) setSortDirection(sortDirection === "asc" ? "desc" : "asc"); else { setSortKey(key); setSortDirection("asc"); } }} onSelectWord={setSelectedWordId} /> : modal === "tomorrow" ? <DueWordsModal words={sortedTomorrow} sortKey={sortKey} direction={sortDirection} onSort={(key) => { if (sortKey === key) setSortDirection(sortDirection === "asc" ? "desc" : "asc"); else { setSortKey(key); setSortDirection("asc"); } }} onSelectWord={setSelectedWordId} /> : <WordListModal words={modal === "learning" ? learning : mature} emptyText={modal === "learning" ? "当前没有学习中的单词。" : "当前没有已掌握单词。"} onSelectWord={setSelectedWordId} />}</FloatingModal>}{selectedWord && selectedDeck && <WordDetailModal word={selectedWord} deck={selectedDeck} voice={selectedDeck.voice} onClose={() => setSelectedWordId(null)} onSave={upsertWord} onRelearn={async () => { await relearnWords([selectedWord.id]); }} onDelete={async () => { await removeWord(selectedWord.id); setSelectedWordId(null); }} onSaveWordFormLabels={async (labels) => { await updateDeck({ ...selectedDeck, wordFormLabels: labels, updatedAt: new Date().toISOString() }); }} />}</div>;
}

function formatInterval(interval: ReviewInterval) {
  const units = { minutes: "分钟后", hours: "小时后", days: "天后" };
  return `${interval.value}${units[interval.unit]}`;
}

function ReviewStat({ icon, label, value, hint, tone, onClick }: { icon: React.ReactNode; label: string; value: number; hint: string; tone: string; onClick: () => void }) {
  return <button type="button" className="review-stat review-stat-button" onClick={onClick}><div className={`review-stat-icon ${tone}`}>{icon}</div><div><span>{label}</span><strong>{value}</strong><small>{hint}</small></div></button>;
}

function FloatingModal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="floating-modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) onClose(); }}><section className="floating-modal" role="dialog" aria-modal="true" aria-label={title}><header className="floating-modal-header"><div><p className="eyebrow">木の洞 · 复习</p><h2>{title}</h2></div><button type="button" className="icon-button" onClick={onClose} aria-label="关闭"><span aria-hidden="true">×</span></button></header><div className="floating-modal-content">{children}</div></section></div>;
}

function WordListModal({ words, emptyText, onSelectWord }: { words: WordCard[]; emptyText: string; onSelectWord: (wordId: string) => void }) {
  return words.length ? <div className="floating-word-list">{words.map((word) => <ReviewWordRow key={word.id} word={word} onSelect={() => onSelectWord(word.id)} />)}</div> : <div className="review-empty">{emptyText}</div>;
}

function DueWordsModal({ words, sortKey, direction, onSort, onSelectWord }: { words: WordCard[]; sortKey: string; direction: "asc" | "desc"; onSort: (key: "time" | "score" | "reviews" | "word" | "familiarity") => void; onSelectWord: (wordId: string) => void }) {
  const options = [["time", "时间"], ["score", "分数"], ["reviews", "复习次数"], ["word", "单词"], ["familiarity", "熟悉程度"]] as const;
  return <div><div className="floating-sort-toolbar"><span>共 {words.length} 个</span><div>{options.map(([key, label]) => <button key={key} type="button" className={sortKey === key ? "active" : ""} onClick={() => onSort(key)}>{label}{sortKey === key ? ` ${direction === "asc" ? "↑" : "↓"}` : ""}</button>)}</div></div><WordListModal words={words} emptyText="今天没有待复习单词。" onSelectWord={onSelectWord} /></div>;
}

function ReviewWordRow({ word, onSelect }: { word: WordCard; onSelect: () => void }) {
  const cycle = Math.min(7, word.reviewCycle ?? word.repetitions);
  const detailTags = uniqueNonEmpty([word.partOfSpeech, ...word.tags]);
  const score = word.status === "MATURE" ? "100分" : `${Math.round(Math.min(99, Math.max(0, word.stability * 5)))}分`;
  const pronunciation = word.kana?.trim();
  return <button type="button" className="floating-word-row floating-word-row-button" onClick={onSelect} aria-label={`查看${word.word}的单词详情`}><div className="floating-word-main"><div className="floating-word-title"><strong>{word.word}</strong>{pronunciation && <span className="floating-word-kana">{pronunciation}</span>}{word.language !== "en" && word.pitchAccent?.trim() && <b className="floating-pitch">{formatPitchAccent(word.pitchAccent)}</b>}</div><div className="floating-word-meta"><span className="floating-score">{score}</span><span className="floating-cycle">周期 {cycle}</span>{detailTags.map((tag) => <span className="floating-word-tag" key={tag}>{tag}</span>)}{word.favorite && <span className="floating-favorite">重点</span>}<span className="floating-meaning">{word.meaning}</span></div></div></button>;
}

function uniqueNonEmpty(values: Array<string | undefined>) {
  return [...new Set(values.map((value) => value?.trim()).filter((value): value is string => Boolean(value)))];
}

function formatPitchAccent(value?: string) {
  const normalized = value?.trim();
  if (!normalized) return "";
  const circles = ["⓪", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨"];
  if (/^\d+$/.test(normalized)) return normalized.split("").map((digit) => circles[Number(digit)] ?? digit).join("");
  return normalized;
}

function CycleCard({ number, days, label, tone, editable, interval, onSave }: { number: string; days: string; label: string; tone: string; editable?: boolean; interval?: ReviewInterval; onSave?: (interval: ReviewInterval) => void }) {
  const [editing, setEditing] = useState(false);
  const [value, setValue] = useState(String(interval?.value ?? ""));
  const [unit, setUnit] = useState<ReviewInterval["unit"]>(interval?.unit ?? "days");
  useEffect(() => {
    if (!editing && interval) { setValue(String(interval.value)); setUnit(interval.unit); }
  }, [editing, interval]);
  const save = () => { const nextValue = Math.max(1, Number(value) || 1); onSave?.({ value: nextValue, unit }); setValue(String(nextValue)); setEditing(false); };
  if (editing && interval) return <div className={`cycle-card ${tone} editing`}><strong>{number}</strong><span>{label}</span><div className="cycle-editor"><input type="number" min={1} step={1} value={value} onChange={(event) => setValue(event.target.value)} aria-label={`${label}数值`} /><select value={unit} onChange={(event) => setUnit(event.target.value as ReviewInterval["unit"])} aria-label={`${label}单位`}><option value="minutes">分钟</option><option value="hours">小时</option><option value="days">天</option></select></div><div className="cycle-editor-actions"><button type="button" className="button button-primary compact" onClick={save}>保存</button><button type="button" className="button button-secondary compact" onClick={() => setEditing(false)}>取消</button></div></div>;
  return <button type="button" className={`cycle-card ${tone} ${editable ? "editable" : ""}`} onClick={() => editable && setEditing(true)} disabled={!editable} aria-label={editable ? `编辑${label}：${days}` : label}><strong>{number}</strong><span>{label}</span><em>{days}</em><i>{editable ? "›" : ""}</i></button>;
}
