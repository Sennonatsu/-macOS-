import {
  ArrowLeft,
  Check,
  ChevronDown,
  ChevronRight,
  Download,
  Edit3,
  NotebookPen,
  Plus,
  RotateCcw,
  Save,
  Settings2,
  Star,
  Trash2,
  Volume2,
  X,
} from "lucide-react";
import { useEffect, useMemo, useState, type ChangeEvent, type KeyboardEvent } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useAppState } from "@/services/AppState";
import { useKonohaAccount } from "@/services/KonohaAccount";
import { exportWordsCsv } from "@/services/csv";
import { buildWordGroups } from "@/services/wordGroups";
import { playConfiguredTextAudio, playVocabularyAudio } from "@/services/tts";
import type { Deck, StudyLanguage, VerbForms, WordCard } from "@/types";
import { DEFAULT_REVIEW_INTERVALS } from "@/services/storage";

export default function DeckDetail() {
  const { deckId } = useParams();
  const navigate = useNavigate();
  const { ready, decks, words, upsertWord, relearnWords, removeWord, updateDeck } =
    useAppState();
  const [showPlan, setShowPlan] = useState(false);
  const [showUnits, setShowUnits] = useState(false);
  const [showRelearn, setShowRelearn] = useState(false);
  const [selectedWord, setSelectedWord] = useState<WordCard | null>(null);
  const [tab, setTab] = useState<"catalog" | "intro" | "settings">("catalog");
  const [selectedUnit, setSelectedUnit] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<
    "all" | "NEW" | "LEARNING" | "REVIEW" | "MATURE"
  >("all");
  const [sortMode, setSortMode] = useState<"order" | "score" | "alpha">(
    "order",
  );
  const deck = decks.find((item) => item.id === deckId);
  const deckWords = useMemo(
    () => words.filter((word) => deck && word.deckIds.includes(deck.id)),
    [deck, words],
  );
  const groups = useMemo(
    () => (deck ? buildWordGroups(deck, deckWords) : []),
    [deck, deckWords],
  );
  const visibleWords = useMemo(() => {
    const source = selectedUnit
      ? (groups.find((group) => group.label === selectedUnit)?.words ?? [])
      : deckWords;
    const filtered =
      statusFilter === "all"
        ? source
        : source.filter((word) => word.status === statusFilter);
    return [...filtered].sort((a, b) => {
      if (sortMode === "score")
        return b.stability - a.stability || b.repetitions - a.repetitions;
      if (sortMode === "alpha") return a.word.localeCompare(b.word, "ja");
      return source.indexOf(a) - source.indexOf(b);
    });
  }, [deckWords, groups, selectedUnit, sortMode, statusFilter]);

  function downloadDeckCsv() {
    const blob = new Blob([exportWordsCsv(deckWords)], {
      type: "text/csv;charset=utf-8",
    });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `木の洞-${deck?.name.replace(/[\\/:*?"<>|]/g, "-") ?? "词库"}.csv`;
    anchor.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  if (!ready) return <div className="loading-state">正在打开词库…</div>;
  if (!deck)
    return (
      <div className="empty-library">
        <h3>找不到这个词库</h3>
        <Link to="/decks" className="button button-primary">
          返回词库
        </Link>
      </div>
    );

  const learned = deckWords.filter((word) => word.status !== "NEW").length;
  const mastered = deckWords.filter((word) => word.status === "MATURE").length;
  const unseen = deckWords.filter((word) => word.status === "NEW").length;

  return (
    <div className="page-stack deck-detail-page">
      <section className="detail-heading">
        <div>
          <Link to="/decks" className="back-link">
            <ArrowLeft size={17} /> 返回词库
          </Link>
          <div className="detail-title-row">
            <div className="deck-detail-cover">
              {deck.coverDataUrl ? (
                <img src={deck.coverDataUrl} alt="" />
              ) : (
                <span>{deck.name.slice(0, 3)}</span>
              )}
            </div>
            <div>
              <p className="eyebrow">
                {deck.language === "en" ? "英语词库" : "日语词库"}
              </p>
              <h1>{deck.name}</h1>
              <div className="detail-metrics">
                <span>
                  共 <strong>{deckWords.length}</strong> 词
                </span>
                <span>
                  重点{" "}
                  <strong>
                    {deckWords.filter((word) => word.favorite).length}
                  </strong>
                </span>
                <span>
                  笔记{" "}
                  <strong>
                    {deckWords.filter((word) => word.note?.trim()).length}
                  </strong>
                </span>
                <span>
                  掌握 <strong>{mastered}</strong>
                </span>
                <span>
                  已学 <strong>{learned}</strong>
                </span>
                <span>
                  未学 <strong>{unseen}</strong>
                </span>
              </div>
            </div>
          </div>
        </div>
        <button
          className="button button-primary"
          onClick={() => navigate(`/add-word?deck=${encodeURIComponent(deck.id)}`)}
        >
          <Plus size={17} /> 添加单词
        </button>
      </section>
      <section className="detail-plan-bar">
        <div>
          <strong>每日新词 {deck.dailyNewLimit} 个</strong>
          <span>当前词库独立计划</span>
        </div>
        <div className="detail-plan-actions">
          <button
            className="icon-text-button"
            onClick={() => setShowUnits(true)}
          >
            <Edit3 size={14} /> 管理目录
          </button>
          <button
            className="icon-text-button"
            onClick={() => setTab("settings")}
          >
            <Settings2 size={14} /> 设置
          </button>
        </div>
      </section>
      <section className="detail-tabs" role="tablist">
        <button
          className={tab === "catalog" ? "active" : ""}
          onClick={() => setTab("catalog")}
        >
          目录
        </button>
        <button
          className={tab === "intro" ? "active" : ""}
          onClick={() => setTab("intro")}
        >
          简介
        </button>
        <button
          className={tab === "settings" ? "active" : ""}
          onClick={() => setTab("settings")}
        >
          设置
        </button>
      </section>
      {tab === "catalog" ? (
        <>
          <section className="unit-menu">
            <div className="unit-menu-heading">
              <span>共 {deckWords.length} 项</span>
              <small>
                {selectedUnit ? `当前：${selectedUnit}` : "按单元浏览"}
              </small>
            </div>
            <button
              className={`unit-row ${selectedUnit === null ? "selected" : ""}`}
              onClick={() => setSelectedUnit(null)}
            >
              <ChevronDown size={16} />
              <span>全部词汇</span>
              <small>{deckWords.length} 词</small>
            </button>
            {groups.map((group) => (
              <button
                className={`unit-row ${selectedUnit === group.label ? "selected" : ""}`}
                key={group.label}
                onClick={() =>
                  setSelectedUnit(
                    selectedUnit === group.label ? null : group.label,
                  )
                }
              >
                <ChevronDown size={16} />
                <span>{group.label}</span>
                <small>{group.words.length} 词</small>
              </button>
            ))}
          </section>
          <section className="detail-toolbar">
            <p className="muted">
              {visibleWords.length
                ? `${selectedUnit ?? "全部词汇"} · 从上到下浏览单词。`
                : "还没有单词，添加第一个词开始学习。"}
            </p>
            <div className="deck-detail-toolbar-actions">
              <button className="icon-text-button" onClick={downloadDeckCsv}>
                <Download size={15} /> 导出此词库
              </button>
              <Link
                to={`/study?deck=${encodeURIComponent(deck.id)}${selectedUnit ? `&unit=${encodeURIComponent(selectedUnit)}` : ""}`}
                className="text-link"
              >
                开始学习 <ArrowLeft size={14} className="rotate-forward" />
              </Link>
            </div>
          </section>
          <div className="word-filter-bar">
            <div className="word-status-filters">
              {[
                ["all", "全部"],
                ["NEW", "未学习"],
                ["LEARNING", "复习中"],
                ["REVIEW", "待复习"],
                ["MATURE", "已掌握"],
              ].map(([key, label]) => (
                <button
                  key={key}
                  className={statusFilter === key ? "active" : ""}
                  onClick={() => setStatusFilter(key as typeof statusFilter)}
                >
                  {label}
                </button>
              ))}
            </div>
            <div className="word-filter-actions">
              <button
                className="button button-secondary compact"
                onClick={() => setShowRelearn(true)}
                disabled={!deckWords.length}
              >
                <RotateCcw size={14} /> 重学
              </button>
              <select
                value={sortMode}
                onChange={(event) =>
                  setSortMode(event.target.value as typeof sortMode)
                }
                aria-label="单词排序"
              >
                <option value="order">按学习顺序</option>
                <option value="score">按记忆稳定度</option>
                <option value="alpha">按词形排序</option>
              </select>
            </div>
          </div>
          <section className="word-list">
            {visibleWords.map((word, index) => (
              <button
                className="word-list-item"
                key={word.id}
                onClick={() => setSelectedWord(word)}
              >
                <span className="word-index">
                  {String(index + 1).padStart(2, "0")}
                </span>
                <span className="word-primary">
                  <strong>{word.word}</strong>
                  <span>{word.kana}</span>
                  {word.favorite && (
                    <Star
                      size={12}
                      className="favorite-icon"
                      fill="currentColor"
                    />
                  )}
                  {word.note?.trim() && (
                    <NotebookPen size={12} className="note-icon" />
                  )}
                </span>
                <span className="word-meaning">{word.meaning}</span>
                <span className={`status-badge ${word.status.toLowerCase()}`}>
                  {statusLabel(word)}
                </span>
                <span className="word-chevron">›</span>
              </button>
            ))}
          </section>
        </>
      ) : tab === "intro" ? (
        <section className="deck-intro panel">
          <h2>{deck.name}</h2>
          <p>
            {deck.description ||
              `这是一个可以按单元浏览、按组学习的${deck.language === "en" ? "英语" : "日语"}词库。`}
          </p>
          <div className="intro-facts">
            <span>
              单词总数 <strong>{deckWords.length}</strong>
            </span>
            <span>
              每日新词 <strong>{deck.dailyNewLimit} 个</strong>
            </span>
            <span>
              当前进度{" "}
              <strong>
                {deckWords.length
                  ? Math.round((learned / deckWords.length) * 100)
                  : 0}
                %
              </strong>
            </span>
          </div>
        </section>
      ) : (
        <DeckLearningSettings
          deck={deck}
          onSave={async (next) => {
            await updateDeck(next);
          }}
          onOpenAdvanced={() => setShowPlan(true)}
        />
      )}
      {showRelearn && (
        <RelearnModal
          words={deckWords}
          groups={groups}
          onClose={() => setShowRelearn(false)}
          onConfirm={async (wordIds) => {
            await relearnWords(wordIds);
            setSelectedWord(null);
            setStatusFilter("NEW");
            setShowRelearn(false);
          }}
        />
      )}
      {showPlan && (
        <GroupPlanModal
          deck={deck}
          onClose={() => setShowPlan(false)}
          onSave={async (next) => {
            await updateDeck(next);
            setShowPlan(false);
          }}
        />
      )}
      {showUnits && (
        <UnitManagerModal
          deck={deck}
          groups={groups.map((group) => group.label)}
          onClose={() => setShowUnits(false)}
          onSave={async (units, removed) => {
            await Promise.all(
              deckWords
                .filter((word) => removed.includes(word.unit?.trim() ?? ""))
                .map((word) => upsertWord({ ...word, unit: "" })),
            );
            await updateDeck({ ...deck, units });
            setShowUnits(false);
          }}
        />
      )}
      {selectedWord && (
        <WordDetailModal
          word={selectedWord}
          deck={deck}
          voice={deck.voice}
          onClose={() => setSelectedWord(null)}
          onSave={async (updated) => {
            await upsertWord(updated);
            setSelectedWord(updated);
          }}
          onRelearn={async () => {
            await relearnWords([selectedWord.id]);
            setSelectedWord(null);
            setStatusFilter("NEW");
          }}
          onDelete={async () => {
            await removeWord(selectedWord.id);
            setSelectedWord(null);
          }}
          onSaveWordFormLabels={async (labels) => {
            await updateDeck({ ...deck, wordFormLabels: labels });
          }}
        />
      )}
    </div>
  );
}

function statusLabel(word: WordCard) {
  const cycle = Math.min(7, word.reviewCycle ?? word.repetitions);
  if (word.status === "NEW" && cycle === 0) return "未学习";
  if (cycle > 0) return `第 ${cycle} 周期`;
  return {
    NEW: "未学习",
    LEARNING: "学习中",
    RELEARNING: "重新学习",
    REVIEW: "待复习",
    MATURE: "已掌握",
    SUSPENDED: "已暂停",
  }[word.status];
}

function DeckLearningSettings({
  deck,
  onSave,
  onOpenAdvanced,
}: {
  deck: Deck;
  onSave: (deck: Deck) => Promise<void>;
  onOpenAdvanced: () => void;
}) {
  const [dailyNewLimit, setDailyNewLimit] = useState(String(deck.dailyNewLimit));
  const [dailyReviewLimit, setDailyReviewLimit] = useState(
    String(deck.dailyReviewLimit),
  );
  const [order, setOrder] = useState(deck.order);
  const [learningMode, setLearningMode] = useState(deck.learningMode);
  const [reviewMode, setReviewMode] = useState(
    deck.reviewMode ?? "TYPE_ANSWER",
  );
  const [relearningSteps, setRelearningSteps] = useState(
    (deck.relearningStepsMinutes ?? [10, 60, 1440]).join(","),
  );
  const [reviewIntervals, setReviewIntervals] = useState(
    (deck.reviewIntervals ?? DEFAULT_REVIEW_INTERVALS).map((interval) => `${interval.value}${interval.unit === "minutes" ? "m" : interval.unit === "hours" ? "h" : "d"}`).join(","),
  );
  const [saved, setSaved] = useState(false);
  const save = async () => {
    const newLimit = Math.max(0, Math.floor(Number(dailyNewLimit) || 0));
    const reviewLimit = Math.max(0, Math.floor(Number(dailyReviewLimit) || 0));
    await onSave({
      ...deck,
      dailyNewLimit: newLimit,
      dailyReviewLimit: reviewLimit,
      order,
      learningMode,
      reviewMode,
      relearningStepsMinutes: relearningSteps.split(",").map(Number),
      reviewIntervals: reviewIntervals.split(",").map((value, index) => {
        const match = value.trim().match(/^(\d+(?:\.\d+)?)(m|h|d)$/i);
        if (!match) return (deck.reviewIntervals ?? DEFAULT_REVIEW_INTERVALS)[index] ?? DEFAULT_REVIEW_INTERVALS[index];
        return { value: Number(match[1]), unit: match[2].toLowerCase() === "m" ? "minutes" : match[2].toLowerCase() === "h" ? "hours" : "days" };
      }),
    });
    setDailyNewLimit(String(newLimit));
    setDailyReviewLimit(String(reviewLimit));
    setSaved(true);
  };
  return (
    <section className="deck-settings-panel panel">
      <div className="deck-settings-copy">
        <p className="eyebrow">当前词库计划</p>
        <h2>学习与复习</h2>
        <p>
          这里的计划只影响「{deck.name}」，不同词库可以分别设置数量、顺序、学习方式与复习方式。
        </p>
      </div>
      <div className="deck-daily-limit">
        <div className="deck-settings-grid">
          <label className="field">
            <span>每日新词</span>
            <div className="number-input-suffix">
              <input type="number" min={0} step={1} inputMode="numeric" value={dailyNewLimit} onChange={(event) => { setDailyNewLimit(event.target.value); setSaved(false); }} />
              <span>个</span>
            </div>
            <small className="field-hint">无上限；设为 0 时暂停新词。</small>
          </label>
          <label className="field">
            <span>每日最大复习</span>
            <div className="number-input-suffix">
              <input type="number" min={0} step={1} inputMode="numeric" value={dailyReviewLimit} onChange={(event) => { setDailyReviewLimit(event.target.value); setSaved(false); }} />
              <span>个</span>
            </div>
            <small className="field-hint">无上限；设为 0 时暂停到期复习。</small>
          </label>
          <label className="field">
            <span>学习顺序</span>
            <select value={order} onChange={(event) => { setOrder(event.target.value as Deck["order"]); setSaved(false); }}>
              <option value="due_first">到期优先</option>
              <option value="new_first">新词优先</option>
              <option value="random">随机</option>
            </select>
          </label>
          <label className="field">
            <span>忘记后的重学间隔</span>
            <select value={relearningSteps} onChange={(event) => { setRelearningSteps(event.target.value); setSaved(false); }}>
              <option value="10,60,1440">10 分钟 · 1 小时 · 1 天</option>
              <option value="5,30,1440">5 分钟 · 30 分钟 · 1 天</option>
              <option value="10,60,2880">10 分钟 · 1 小时 · 2 天</option>
            </select>
          </label>
          <label className="field wide">
            <span>复习周期（按顺序）</span>
            <input value={reviewIntervals} onChange={(event) => { setReviewIntervals(event.target.value); setSaved(false); }} placeholder="10m, 1d, 4d, 7d, 10d, 15d, 20d" />
            <small className="field-hint">用逗号填写 7 个间隔；m=分钟，h=小时，d=天，例如 10m, 1d, 4d。</small>
          </label>
        </div>
        <div className="deck-test-mode-grid">
          <TestModePicker
            label="学习方式"
            value={learningMode}
            onChange={(value) => {
              setLearningMode(value);
              setSaved(false);
            }}
          />
          <TestModePicker
            label="复习方式"
            value={reviewMode}
            onChange={(value) => {
              setReviewMode(value);
              setSaved(false);
            }}
          />
        </div>
        <div className="deck-settings-actions">
          <span className={`note-saved ${saved ? "visible" : ""}`}>
            <Check size={13} /> 已保存并同步主界面
          </span>
          <button className="button button-secondary" onClick={onOpenAdvanced}>
            <Settings2 size={15} /> 目录分组设置
          </button>
          <button className="button button-primary" onClick={() => void save()}>
            <Save size={15} /> 保存每日计划
          </button>
        </div>
      </div>
    </section>
  );
}

function TestModePicker({
  label,
  value,
  onChange,
}: {
  label: string;
  value: Deck["learningMode"];
  onChange: (value: Deck["learningMode"]) => void;
}) {
  return (
    <div className="deck-learning-modes">
      <span>{label}</span>
      <div className="mode-grid compact-mode-grid">
        {([
          {
            key: "TYPE_ANSWER",
            title: "输入测试",
            desc: "先输入读音，再根据中文输入单词",
          },
          {
            key: "LISTENING",
            title: "听音测试",
            desc: "先听发音输入单词，再根据中文输入单词",
          },
        ] as { key: Deck["learningMode"]; title: string; desc: string }[]).map(
          (item) => (
            <button
              key={item.key}
              className={`mode-option ${value === item.key ? "selected" : ""}`}
              onClick={() => onChange(item.key)}
            >
              <div>
                <strong>{item.title}</strong>
                <span>{item.desc}</span>
              </div>
              {value === item.key && <Check size={17} />}
            </button>
          ),
        )}
      </div>
    </div>
  );
}

function dateOnly(value: string) {
  return value.slice(0, 10);
}

function firstLearnedDate(word: WordCard) {
  const reviewsInCurrentCycle = word.relearnedAt
    ? word.reviewHistory.filter(
        (review) => review.reviewedAt >= word.relearnedAt!,
      )
    : word.reviewHistory;
  const firstLearningReview =
    reviewsInCurrentCycle.find((review) => review.wasNew)?.reviewedAt ??
    reviewsInCurrentCycle[0]?.reviewedAt;
  return dateOnly(firstLearningReview ?? word.lastReview ?? word.createdAt);
}

function RelearnModal({
  words,
  groups,
  onClose,
  onConfirm,
}: {
  words: WordCard[];
  groups: ReturnType<typeof buildWordGroups>;
  onClose: () => void;
  onConfirm: (wordIds: string[]) => Promise<void>;
}) {
  const learnedWords = words.filter(
    (word) => word.status !== "NEW" || (word.reviewCycle ?? 0) > 0,
  );
  const dates = [...new Set(learnedWords.map(firstLearnedDate))]
    .sort()
    .reverse();
  const units = groups
    .filter((group) => group.label !== "全部词汇")
    .map((group) => group.label);
  const [scope, setScope] = useState<"date" | "unit" | "all">("date");
  const [selectedDate, setSelectedDate] = useState(dates[0] ?? "");
  const [selectedUnit, setSelectedUnit] = useState(units[0] ?? "");
  const targets =
    scope === "all"
      ? learnedWords
      : scope === "date"
        ? learnedWords.filter(
            (word) => firstLearnedDate(word) === selectedDate,
          )
        : learnedWords.filter((word) =>
            groups
              .find((group) => group.label === selectedUnit)
              ?.words.some((item) => item.id === word.id),
          );
  const confirm = () => {
    if (!targets.length) return;
    const label =
      scope === "all"
        ? "整个词库"
        : scope === "date"
          ? `${selectedDate} 学习的单词`
          : `目录“${selectedUnit}”`;
    if (
      window.confirm(
        `确定让${label}中的 ${targets.length} 个单词重新学习吗？学习周期会清零，重点和笔记会保留。`,
      )
    ) {
      void onConfirm(targets.map((word) => word.id));
    }
  };
  return (
    <div className="modal-backdrop">
      <div className="modal-card relearn-modal">
        <div className="modal-header">
          <div>
            <p className="eyebrow">清除学习周期</p>
            <h2>选择重新学习范围</h2>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭">
            <X size={18} />
          </button>
        </div>
        <p className="modal-copy">
          单词内容、词库归属、重点和笔记都会保留，只把所选单词恢复为未学习。
        </p>
        <div className="relearn-scope-grid">
          <button
            className={scope === "date" ? "selected" : ""}
            onClick={() => setScope("date")}
          >
            <strong>按新学日期</strong>
            <span>重学某一天首次学习过的单词</span>
          </button>
          <button
            className={scope === "unit" ? "selected" : ""}
            onClick={() => setScope("unit")}
          >
            <strong>按目录分类</strong>
            <span>重学某个目录中的已学单词</span>
          </button>
          <button
            className={scope === "all" ? "selected" : ""}
            onClick={() => setScope("all")}
          >
            <strong>全部重学</strong>
            <span>清除整个词库的学习周期</span>
          </button>
        </div>
        {scope === "date" && (
          <label className="field">
            <span>选择新学日期</span>
            <select
              value={selectedDate}
              onChange={(event) => setSelectedDate(event.target.value)}
            >
              {dates.map((date) => (
                <option key={date} value={date}>
                  {new Date(`${date}T00:00:00`).toLocaleDateString("zh-CN")}
                </option>
              ))}
            </select>
          </label>
        )}
        {scope === "unit" && (
          <label className="field">
            <span>选择目录</span>
            <select
              value={selectedUnit}
              onChange={(event) => setSelectedUnit(event.target.value)}
            >
              {units.map((unit) => (
                <option key={unit} value={unit}>
                  {unit}
                </option>
              ))}
            </select>
          </label>
        )}
        <div className="relearn-preview">
          <RotateCcw size={16} />
          <span>
            将有 <strong>{targets.length}</strong> 个单词恢复为未学习
          </span>
        </div>
        <div className="import-actions">
          <button className="button button-secondary" onClick={onClose}>
            取消
          </button>
          <button
            className="button button-primary"
            disabled={!targets.length}
            onClick={confirm}
          >
            确认重学
          </button>
        </div>
      </div>
    </div>
  );
}

function GroupPlanModal({
  deck,
  onClose,
  onSave,
}: {
  deck: Deck;
  onClose: () => void;
  onSave: (deck: Deck) => Promise<void>;
}) {
  const [groups, setGroups] = useState(deck.dailyGroupCount);
  const [wordsPerGroup, setWordsPerGroup] = useState(deck.wordsPerGroup);
  return (
    <div className="modal-backdrop">
      <div className="modal-card plan-modal">
        <div className="modal-header">
          <div>
            <p className="eyebrow">学习计划</p>
            <h2>安排每组词数</h2>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭">
            <X size={18} />
          </button>
        </div>
        <p className="modal-copy">
          按参考图的方式，设置每天学习几组，以及每组安排多少个单词。
        </p>
        <div className="plan-setting-grid">
          <label className="field">
            <span>每天学习组数</span>
            <input
              type="number"
              min={1}
              max={50}
              value={groups}
              onChange={(event) =>
                setGroups(Math.max(1, Number(event.target.value)))
              }
            />
          </label>
          <label className="field">
            <span>每组词数</span>
            <input
              type="number"
              min={1}
              max={100}
              value={wordsPerGroup}
              onChange={(event) =>
                setWordsPerGroup(Math.max(1, Number(event.target.value)))
              }
            />
          </label>
        </div>
        <div className="plan-preview">
          <Settings2 size={15} />
          <span>
            今日最多安排 <strong>{groups * wordsPerGroup}</strong> 个新词
          </span>
        </div>
        <div className="import-actions">
          <button className="button button-secondary" onClick={onClose}>
            取消
          </button>
          <button
            className="button button-primary"
            onClick={() =>
              void onSave({ ...deck, dailyGroupCount: groups, wordsPerGroup })
            }
          >
            保存计划
          </button>
        </div>
      </div>
    </div>
  );
}

function UnitManagerModal({
  deck,
  groups,
  onClose,
  onSave,
}: {
  deck: Deck;
  groups: string[];
  onClose: () => void;
  onSave: (units: string[], removed: string[]) => Promise<void>;
}) {
  const initial = deck.units?.length
    ? deck.units
    : groups.filter((label) => label !== "全部词汇");
  const [units, setUnits] = useState(initial);
  const [newUnit, setNewUnit] = useState("");
  const [removed, setRemoved] = useState<string[]>([]);
  const rename = (index: number, value: string) =>
    setUnits((current) =>
      current.map((unit, itemIndex) => (itemIndex === index ? value : unit)),
    );
  const add = () => {
    const value = newUnit.trim();
    if (!value || units.includes(value)) return;
    setUnits((current) => [...current, value]);
    setNewUnit("");
  };
  const remove = (index: number) => {
    const value = units[index];
    setUnits((current) =>
      current.filter((_, itemIndex) => itemIndex !== index),
    );
    if (value) setRemoved((current) => [...current, value]);
  };
  return (
    <div className="modal-backdrop">
      <div className="modal-card unit-modal">
        <div className="modal-header">
          <div>
            <p className="eyebrow">目录子菜单</p>
            <h2>管理学习单元</h2>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭">
            <X size={18} />
          </button>
        </div>
        <p className="modal-copy">
          你可以自己添加、改名或删除目录中的单元。删除单元不会删除单词，只会把它们移到未分类。
        </p>
        <div className="unit-editor-list">
          {units.map((unit, index) => (
            <div className="unit-editor-row" key={`${unit}-${index}`}>
              <input
                value={unit}
                onChange={(event) => rename(index, event.target.value)}
              />
              <button
                className="delete-quiet"
                onClick={() => remove(index)}
                aria-label={`删除${unit}`}
              >
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
        <div className="unit-add-row">
          <input
            value={newUnit}
            onChange={(event) => setNewUnit(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter") add();
            }}
            placeholder="例如：第七单元"
          />
          <button className="button button-secondary compact" onClick={add}>
            <Plus size={14} /> 添加
          </button>
        </div>
        <div className="import-actions">
          <button className="button button-secondary" onClick={onClose}>
            取消
          </button>
          <button
            className="button button-primary"
            disabled={!units.length || units.some((unit) => !unit.trim())}
            onClick={() =>
              void onSave(
                units.map((unit) => unit.trim()),
                removed,
              )
            }
          >
            保存目录
          </button>
        </div>
      </div>
    </div>
  );
}

export function WordDetailModal({
  word,
  deck,
  voice,
  onClose,
  onSave,
  onRelearn,
  onDelete,
  onSaveWordFormLabels,
}: {
  word: WordCard;
  deck: Deck;
  voice?: Deck["voice"];
  onClose: () => void;
  onSave: (word: WordCard) => Promise<void>;
  onRelearn: () => Promise<void>;
  onDelete: () => Promise<void>;
  onSaveWordFormLabels: (labels: string[]) => Promise<void>;
}) {
  const { localAssets, settings, updateSettings } = useAppState();
  const { currentAccount } = useKonohaAccount();
  const voicePreference = voice && voice !== "natural" ? voice : settings.voice;
  const [playing, setPlaying] = useState<"word" | "example" | null>(null);
  const [note, setNote] = useState(word.note ?? "");
  const [saved, setSaved] = useState(false);
  const [confirmAction, setConfirmAction] = useState<"relearn" | "delete" | null>(null);
  const [skipConfirmation, setSkipConfirmation] = useState(false);
  const [addingTag, setAddingTag] = useState(false);
  const [newTag, setNewTag] = useState("");
  const [draggingTag, setDraggingTag] = useState<string | null>(null);
  const [showWordForms, setShowWordForms] = useState(false);
  useEffect(() => {
    setNote(word.note ?? "");
  }, [word]);
  const play = async () => {
    setPlaying("word");
    await playVocabularyAudio(word, localAssets, {
      voice: voicePreference,
      desktopUserId: currentAccount?.id,
    });
    setPlaying(null);
  };
  const playExample = async () => {
    if (!word.example.trim()) return;
    setPlaying("example");
    await playConfiguredTextAudio(word.example, word.language === "en" ? "en" : "ja", {
      voice: voicePreference,
      desktopUserId: currentAccount?.id,
    });
    setPlaying(null);
  };
  const toggleFavorite = async () => {
    await onSave({ ...word, note: note.trim(), favorite: !word.favorite });
    setSaved(true);
  };
  const saveNote = async () => {
    await onSave({ ...word, note: note.trim() });
    setSaved(true);
  };
  const saveField = async (key: keyof WordCard, value: string | string[]) => {
    const normalized = typeof value === "string" ? value.trim() : value.map((item) => item.trim()).filter(Boolean);
    if (JSON.stringify(word[key]) === JSON.stringify(normalized)) return;
    await onSave({ ...word, [key]: normalized });
  };
  const addTag = async () => {
    const tag = newTag.trim();
    if (!tag || word.tags.some((item) => item.toLocaleLowerCase() === tag.toLocaleLowerCase())) {
      setNewTag("");
      return;
    }
    await saveField("tags", [...word.tags, tag]);
    setNewTag("");
    setAddingTag(false);
  };
  const removeTag = async (tag: string) => {
    await saveField("tags", word.tags.filter((item) => item !== tag));
  };
  const reorderTag = async (targetTag: string) => {
    if (!draggingTag || draggingTag === targetTag) return;
    const next = [...word.tags];
    const from = next.indexOf(draggingTag);
    const to = next.indexOf(targetTag);
    if (from < 0 || to < 0) return;
    next.splice(from, 1);
    next.splice(to, 0, draggingTag);
    await saveField("tags", next);
    setDraggingTag(null);
  };
  const requestRelearn = () => {
    if (settings.skipRelearnConfirmation) void onRelearn();
    else {
      setSkipConfirmation(false);
      setConfirmAction("relearn");
    }
  };
  const requestDelete = () => {
    if (settings.skipDeleteConfirmation) void onDelete();
    else {
      setSkipConfirmation(false);
      setConfirmAction("delete");
    }
  };
  const completeConfirmation = async () => {
    const action = confirmAction;
    if (!action) return;
    if (skipConfirmation) {
      await updateSettings(action === "relearn" ? { skipRelearnConfirmation: true } : { skipDeleteConfirmation: true });
    }
    setConfirmAction(null);
    setSkipConfirmation(false);
    if (action === "relearn") await onRelearn();
    else await onDelete();
  };
  return (
    <div className="modal-backdrop word-detail-backdrop">
      <div className="modal-card word-detail-modal">
        <div className="modal-header word-detail-modal-header">
          <span className="word-detail-language-label">
            {word.language === "en" ? "英语单词" : "日语单词"}
          </span>
          <div className="word-detail-header-actions">
            <button type="button" className="button button-secondary compact word-detail-relearn" onClick={requestRelearn}><RotateCcw size={15} /> 重新学习</button>
            <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
          </div>
        </div>
        <div className="word-detail-main">
          <div className="word-detail-wordline">
            <InlineEditable className="word-detail-word-edit" value={word.word} onSave={(value) => saveField("word", value)} />
            {word.language !== "en" && (
              <InlineEditable
                className="word-detail-pitch word-detail-pitch-edit"
                value={word.pitchAccent ?? ""}
                displayValue={formatPitchAccent(word.pitchAccent)}
                hideWhenEmpty
                onSave={(value) => saveField("pitchAccent", value)}
              />
            )}
            <div className="word-detail-inline-tools">
              <button className={`detail-audio ${playing === "word" ? "speaking" : ""}`} onClick={() => void play()}><Volume2 size={16} /> 播放发音</button>
              <button className={`detail-favorite ${word.favorite ? "active" : ""}`} onClick={() => void toggleFavorite()}><Star size={15} fill={word.favorite ? "currentColor" : "none"} /> {word.favorite ? "已设重点" : "设为重点"}</button>
            </div>
          </div>
          <InlineEditable className="detail-kana word-detail-kana-edit" value={word.kana} placeholder="暂无读音" hideWhenEmpty onSave={(value) => saveField("kana", value)} />
        </div>
        <div className="word-detail-tags">
          <InlineEditable className="word-detail-tag word-detail-tag-primary" value={word.partOfSpeech} placeholder="词性" onSave={(value) => saveField("partOfSpeech", value)} />
          <span className="word-detail-tag">状态 · {statusLabel(word)}</span>
          {word.tags.map((tag) => (
            <span
              className={`word-detail-tag word-detail-custom-tag ${draggingTag === tag ? "dragging" : ""}`}
              key={tag}
              draggable
              onDragStart={() => setDraggingTag(tag)}
              onDragEnd={() => setDraggingTag(null)}
              onDragOver={(event) => event.preventDefault()}
              onDrop={(event) => {
                event.preventDefault();
                void reorderTag(tag);
              }}
            >
              <span>{tag}</span>
              <button type="button" onClick={() => void removeTag(tag)} aria-label={`删除标签${tag}`}>
                <X size={11} />
              </button>
            </span>
          ))}
          {addingTag ? (
            <div className="word-detail-tag-add-input">
              <input
                autoFocus
                value={newTag}
                onChange={(event) => setNewTag(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    void addTag();
                  }
                  if (event.key === "Escape") {
                    setAddingTag(false);
                    setNewTag("");
                  }
                }}
                onBlur={() => {
                  if (newTag.trim()) void addTag();
                  else setAddingTag(false);
                }}
                placeholder="新标签"
                aria-label="新标签"
              />
            </div>
          ) : (
            <button
              type="button"
              className="word-detail-tag-add"
              onClick={() => setAddingTag(true)}
              aria-label="添加标签"
            >
              <Plus size={13} />
            </button>
          )}
        </div>
        <button
          type="button"
          className="word-forms-trigger"
          onClick={() => setShowWordForms(true)}
        >
          <span>
            <strong>单词变形</strong>
            <small>
              {countWordForms(word.verbForms) ? `${countWordForms(word.verbForms)} 项` : "添加单词变形"}
            </small>
          </span>
          <ChevronRight size={17} />
        </button>
        <section className="word-detail-section">
          <div className="word-detail-section-heading"><h3>释义</h3><span>{word.partOfSpeech || "词汇"}</span></div>
          <div className="word-detail-definition word-detail-definition-rich"><b>中</b><InlineEditable className="word-detail-inline-definition" value={word.meaning} placeholder="添加释义" onSave={(value) => saveField("meaning", value)} /></div>
        </section>
        <section className="word-detail-section">
          <div className="word-detail-section-heading"><h3>例句</h3><button type="button" className={`word-example-audio ${playing === "example" ? "speaking" : ""}`} onClick={() => void playExample()} aria-label="播放例句"><Volume2 size={16} /></button></div>
          <div className="word-example-card">
            <InlineEditable className="word-example-editable" value={word.example} placeholder="添加例句" multiline onSave={(value) => saveField("example", value)} />
            <InlineEditable className="word-example-translation-editable" value={word.exampleTranslation} placeholder="添加例句翻译" onSave={(value) => saveField("exampleTranslation", value)} />
          </div>
        </section>
        <section className="word-detail-section word-note-section">
          <div className="word-detail-section-heading"><h3>我的笔记</h3></div>
          <div className="detail-note-editor"><textarea id={`detail-note-${word.id}`} value={note} onChange={(event) => { setNote(event.target.value); setSaved(false); }} placeholder="记录联想、易错点或语法用法…" rows={4} /><div><span className={`note-saved ${saved ? "visible" : ""}`}><Check size={13} /> 已保存</span><button className="button button-secondary compact" onClick={() => void saveNote()}><Save size={14} /> 保存笔记</button></div></div>
        </section>
        <div className="word-detail-delete-row"><button className="button button-danger" onClick={requestDelete}><Trash2 size={15} /> 删除单词</button></div>
        {confirmAction && <ConfirmDialog action={confirmAction} skip={skipConfirmation} onSkipChange={setSkipConfirmation} onCancel={() => { setConfirmAction(null); setSkipConfirmation(false); }} onConfirm={() => void completeConfirmation()} />}
        {showWordForms && (
          <WordFormsModal
            word={word}
            sharedLabels={deck.wordFormLabels}
            onClose={() => setShowWordForms(false)}
            onSave={async (verbForms, labels) => {
              await onSave({ ...word, verbForms });
              await onSaveWordFormLabels(labels);
            }}
          />
        )}
      </div>
    </div>
  );
}

function fixedWordFormFields(language: StudyLanguage): Array<{ key: "dictionary" | "masu" | "te" | "nai" | "ta"; label: string }> {
  return language === "en"
    ? [
        { key: "dictionary", label: "原形" },
        { key: "masu", label: "第三人称" },
        { key: "te", label: "现在分词" },
        { key: "nai", label: "过去式" },
        { key: "ta", label: "过去分词" },
      ]
    : [
        { key: "dictionary", label: "辞书形" },
        { key: "masu", label: "ます形" },
        { key: "te", label: "て形" },
        { key: "nai", label: "ない形" },
        { key: "ta", label: "た形" },
      ];
}

type WordFormEntry = {
  id: string;
  key?: "dictionary" | "masu" | "te" | "nai" | "ta";
  label: string;
  value: string;
};

function wordFormEntries(forms: VerbForms | undefined, sharedLabels: string[] = [], language: StudyLanguage = "ja"): WordFormEntry[] {
  const fixed = fixedWordFormFields(language).map(({ key, label }) => ({
    id: key,
    key,
    label,
    value: forms?.[key] ?? "",
  }));
  const existingCustom = forms?.custom ?? [];
  const sharedCustom = sharedLabels.map((label, index) => {
    const existing = existingCustom.find((item) => item.label.toLocaleLowerCase() === label.toLocaleLowerCase());
    return {
      id: `custom-shared-${index}-${label}`,
      label,
      value: existing?.value ?? "",
    };
  });
  const extraCustom = existingCustom
    .filter((item) => !sharedLabels.some((label) => label.toLocaleLowerCase() === item.label.toLocaleLowerCase()))
    .map((item, index) => ({
      id: `custom-extra-${index}-${item.label}`,
      label: item.label,
      value: item.value,
    }));
  const custom = [...sharedCustom, ...extraCustom];
  return [...fixed, ...custom];
}

function countWordForms(forms?: VerbForms) {
  if (!forms) return 0;
  return [
    forms.dictionary,
    forms.masu,
    forms.te,
    forms.nai,
    forms.ta,
    ...(forms.custom ?? []).map((item) => item.value),
  ].filter((value) => value?.trim()).length;
}

function WordFormsModal({
  word,
  sharedLabels,
  onClose,
  onSave,
}: {
  word: WordCard;
  sharedLabels?: string[];
  onClose: () => void;
  onSave: (forms: VerbForms, labels: string[]) => Promise<void>;
}) {
  const language = word.language === "en" ? "en" : "ja";
  const [entries, setEntries] = useState(() => wordFormEntries(word.verbForms, sharedLabels, language));
  const [adding, setAdding] = useState(false);
  const [newLabel, setNewLabel] = useState("");
  const [newValue, setNewValue] = useState("");
  const [saving, setSaving] = useState(false);

  const updateEntry = (id: string, key: "label" | "value", value: string) => {
    setEntries((current) =>
      current.map((entry) => (entry.id === id ? { ...entry, [key]: value } : entry)),
    );
  };
  const removeEntry = (id: string) => {
    setEntries((current) => current.filter((entry) => entry.id !== id));
  };
  const addEntry = () => {
    const label = newLabel.trim();
    const value = newValue.trim();
    if (!label) return;
    setEntries((current) => [
      ...current,
      { id: `custom-${Date.now()}`, label, value },
    ]);
    setNewLabel("");
    setNewValue("");
    setAdding(false);
  };
  const save = async () => {
    setSaving(true);
    try {
      const next: VerbForms = {};
      const custom: Array<{ label: string; value: string }> = [];
      const labels: string[] = [];
      entries.forEach((entry) => {
        const label = entry.label.trim();
        const value = entry.value.trim();
        if (!label) return;
        if (entry.key) {
          if (value) next[entry.key] = value;
        } else {
          labels.push(label);
          if (value) custom.push({ label, value });
        }
      });
      if (custom.length) next.custom = custom;
      await onSave(next, [...new Set(labels)]);
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="word-forms-backdrop" role="presentation">
      <div className="modal-card word-forms-modal" role="dialog" aria-modal="true" aria-labelledby="word-forms-title">
        <div className="modal-header">
          <div>
            <p className="eyebrow">{language === "en" ? "英语词形" : "日语词形"}</p>
            <h2 id="word-forms-title">单词变形</h2>
          </div>
          <button type="button" className="icon-button" onClick={onClose} aria-label="关闭单词变形">
            <X size={18} />
          </button>
        </div>
        <p className="modal-copy">可以直接修改变形后的单词，也可以用加号增加新的变形标签。</p>
        <div className="word-forms-list">
          {entries.map((entry) => (
            <div className="word-form-row" key={entry.id}>
              <input
                className="word-form-label"
                value={entry.label}
                onChange={(event) => updateEntry(entry.id, "label", event.target.value)}
                aria-label={`${entry.label}标签`}
              />
              <input
                className="word-form-value"
                value={entry.value}
                onChange={(event) => updateEntry(entry.id, "value", event.target.value)}
                placeholder="填写单词"
                aria-label={`${entry.label}单词`}
              />
              <button type="button" className="word-form-remove" onClick={() => removeEntry(entry.id)} aria-label={`删除${entry.label}`}>
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
        {adding ? (
          <div className="word-form-add-row">
            <input
              autoFocus
              value={newLabel}
              onChange={(event) => setNewLabel(event.target.value)}
              placeholder="标签"
              aria-label="新变形标签"
            />
            <input
              value={newValue}
              onChange={(event) => setNewValue(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  addEntry();
                }
                if (event.key === "Escape") {
                  setAdding(false);
                  setNewLabel("");
                  setNewValue("");
                }
              }}
              placeholder="单词"
              aria-label="新变形单词"
            />
            <button type="button" className="button button-secondary compact" onClick={addEntry}>
              添加
            </button>
          </div>
        ) : (
          <button type="button" className="word-form-add-button" onClick={() => setAdding(true)}>
            <Plus size={14} /> 添加变形
          </button>
        )}
        <div className="import-actions">
          <button type="button" className="button button-secondary" onClick={onClose}>
            取消
          </button>
          <button type="button" className="button button-primary" disabled={saving} onClick={() => void save()}>
            <Save size={14} /> {saving ? "保存中…" : "保存单词变形"}
          </button>
        </div>
      </div>
    </div>
  );
}

function InlineEditable({
  value,
  displayValue,
  placeholder,
  hideWhenEmpty = false,
  onSave,
  className,
  multiline = false,
}: {
  value: string;
  displayValue?: string;
  placeholder?: string;
  hideWhenEmpty?: boolean;
  onSave: (value: string) => Promise<void> | void;
  className?: string;
  multiline?: boolean;
}) {
  const [active, setActive] = useState(false);
  const [draft, setDraft] = useState(value);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!active) setDraft(value);
  }, [active, value]);

  const cancel = () => {
    setDraft(value);
    setActive(false);
  };

  const commit = async () => {
    if (saving) return;
    const next = draft.trim();
    setActive(false);
    if (next === value) return;
    setSaving(true);
    try {
      await onSave(next);
    } finally {
      setSaving(false);
    }
  };

  if (active) {
    const sharedProps = {
      autoFocus: true,
      className: `inline-edit-control ${className ?? ""}`,
      value: draft,
      onChange: (event: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
        setDraft(event.target.value),
      onBlur: () => void commit(),
      onKeyDown: (event: KeyboardEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        if (event.key === "Escape") {
          event.preventDefault();
          cancel();
        } else if (!multiline && event.key === "Enter") {
          event.preventDefault();
          event.currentTarget.blur();
        }
      },
    };
    return multiline ? <textarea {...sharedProps} rows={3} /> : <input {...sharedProps} />;
  }

  return (
    <button
      type="button"
      className={`inline-edit-display ${hideWhenEmpty && !value ? "inline-edit-empty" : ""} ${className ?? ""}`}
      onClick={() => setActive(true)}
      aria-label={`编辑${value || placeholder || "内容"}`}
    >
      {hideWhenEmpty && !value ? null : displayValue || value || placeholder || "点击添加"}
    </button>
  );
}

function formatPitchAccent(value?: string) {
  const raw = value?.trim() ?? "";
  if (!raw) return "";
  const circledDigits = ["⓪", "①", "②", "③", "④", "⑤", "⑥", "⑦", "⑧", "⑨"];
  if (/^\d$/.test(raw)) return circledDigits[Number(raw)] ?? raw;
  return raw;
}

function ConfirmDialog({
  action,
  skip,
  onSkipChange,
  onCancel,
  onConfirm,
}: {
  action: "relearn" | "delete";
  skip: boolean;
  onSkipChange: (value: boolean) => void;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  const isDelete = action === "delete";
  return (
    <div className="confirm-dialog-backdrop" role="presentation">
      <div
        className="confirm-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="word-confirm-title"
        onClick={(event) => event.stopPropagation()}
      >
        <h3 id="word-confirm-title">{isDelete ? "删除单词" : "重新学习"}</h3>
        <p>
          {isDelete
            ? "确定要删除这个单词吗？"
            : "确定要将这个单词重新设置为未学习吗？"}
        </p>
        {isDelete && (
          <p className="confirm-dialog-note">
            删除后，该单词记录将从单词库中移除。
          </p>
        )}
        <label className="confirm-dialog-check">
          <input
            type="checkbox"
            checked={skip}
            onChange={(event) => onSkipChange(event.target.checked)}
          />
          <span>不再提醒</span>
        </label>
        <div className="confirm-dialog-actions">
          <button type="button" className="button button-secondary" onClick={onCancel}>
            取消
          </button>
          <button
            type="button"
            className={`button ${isDelete ? "button-danger" : "button-primary"}`}
            onClick={onConfirm}
          >
            {isDelete ? "确定删除" : "确定"}
          </button>
        </div>
      </div>
    </div>
  );
}
