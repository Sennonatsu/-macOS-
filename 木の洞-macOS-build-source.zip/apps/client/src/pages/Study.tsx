import { ArrowLeft, CheckCircle2, Headphones, Keyboard, RotateCcw, Volume2 } from "lucide-react";
import { useEffect, useMemo, useState } from "react";
import { Link, Navigate, useSearchParams } from "react-router-dom";
import { useAppState } from "@/services/AppState";
import { useKonohaAccount } from "@/services/KonohaAccount";
import { isDue } from "@/services/scheduler";
import { getWordUnit } from "@/services/wordGroups";
import { playVocabularyAudio } from "@/services/tts";
import type { WordCard } from "@/types";

export default function Study() {
  const { ready, words, decks, localAssets, settings, reviewWord, markWordMastered, markWordAudio } = useAppState();
  const { currentAccount } = useKonohaAccount();
  const [params] = useSearchParams();
  const selectedDeckId = params.get("deck");
  const selectedDeck = decks.find((deck) => deck.id === selectedDeckId);
  const isReviewSession = params.get("session") === "review";
  const voicePreference = selectedDeck?.voice && selectedDeck.voice !== "natural" ? selectedDeck.voice : settings.voice;
  const selectedUnit = params.get("unit");
  const [sessionIds, setSessionIds] = useState<string[]>([]);
  const [round, setRound] = useState<1 | 2>(1);
  const [wordIndex, setWordIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [feedback, setFeedback] = useState<"correct" | "wrong" | null>(null);
  const [firstRoundCorrect, setFirstRoundCorrect] = useState<Set<string>>(new Set());
  const [masteredIds, setMasteredIds] = useState<Set<string>>(new Set());
  const [passedCount, setPassedCount] = useState(0);
  const [masteredCount, setMasteredCount] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [busy, setBusy] = useState(false);
  const [startedAt, setStartedAt] = useState(Date.now());
  const [playing, setPlaying] = useState(false);
  const [sessionScope, setSessionScope] = useState("");
  const scopeKey = selectedDeck ? `${selectedDeck.id}::${selectedUnit ?? ""}::${isReviewSession ? "review" : "learn"}` : "";
  const mode = isReviewSession
    ? selectedDeck?.reviewMode ?? "TYPE_ANSWER"
    : selectedDeck?.learningMode ?? "TYPE_ANSWER";

  const sessionQueue = useMemo(() => {
    const deckPool = selectedDeck ? words.filter((word) => word.deckIds.includes(selectedDeck.id) && word.status !== "SUSPENDED") : words.filter((word) => word.status !== "SUSPENDED");
    const pool = selectedDeck && selectedUnit ? deckPool.filter((word) => getWordUnit(selectedDeck, deckPool, word) === selectedUnit) : deckPool;
    const due = pool.filter((word) => word.status !== "NEW" && isDue(word));
    const fresh = pool.filter((word) => word.status === "NEW");
    const learning = pool.filter((word) => word.status === "LEARNING" || word.status === "RELEARNING");
    if (isReviewSession) {
      const dueIds = new Set(due.map((word) => word.id));
      return [...due, ...learning.filter((word) => !dueIds.has(word.id))]
        .slice(0, Math.min(selectedDeck?.dailyReviewLimit ?? settings.dailyReviewLimit, selectedDeck?.wordsPerGroup ?? 10));
    }
    const dailyNew = selectedDeck
      ? Math.max(0, selectedDeck.dailyNewLimit)
      : Math.max(0, decks.reduce((total, deck) => total + deck.dailyNewLimit, 0) || settings.dailyNewLimit);
    const dailyReview = selectedDeck?.dailyReviewLimit ?? settings.dailyReviewLimit;
    const order = selectedDeck?.order ?? settings.order;
    const dueItems = order === "new_first" ? [] : due.slice(0, dailyReview);
    const newItems = fresh.slice(0, dailyNew);
    const dueIds = new Set(dueItems.map((item) => item.id));
    const learningItems = learning.filter((word) => !dueIds.has(word.id)).slice(0, dailyReview);
    const result = order === "new_first" ? [...newItems, ...dueItems, ...learningItems] : [...dueItems, ...learningItems, ...newItems];
    const ordered = order === "random" ? result.sort(() => Math.random() - 0.5) : result;
    return ordered.slice(0, selectedDeck?.wordsPerGroup ?? 10);
  }, [decks, isReviewSession, selectedDeck, selectedUnit, settings.dailyNewLimit, settings.dailyReviewLimit, settings.order, words]);

  useEffect(() => {
    if (!ready || !selectedDeck) return;
    if (sessionScope !== scopeKey) {
      setSessionIds(sessionQueue.map((word) => word.id));
      setSessionScope(scopeKey);
      setRound(1);
      setWordIndex(0);
      setAnswer("");
      setFeedback(null);
      setFirstRoundCorrect(new Set());
      setMasteredIds(new Set());
      setPassedCount(0);
      setMasteredCount(0);
      setCompleted(false);
      setBusy(false);
    }
  }, [ready, selectedDeck, sessionQueue, sessionScope, scopeKey]);

  const activeSessionIds = round === 2
    ? sessionIds.filter((id) => !masteredIds.has(id))
    : sessionIds;
  const current = useMemo(
    () =>
      sessionScope === scopeKey
        ? words.find(
            (word) =>
              word.id === activeSessionIds[wordIndex] &&
              Boolean(selectedDeck && word.deckIds.includes(selectedDeck.id)),
          )
        : undefined,
    [activeSessionIds, scopeKey, selectedDeck, sessionScope, wordIndex, words],
  );
  const activeLanguage = current?.language ?? selectedDeck?.language ?? "ja";
  const languageName = activeLanguage === "en" ? "英语" : "日语";
  const totalSteps = sessionIds.length * 2;
  const completedSteps = sessionIds.length
    ? (round - 1) * sessionIds.length + wordIndex
    : 0;

  useEffect(() => {
    setAnswer("");
    setFeedback(null);
    setBusy(false);
    setStartedAt(Date.now());
    if (current && mode === "LISTENING" && round === 1) {
      void speakCurrentWord(current);
    }
  }, [current?.id, mode, round]);

  async function speakCurrentWord(word: WordCard) {
    const spokenText = word.word.trim();
    if (!spokenText) return;
    const spokenLanguage = word.language ?? selectedDeck?.language ?? "ja";
    setPlaying(true);
    const ok = await playVocabularyAudio({ word: spokenText, language: spokenLanguage }, localAssets, {
      voice: voicePreference,
      desktopUserId: currentAccount?.id,
    });
    if (ok) await markWordAudio(word.id, "wordGeneratedAt", voicePreference);
    setPlaying(false);
  }

  async function checkAnswer() {
    if (!current || feedback || busy) return;
    const normalized = normalizeAnswer(answer);
    if (!normalized) return;
    setBusy(true);
    const expected = round === 1 && mode === "TYPE_ANSWER" && activeLanguage === "ja"
      ? current.kana
      : current.word;
    const correct = normalized === normalizeAnswer(expected);
    setFeedback(correct ? "correct" : "wrong");
    if (round === 1 && correct) {
      setFirstRoundCorrect((currentSet) => new Set(currentSet).add(current.id));
    }
    await speakCurrentWord(current);
    setBusy(false);
  }

  async function continueTest(markAsMastered = false) {
    if (!current || (!feedback && !markAsMastered) || busy) return;
    setBusy(true);
    if (markAsMastered) {
      await markWordMastered(current);
      setMasteredIds((currentIds) => new Set(currentIds).add(current.id));
      setMasteredCount((count) => count + 1);
    } else if (round === 2) {
        const passed = firstRoundCorrect.has(current.id) && feedback === "correct";
        await reviewWord(current, passed ? "GOOD" : "AGAIN", Date.now() - startedAt, selectedDeck?.id);
        if (passed) setPassedCount((count) => count + 1);
    }
    const activeIdsAfterAction = round === 1
      ? sessionIds
      : activeSessionIds.filter((id) => !(markAsMastered && id === current.id));
    if (markAsMastered && round === 2) {
      if (wordIndex < activeSessionIds.length - 1) {
        setWordIndex(wordIndex);
      } else {
        setCompleted(true);
      }
      return;
    }
    if (wordIndex < activeIdsAfterAction.length - 1) {
      setWordIndex((index) => index + 1);
      return;
    }
    if (round === 1) {
      const masteredAfterAction = masteredIds.size + (markAsMastered && !masteredIds.has(current.id) ? 1 : 0);
      if (masteredAfterAction >= sessionIds.length) {
        setCompleted(true);
      } else {
        setRound(2);
        setWordIndex(0);
      }
      return;
    }
    setCompleted(true);
  }

  useEffect(() => {
    const handleEnter = (event: KeyboardEvent) => {
      if (event.key !== "Enter" || event.isComposing) return;
      event.preventDefault();
      if (feedback) void continueTest();
      else void checkAnswer();
    };
    window.addEventListener("keydown", handleEnter);
    return () => window.removeEventListener("keydown", handleEnter);
  });

  if (!ready) return <div className="loading-state">正在准备你的词库…</div>;
  if (!selectedDeckId && decks[0]) return <Navigate to={`/study?deck=${encodeURIComponent(decks[0].id)}`} replace />;
  if (selectedDeckId && !selectedDeck) return <div className="empty-library"><h3>找不到这个学习词库</h3><p>请选择左侧学习栏目中的一个词库。</p><Link to="/decks" className="button button-primary">返回词库</Link></div>;
  if (selectedDeck && sessionScope !== scopeKey) return <div className="loading-state">正在切换到「{selectedDeck.name}」…</div>;
  if (!sessionIds.length) return <StudyComplete deckId={selectedDeck?.id} deckName={selectedDeck?.name} passed={0} mastered={0} total={0} isReview={isReviewSession} />;
  if (completed) return <StudyComplete deckId={selectedDeck?.id} deckName={selectedDeck?.name} passed={passedCount} mastered={masteredCount} total={sessionIds.length} isReview={isReviewSession} />;
  if (!current) return <div className="loading-state">正在准备测试…</div>;

  const firstPrompt = mode === "LISTENING"
    ? "听发音，输入单词"
    : activeLanguage === "ja"
      ? "看单词，输入假名"
      : "看音标，输入英语单词";
  const promptText = round === 2
    ? current.meaning.split("；")[0]
    : mode === "LISTENING"
      ? ""
      : activeLanguage === "ja"
        ? current.word
        : current.kana || current.word;
  const placeholder = round === 1 && mode === "TYPE_ANSWER" && activeLanguage === "ja"
    ? "输入假名"
    : `输入${languageName}单词`;

  return (
    <div className="study-page">
      <div className="study-topbar"><Link to={isReviewSession ? `/review?deck=${encodeURIComponent(selectedDeck?.id ?? "")}` : "/decks"} className="back-link"><ArrowLeft size={17} /> {isReviewSession ? "返回复习" : "返回词库"}</Link><div className="study-context">{selectedDeck?.name} · {isReviewSession ? "复习测试" : "学习测试"}{selectedUnit ? ` · ${selectedUnit}` : ""}</div><div className="study-count">第 {round} 轮 <span>/ 2</span></div></div>
      <div className="study-progress-line"><span style={{ width: `${Math.max(5, (completedSteps / Math.max(1, totalSteps)) * 100)}%` }} /></div>
      <div className="test-round-strip">
        <span className={round === 1 ? "active" : ""}>第一轮 · {mode === "LISTENING" ? "听音输入" : activeLanguage === "ja" ? "单词→假名" : "音标→单词"}</span>
        <span className={round === 2 ? "active" : ""}>第二轮 · 中文→{languageName}</span>
        <button
          type="button"
          className="mastery-step"
          onClick={() => void continueTest(true)}
          disabled={busy}
          title="标记为已掌握并跳过本词，不计入今日新词目标"
          aria-label="将当前单词标记为掌握"
        >
          掌握
        </button>
        <small>{wordIndex + 1} / {sessionIds.length}</small>
      </div>
      <div className={`flashcard ${feedback ? "revealed" : ""} ${mode === "LISTENING" && round === 1 ? "listening-card" : ""}`}>
        <div className="card-topline"><span>{selectedDeck?.name} · {mode === "LISTENING" ? "听音测试" : "输入测试"}</span><button className={`icon-button ghost ${playing ? "speaking" : ""}`} onClick={() => void speakCurrentWord(current)} aria-label={`播放${languageName}单词`}><Volume2 size={17} /></button></div>
        <div className="card-main">
          <span className="card-direction">{round === 1 ? firstPrompt : `看中文，输入${languageName}单词`}</span>
          {mode === "LISTENING" && round === 1 ? <button className={`listen-big ${playing ? "speaking" : ""}`} onClick={() => void speakCurrentWord(current)} aria-label="重新播放听力"><Headphones size={34} /></button> : <h2>{promptText}</h2>}
          {!feedback && <div className="answer-input-wrap"><input autoFocus value={answer} onChange={(event) => setAnswer(event.target.value)} placeholder={placeholder} disabled={busy} /><button className="button button-primary compact" onClick={() => void checkAnswer()} disabled={busy || !answer.trim()}>检查</button></div>}
          {feedback && <div className="answer-side"><div className={`answer-feedback ${feedback}`}>{feedback === "correct" ? "回答正确" : "回答错误，本轮不会过关"}</div><div className="answer-word"><strong>{current.word}</strong><span>{current.kana}</span></div><div className="answer-meaning">{current.meaning}</div><button className="button button-primary test-next-button" onClick={() => void continueTest()} disabled={busy}>{round === 1 && wordIndex === sessionIds.length - 1 ? "进入第二轮 ↵" : round === 2 && wordIndex === sessionIds.length - 1 ? "查看结果 ↵" : "下一个 ↵"}</button></div>}
        </div>
      </div>
      <p className="keyboard-hint"><Keyboard size={13} /> {feedback ? "按 Enter 进入下一项" : "按 Enter 检查答案"} · 每次提交后自动播放发音</p>
    </div>
  );
}

function normalizeAnswer(value: string) {
  return value.trim().toLocaleLowerCase().replace(/\s+/g, "");
}

function StudyComplete({ deckId, deckName, passed, mastered, total, isReview }: { deckId?: string; deckName?: string; passed: number; mastered: number; total: number; isReview: boolean }) {
  const empty = total === 0;
  return <div className="study-complete"><div className="complete-icon"><CheckCircle2 size={34} /></div><h1>{empty ? "当前没有待测试单词。" : "两轮测试完成。"}</h1><p>{empty ? `「${deckName ?? "当前词库"}」暂时没有符合本次安排的单词。` : deckName ? `「${deckName}」本次 ${passed} 个单词两轮全对${mastered ? `，另有 ${mastered} 个标记为掌握` : ""}。` : "这段记忆已经被保存。"}</p><Link to={isReview && deckId ? `/review?deck=${encodeURIComponent(deckId)}` : "/decks"} className="button button-primary"><RotateCcw size={16} /> {isReview ? "回到复习" : "回到词库"}</Link>{!empty && <p className="complete-note">任意一轮答错的单词会进入重学安排。</p>}</div>;
}
