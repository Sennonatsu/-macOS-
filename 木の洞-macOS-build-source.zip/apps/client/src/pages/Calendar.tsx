import { useEffect, useMemo, useState } from "react";
import { AlertCircle, BookOpenCheck, CalendarDays, CheckCircle2, ChevronLeft, ChevronRight, RotateCcw, Sparkles } from "lucide-react";
import { useAppState } from "@/services/AppState";
import { buildCalendarStats, getCalendarDayStats, getLocalDateKey, getMonthGrid } from "@/services/calendarStats";

const weekDays = ["日", "一", "二", "三", "四", "五", "六"];

function formatSelectedDate(dateKey: string) {
  const [year, month, day] = dateKey.split("-").map(Number);
  return new Intl.DateTimeFormat("zh-CN", {
    year: "numeric",
    month: "long",
    day: "numeric",
    weekday: "long",
  }).format(new Date(year, month - 1, day));
}

export default function Calendar() {
  const { words, decks, reviews } = useAppState();
  const todayKey = getLocalDateKey(new Date());
  const [visibleMonth, setVisibleMonth] = useState(() => {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth(), 1);
  });
  const [selectedDateKey, setSelectedDateKey] = useState(todayKey);
  const [detailDeckId, setDetailDeckId] = useState(() => decks[0]?.id ?? "");
  const statsByDate = useMemo(() => buildCalendarStats(words, decks, reviews), [decks, reviews, words]);
  const detailStatsByDate = useMemo(
    () => buildCalendarStats(words, decks, reviews, detailDeckId || undefined),
    [decks, detailDeckId, reviews, words],
  );
  const monthDays = useMemo(() => getMonthGrid(visibleMonth), [visibleMonth]);
  const detailDeck = decks.find((deck) => deck.id === detailDeckId) ?? decks[0];
  const detailDecks = detailDeck ? [detailDeck] : [];
  const selectedStats = getCalendarDayStats(detailStatsByDate, selectedDateKey, detailDecks);
  const currentMonthKeys = monthDays.filter((day) => day.inCurrentMonth).map((day) => day.dateKey);
  const monthStats = currentMonthKeys.map((key) => statsByDate.get(key)).filter((stats) => Boolean(stats));
  const studiedDays = monthStats.filter((stats) => (stats?.totalAttempts ?? 0) > 0).length;
  const monthNewWords = monthStats.reduce((sum, stats) => sum + (stats?.newWords ?? 0), 0);
  const monthReviewedWords = monthStats.reduce((sum, stats) => sum + (stats?.reviewedWords ?? 0), 0);
  const monthWrongWords = monthStats.reduce((sum, stats) => sum + (stats?.wrongWordCount ?? 0), 0);

  useEffect(() => {
    if (!decks.length) {
      setDetailDeckId("");
      return;
    }
    if (!decks.some((deck) => deck.id === detailDeckId)) setDetailDeckId(decks[0].id);
  }, [decks, detailDeckId]);

  function changeMonth(offset: number) {
    setVisibleMonth((current) => new Date(current.getFullYear(), current.getMonth() + offset, 1));
  }

  function goToday() {
    const today = new Date();
    setVisibleMonth(new Date(today.getFullYear(), today.getMonth(), 1));
    setSelectedDateKey(getLocalDateKey(today));
  }

  return (
    <div className="page-stack calendar-page">
      <section className="page-heading calendar-heading">
        <div>
          <p className="eyebrow">学习日历</p>
          <h1>每天的积累，一目了然</h1>
          <p className="muted">自动同步当前木の叶账号的新学、复习、错题和任务完成度。</p>
        </div>
        <button className="button button-secondary calendar-today-button" onClick={goToday}>
          <CalendarDays size={16} /> 回到今天
        </button>
      </section>

      <section className="calendar-month-summary" aria-label="本月学习汇总">
        <div><span>学习天数</span><strong>{studiedDays}</strong><small>天</small></div>
        <div><span>新学单词</span><strong>{monthNewWords}</strong><small>个</small></div>
        <div><span>复习单词</span><strong>{monthReviewedWords}</strong><small>个</small></div>
        <div className={monthWrongWords > 0 ? "has-wrong" : ""}><span>错题单词</span><strong>{monthWrongWords}</strong><small>个</small></div>
      </section>

      <div className="calendar-workspace">
        <section className="month-calendar panel">
          <div className="calendar-toolbar">
            <div>
              <p className="eyebrow">Monthly record</p>
              <h2>{visibleMonth.getFullYear()}年 {visibleMonth.getMonth() + 1}月</h2>
            </div>
            <div className="calendar-month-controls">
              <button className="icon-button" onClick={() => changeMonth(-1)} aria-label="上一个月"><ChevronLeft size={18} /></button>
              <button className="icon-button" onClick={() => changeMonth(1)} aria-label="下一个月"><ChevronRight size={18} /></button>
            </div>
          </div>

          <div className="calendar-weekdays" aria-hidden="true">
            {weekDays.map((day) => <span key={day}>{day}</span>)}
          </div>
          <div className="calendar-month-grid">
            {monthDays.map((day) => {
              const stats = getCalendarDayStats(statsByDate, day.dateKey, decks);
              const hasActivity = stats.totalAttempts > 0;
              const isToday = day.dateKey === todayKey;
              const isSelected = day.dateKey === selectedDateKey;
              return (
                <button
                  key={day.dateKey}
                  className={[
                    "calendar-day",
                    day.inCurrentMonth ? "" : "outside",
                    isToday ? "today" : "",
                    isSelected ? "selected" : "",
                    hasActivity ? "has-activity" : "",
                  ].filter(Boolean).join(" ")}
                  onClick={() => {
                    setSelectedDateKey(day.dateKey);
                    if (!day.inCurrentMonth) setVisibleMonth(new Date(day.date.getFullYear(), day.date.getMonth(), 1));
                  }}
                  aria-label={`${day.date.toLocaleDateString("zh-CN")}，完成度 ${stats.completion}%`}
                  aria-pressed={isSelected}
                >
                  <span className="calendar-day-top">
                    <strong>{day.date.getDate()}</strong>
                    {isToday && <em>今天</em>}
                    {hasActivity && <small>{stats.completion}%</small>}
                  </span>
                  <span className="calendar-day-progress" aria-hidden="true">
                    <i style={{ width: `${stats.completion}%` }} />
                  </span>
                  {hasActivity ? (
                    <span className="calendar-day-metrics">
                      {stats.newWords > 0 && <i className="new">新 {stats.newWords}</i>}
                      {stats.reviewedWords > 0 && <i className="reviewed">复 {stats.reviewedWords}</i>}
                      {stats.wrongWordCount > 0 && <i className="wrong">错 {stats.wrongWordCount}</i>}
                    </span>
                  ) : (
                    <span className="calendar-day-empty">—</span>
                  )}
                </button>
              );
            })}
          </div>
        </section>

        <aside className="calendar-detail panel" aria-live="polite">
          <div className="calendar-detail-heading">
            <div>
              <p className="eyebrow">当天详情</p>
              <h2>{formatSelectedDate(selectedDateKey)}</h2>
            </div>
            <div className={`calendar-completion-ring ${selectedStats.completion >= 100 ? "complete" : ""}`} style={{ "--completion": `${selectedStats.completion * 3.6}deg` } as React.CSSProperties}>
              <span>{selectedStats.completion}%</span>
            </div>
          </div>

          <div className="calendar-deck-switcher">
            <label htmlFor="calendar-detail-deck">统计词库</label>
            {decks.length > 1 ? (
              <select id="calendar-detail-deck" value={detailDeck?.id ?? ""} onChange={(event) => setDetailDeckId(event.target.value)}>
                {decks.map((deck) => (
                  <option key={deck.id} value={deck.id}>
                    {deck.language === "en" ? "英语" : "日语"} · {deck.name}
                  </option>
                ))}
              </select>
            ) : (
              <div className="calendar-current-deck">
                <span>{detailDeck?.language === "en" ? "英" : "日"}</span>
                <strong>{detailDeck?.name ?? "尚未创建词库"}</strong>
              </div>
            )}
          </div>

          <div className="calendar-task-progress">
            <div>
              <span><Sparkles size={14} /> 新学任务</span>
              <strong>{selectedStats.newWords} <small>/ {selectedStats.newGoal}</small></strong>
              <i><b style={{ width: `${selectedStats.newGoal ? Math.min(100, selectedStats.newWords / selectedStats.newGoal * 100) : selectedStats.newWords ? 100 : 0}%` }} /></i>
            </div>
            <div>
              <span><RotateCcw size={14} /> 复习任务</span>
              <strong>{selectedStats.reviewedWords} <small>/ {selectedStats.reviewGoal}</small></strong>
              <i><b style={{ width: `${selectedStats.reviewGoal ? Math.min(100, selectedStats.reviewedWords / selectedStats.reviewGoal * 100) : selectedStats.reviewedWords ? 100 : 0}%` }} /></i>
            </div>
          </div>

          <div className="calendar-detail-metrics">
            <div><BookOpenCheck size={15} /><span>作答次数</span><strong>{selectedStats.totalAttempts}</strong></div>
            <div><CheckCircle2 size={15} /><span>正确率</span><strong>{selectedStats.totalAttempts ? `${selectedStats.accuracy}%` : "—"}</strong></div>
            <div className={selectedStats.wrongWordCount > 0 ? "wrong" : ""}><AlertCircle size={15} /><span>错题单词</span><strong>{selectedStats.wrongWordCount}</strong></div>
          </div>

          <div className="calendar-wrong-section">
            <div className="calendar-section-title">
              <div><h3>当天错题</h3><p>测试中选择“忘记”或答错的单词会自动记录。</p></div>
              {selectedStats.wrongAttempts > 0 && <span>{selectedStats.wrongAttempts} 次错误</span>}
            </div>
            {selectedStats.wrongEntries.length ? (
              <div className="calendar-wrong-list">
                {selectedStats.wrongEntries.map((entry) => {
                  const deckNames = entry.word
                    ? decks.filter((deck) => entry.word?.deckIds.includes(deck.id)).map((deck) => deck.name)
                    : [];
                  return (
                    <div className="calendar-wrong-item" key={entry.key}>
                      <div>
                        <strong>{entry.word?.word ?? "已删除的词条"}</strong>
                        <span>{entry.word?.kana || entry.word?.meaning || "记录仍保留在学习历史中"}</span>
                      </div>
                      <div>
                        {deckNames.slice(0, 2).map((name) => <small key={name}>{name}</small>)}
                        <em>{entry.attempts} 次</em>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="calendar-detail-empty">
                <CheckCircle2 size={22} />
                <strong>{selectedStats.totalAttempts ? "这一天没有错题" : "这一天还没有学习记录"}</strong>
                <span>{selectedStats.totalAttempts ? "保持得很好，继续按计划复习。" : "完成学习或复习后，日历会自动同步。"}</span>
              </div>
            )}
          </div>
          <p className="calendar-goal-note">当天详情与完成度按「{detailDeck?.name ?? "当前词库"}」的每日新词和每日复习计划计算；上方月历保留全部词库汇总。</p>
        </aside>
      </div>
    </div>
  );
}
