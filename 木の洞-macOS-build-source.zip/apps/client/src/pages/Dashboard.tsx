import { ArrowRight, BookOpen, Check, Flame, Plus, Target } from "lucide-react";
import { Link } from "react-router-dom";
import { useAppState } from "@/services/AppState";

export default function Dashboard() {
  const { words, dueCount, newCount, completedToday, todayReviews, streak, queue } = useAppState();
  const mastered = words.filter((word) => word.status === "MATURE").length;
  const accuracy = todayReviews.length ? Math.round((todayReviews.filter((review) => review.rating !== "AGAIN").length / todayReviews.length) * 100) : 0;
  const totalToday = Math.min(dueCount, 50) + Math.min(newCount, 20);
  const progress = totalToday ? Math.min(100, Math.round((completedToday / totalToday) * 100)) : 100;
  const recent = [...words].filter((word) => word.lastReview).sort((a, b) => String(b.lastReview).localeCompare(String(a.lastReview))).slice(0, 4);

  return (
    <div className="page-stack">
      <section className="page-heading">
        <div>
          <p className="eyebrow">今天 · {new Date().toLocaleDateString("zh-CN", { month: "long", day: "numeric", weekday: "short" })}</p>
          <h1>早上好，继续保持。</h1>
          <p className="muted">用一小段专注时间，把记忆留得更久。</p>
        </div>
        <Link to="/add-word" className="button button-secondary"><Plus size={17} /> 添加单词</Link>
      </section>

      <section className="hero-study-card">
        <div className="hero-study-copy">
          <div className="hero-kicker"><Target size={15} /> 今日学习</div>
          <div className="hero-number">{queue.length}<span> 个任务</span></div>
          <p>{queue.length ? `先完成到期复习，再认识 ${Math.min(newCount, 20)} 个新词。` : "今天的任务已经完成，做得很好。"}</p>
          <Link to="/study" className="button button-primary">{queue.length ? "开始学习" : "查看词库"} <ArrowRight size={17} /></Link>
        </div>
        <div className="hero-progress">
          <div className="progress-ring" style={{ "--progress": `${progress * 3.6}deg` } as React.CSSProperties}>
            <div><strong>{progress}%</strong><span>今日进度</span></div>
          </div>
        </div>
      </section>

      <section className="metric-grid">
        <Metric label="待复习" value={dueCount} hint="到期卡片" tone="blue" />
        <Metric label="今日新词" value={Math.min(newCount, 20)} hint={`${newCount} 个待安排`} tone="purple" />
        <Metric label="已完成" value={completedToday} hint={todayReviews.length ? `${accuracy}% 正确` : "还没有记录"} tone="green" />
        <Metric label="已掌握" value={mastered} hint={`共 ${words.length} 个单词`} tone="orange" />
      </section>

      <section className="split-grid">
        <div className="panel">
          <div className="panel-heading"><div><h2>最近学习</h2><p className="muted">上次复习过的单词</p></div><Link to="/decks" className="text-link">查看全部 <ArrowRight size={14} /></Link></div>
          {recent.length ? <div className="recent-list">{recent.map((word) => <div key={word.id} className="recent-row"><div><strong>{word.word}</strong><span>{word.kana}</span></div><em>{word.meaning}</em></div>)}</div> : <EmptyState icon={<BookOpen size={22} />} text="完成第一次学习后，这里会显示最近的单词。" />}
        </div>
        <div className="panel quiet-panel">
          <div className="panel-heading"><div><h2>学习节奏</h2><p className="muted">每天一点，记得更牢</p></div><Flame size={20} className="accent-icon" /></div>
          <div className="streak-large"><strong>{streak}</strong><span>天连续学习</span></div>
          <div className="week-dots">{["一", "二", "三", "四", "五", "六", "日"].map((day, index) => <div key={day} className={`week-day ${index < Math.min(streak, 7) ? "done" : ""}`}><span>{day}</span><i /></div>)}</div>
        </div>
      </section>
    </div>
  );
}

function Metric({ label, value, hint, tone }: { label: string; value: number; hint: string; tone: string }) {
  return <div className="metric-card"><span className={`metric-dot ${tone}`} /><div><span className="metric-label">{label}</span><strong>{value}</strong><small>{hint}</small></div></div>;
}

function EmptyState({ icon, text }: { icon: React.ReactNode; text: string }) {
  return <div className="empty-state"><div className="empty-icon">{icon}</div><p>{text}</p></div>;
}
