import { Check, CircleUserRound, Contrast, Droplets, Moon, Monitor, Palette, Square, Sun, Volume2 } from "lucide-react";
import { useState, type ReactNode } from "react";
import LocalAssetsSettings from "@/components/LocalAssetsSettings";
import { DesktopTtsSettings, DesktopVersionSettings, KonohaAccountSettings } from "@/components/KonohaDesktopSettings";
import DataMigrationSettings from "@/components/DataMigrationSettings";
import { useAppState } from "@/services/AppState";
import type { AccentColor, AppSettings, ThemeMode, VoicePreference } from "@/types";

const accentOptions: { key: AccentColor; label: string }[] = [
  { key: "blue", label: "蓝色" },
  { key: "green", label: "绿色" },
  { key: "teal", label: "青色" },
  { key: "indigo", label: "靛蓝" },
  { key: "violet", label: "紫色" },
  { key: "rose", label: "玫瑰" },
  { key: "coral", label: "珊瑚红" },
  { key: "amber", label: "琥珀" },
  { key: "black", label: "黑色" },
  { key: "gray", label: "灰色" },
];

export default function SettingsV2() {
  const { settings, updateSettings } = useAppState();
  const update = (next: Partial<AppSettings>) => void updateSettings(next);
  const [accountOpen, setAccountOpen] = useState(false);
  const [displayName, setDisplayName] = useState(settings.account.displayName);
  const [email, setEmail] = useState(settings.account.email);
  const themes: { key: ThemeMode; label: string; icon: typeof Sun }[] = [
    { key: "light", label: "浅色", icon: Sun },
    { key: "dark", label: "深色", icon: Moon },
    { key: "system", label: "跟随系统", icon: Monitor },
  ];
  const voices: { key: VoicePreference; label: string; desc: string }[] = [
    { key: "natural", label: "自然发音", desc: "按词库语言选择更自然的设备声音" },
    { key: "female", label: "女性声音", desc: "在日语或英语声音中优先匹配女性音色" },
    { key: "male", label: "男性声音", desc: "在日语或英语声音中优先匹配男性音色" },
  ];
  return <div className="page-stack narrow-page"><section className="page-heading"><div><p className="eyebrow">设置</p><h1>保持适合你的节奏</h1><p className="muted">学习、界面和账号偏好集中在这里。</p></div></section><section className="settings-card">
    <SettingSection title="词库学习计划"><p className="settings-note">每日新词、每日最大复习、学习顺序、重学间隔、学习方式和复习方式都已移到每个词库的“设置”页签，便于分别安排。</p></SettingSection>
    <SettingSection title="界面颜色" id="appearance"><SettingRow title="色调模式" desc="保留原版与低饱和配色，并增加白色、克制的简洁模式"><div className="color-style-options"><button className={`color-style-option ${settings.colorStyle === "standard" ? "selected" : ""}`} onClick={() => update({ colorStyle: "standard" })}><Contrast size={16} /><span><strong>标准模式</strong><small>原版配色</small></span>{settings.colorStyle === "standard" && <Check size={14} />}</button><button className={`color-style-option ${settings.colorStyle === "low_saturation" ? "selected" : ""}`} onClick={() => update({ colorStyle: "low_saturation" })}><Droplets size={16} /><span><strong>低饱和模式</strong><small>灰白柔和</small></span>{settings.colorStyle === "low_saturation" && <Check size={14} />}</button><button className={`color-style-option ${settings.colorStyle === "minimal" ? "selected" : ""}`} onClick={() => update({ colorStyle: "minimal" })}><Square size={16} /><span><strong>简洁模式</strong><small>暖白极简</small></span>{settings.colorStyle === "minimal" && <Check size={14} />}</button></div></SettingRow><SettingRow title="主强调色" desc="选择按钮、进度、日历和选中状态使用的主色"><div className="accent-options">{accentOptions.map((item) => <button key={item.key} className={`accent-option ${item.key} ${settings.accentColor === item.key ? "selected" : ""}`} onClick={() => update({ accentColor: item.key })} aria-label={item.label} title={item.label}><i /> <span>{item.label}</span>{settings.accentColor === item.key && <Check size={12} />}</button>)}</div></SettingRow><SettingRow title="跟随色调模式" desc="开启后强调色会随标准、低饱和、简洁模式自动调整；关闭后始终使用当前选择的强调色"><label className="accent-follow-switch"><span className="sr-only">跟随色调模式</span><input type="checkbox" checked={settings.accentFollowColorStyle} onChange={(event) => update({ accentFollowColorStyle: event.target.checked })} /><span aria-hidden="true" /></label></SettingRow><SettingRow title="明暗模式" desc="简洁模式同样支持明亮、深色或跟随系统"><div className="theme-options">{themes.map((item) => { const Icon = item.icon; return <button key={item.key} className={`theme-option ${settings.theme === item.key ? "selected" : ""}`} onClick={() => update({ theme: item.key })}><Icon size={16} /><span>{item.label}</span>{settings.theme === item.key && <Check size={14} />}</button>; })}</div></SettingRow><SettingRow title="界面缩放" desc="适配 MacBook 或大屏 Mac 显示器的阅读比例"><select value={settings.uiScale} onChange={(event) => update({ uiScale: Number(event.target.value) as AppSettings["uiScale"] })}><option value={0.9}>90% 紧凑</option><option value={1}>100% 标准</option><option value={1.1}>110% 舒适</option><option value={1.2}>120% 放大</option></select></SettingRow></SettingSection>
    <SettingSection title="配音"><SettingRow title="默认发音声音" desc="学习页、单词详情和试听会按词库语言使用这里的偏好"><div className="voice-options">{voices.map((item) => <button key={item.key} className={`voice-option ${settings.voice === item.key ? "selected" : ""}`} onClick={() => update({ voice: item.key })}><Volume2 size={15} /><span><strong>{item.label}</strong><small>{item.desc}</small></span>{settings.voice === item.key && <Check size={14} />}</button>)}</div></SettingRow><p className="settings-note voice-note">不同操作系统提供的日语、英语声音名称和性别标记可能不同；软件会按词库语言尽量匹配，找不到时自动回退到最接近的可用声音。</p></SettingSection>
    <DesktopTtsSettings />
    <LocalAssetsSettings />
    <DataMigrationSettings />
    <KonohaAccountSettings />
    <DesktopVersionSettings />
    <SettingSection title="账号"><div className="account-box"><div className="account-avatar"><CircleUserRound size={20} /></div><div className="account-copy"><strong>{settings.account.signedIn ? settings.account.displayName || settings.account.email : "本地学习账号"}</strong><span>{settings.account.signedIn ? settings.account.email : "目前使用本地账号，数据保存在此浏览器"}</span></div><button className="button button-primary compact" onClick={() => setAccountOpen(true)}><Palette size={14} /> {settings.account.signedIn ? "编辑资料" : "设置账号"}</button></div>{accountOpen && <div className="inline-account-form"><input value={displayName} onChange={(event) => setDisplayName(event.target.value)} placeholder="昵称" /><input value={email} onChange={(event) => setEmail(event.target.value)} placeholder="邮箱（可选）" /><button className="button button-secondary compact" onClick={() => setAccountOpen(false)}>取消</button><button className="button button-primary compact" disabled={!displayName.trim()} onClick={() => { void updateSettings({ account: { displayName: displayName.trim(), email: email.trim(), signedIn: true } }); setAccountOpen(false); }}>保存</button></div>}<p className="settings-note">账号入口目前用于本地身份标记；跨设备云同步需要后端账号与数据服务，当前版本不会伪称已同步。</p></SettingSection>
    <p className="settings-note">数据保存于本地 IndexedDB。清除浏览器站点数据会同时清除词库和学习记录。</p>
  </section></div>;
}

function SettingSection({ title, id, children }: { title: string; id?: string; children: ReactNode }) {
  return <div className="setting-section" id={id}><h2>{title}</h2>{children}</div>;
}

function SettingRow({ title, desc, children }: { title: string; desc: string; children: ReactNode }) {
  return <div className="setting-row"><div><strong>{title}</strong><span>{desc}</span></div>{children}</div>;
}
