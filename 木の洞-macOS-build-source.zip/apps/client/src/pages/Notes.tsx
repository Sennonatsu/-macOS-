import { BookOpen, Check, Edit3, NotebookPen, Save, Search, Star, X } from "lucide-react";
import { useMemo, useState } from "react";
import { Link, Navigate, useSearchParams } from "react-router-dom";
import { useAppState } from "@/services/AppState";
import type { WordCard } from "@/types";

type NoteFilter = "all" | "favorite" | "notes";

export default function Notes() {
  const { ready, words, decks, upsertWord } = useAppState();
  const [params] = useSearchParams();
  const selectedDeckId = params.get("deck");
  const selectedDeck = decks.find((deck) => deck.id === selectedDeckId);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<NoteFilter>("all");
  const [editingId, setEditingId] = useState<string | null>(null);
  const [drafts, setDrafts] = useState<Record<string, string>>({});
  const [savedId, setSavedId] = useState<string | null>(null);

  const noteworthyWords = useMemo(
    () => words.filter((word) => word.deckIds.includes(selectedDeckId ?? "") && (word.favorite || Boolean(word.note?.trim()))),
    [selectedDeckId, words],
  );
  const visibleWords = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    return noteworthyWords
      .filter((word) => {
        if (filter === "favorite" && !word.favorite) return false;
        if (filter === "notes" && !word.note?.trim()) return false;
        if (!normalized) return true;
        const deckNames = word.deckIds.map((id) => decks.find((deck) => deck.id === id)?.name ?? "");
        return [word.word, word.kana, word.meaning, word.note ?? "", ...deckNames]
          .some((value) => value.toLocaleLowerCase().includes(normalized));
      })
      .sort((a, b) => Number(Boolean(b.favorite)) - Number(Boolean(a.favorite)) || b.createdAt.localeCompare(a.createdAt));
  }, [decks, filter, noteworthyWords, query]);

  const favoriteCount = noteworthyWords.filter((word) => word.favorite).length;
  const noteCount = noteworthyWords.filter((word) => word.note?.trim()).length;

  async function toggleFavorite(word: WordCard) {
    await upsertWord({ ...word, favorite: !word.favorite });
  }

  function startEditing(word: WordCard) {
    setDrafts((current) => ({ ...current, [word.id]: current[word.id] ?? word.note ?? "" }));
    setEditingId(word.id);
    setSavedId(null);
  }

  async function saveNote(word: WordCard) {
    const note = (drafts[word.id] ?? word.note ?? "").trim();
    await upsertWord({ ...word, note });
    setEditingId(null);
    setSavedId(word.id);
    window.setTimeout(() => setSavedId((current) => current === word.id ? null : current), 1800);
  }

  if (!ready) return <div className="loading-state">正在整理笔记…</div>;
  if (!selectedDeckId && decks[0]) return <Navigate to={`/notes?deck=${encodeURIComponent(decks[0].id)}`} replace />;
  if (selectedDeckId && !selectedDeck) return <div className="empty-library"><h3>找不到这个笔记词库</h3><p>请从左侧笔记子菜单重新选择。</p></div>;

  return (
    <div className="page-stack notes-page">
      <section className="page-heading notes-heading">
        <div>
          <p className="eyebrow">{selectedDeck?.language === "en" ? "英语笔记" : "日语笔记"}</p>
          <h1>{selectedDeck?.name ?? "重点与笔记"}</h1>
          <p className="muted">当前只显示这个词库中的重点单词和个人笔记。</p>
        </div>
        <Link to="/decks" className="button button-secondary"><BookOpen size={16} /> 前往词库</Link>
      </section>

      <section className="notes-summary" aria-label="重点与笔记统计">
        <div><span>已整理</span><strong>{noteworthyWords.length}</strong><small>个单词</small></div>
        <div><span><Star size={13} /> 重点</span><strong>{favoriteCount}</strong><small>个标记</small></div>
        <div><span><NotebookPen size={13} /> 笔记</span><strong>{noteCount}</strong><small>条记录</small></div>
      </section>

      <section className="notes-toolbar">
        <div className="search-box">
          <Search size={17} />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索单词、释义、词库或笔记内容" />
          {query && <button onClick={() => setQuery("")} aria-label="清除搜索"><X size={15} /></button>}
        </div>
        <div className="notes-filters" aria-label="笔记筛选">
          {([
            ["all", "全部"],
            ["favorite", "重点"],
            ["notes", "有笔记"],
          ] as [NoteFilter, string][]).map(([key, label]) => (
            <button key={key} className={filter === key ? "active" : ""} onClick={() => setFilter(key)}>{label}</button>
          ))}
        </div>
      </section>

      {visibleWords.length ? (
        <section className="note-card-grid">
          {visibleWords.map((word) => {
            const deckNames = word.deckIds.map((id) => decks.find((deck) => deck.id === id)?.name).filter((name): name is string => Boolean(name));
            const isEditing = editingId === word.id;
            const draft = drafts[word.id] ?? word.note ?? "";
            return (
              <article className={`note-card ${word.favorite ? "is-favorite" : ""}`} key={word.id}>
                <div className="note-card-top">
                  <div className="note-word">
                    <span>{word.kana || (word.language === "en" ? "未填写音标" : "假名未填写")}</span>
                    <h2>{word.word}</h2>
                    <p>{word.meaning}</p>
                  </div>
                  <button
                    className={`favorite-toggle ${word.favorite ? "active" : ""}`}
                    onClick={() => void toggleFavorite(word)}
                    aria-label={word.favorite ? `取消重点：${word.word}` : `设为重点：${word.word}`}
                    title={word.favorite ? "取消重点" : "设为重点"}
                  >
                    <Star size={18} fill={word.favorite ? "currentColor" : "none"} />
                  </button>
                </div>
                <div className="note-decks">
                  <span className="note-language">{word.language === "en" ? "EN" : "日"}</span>
                  {deckNames.length ? deckNames.map((name) => <span key={name}>{name}</span>) : <span>未分类</span>}
                </div>
                <div className="note-card-body">
                  <div className="note-label"><NotebookPen size={14} /><span>我的笔记</span></div>
                  {isEditing ? (
                    <textarea
                      autoFocus
                      value={draft}
                      onChange={(event) => setDrafts((current) => ({ ...current, [word.id]: event.target.value }))}
                      placeholder="记录联想、易错点、语法用法或例句…"
                      rows={5}
                    />
                  ) : (
                    <p className={word.note?.trim() ? "" : "note-empty-copy"}>{word.note?.trim() || "还没有笔记，点击编辑开始记录。"}</p>
                  )}
                </div>
                <div className="note-card-footer">
                  <span className={`note-saved ${savedId === word.id ? "visible" : ""}`}><Check size={13} /> 已保存</span>
                  {isEditing ? (
                    <div>
                      <button className="button button-secondary compact" onClick={() => setEditingId(null)}>取消</button>
                      <button className="button button-primary compact" onClick={() => void saveNote(word)}><Save size={14} /> 保存笔记</button>
                    </div>
                  ) : (
                    <button className="note-edit-button" onClick={() => startEditing(word)}><Edit3 size={14} /> {word.note?.trim() ? "编辑笔记" : "添加笔记"}</button>
                  )}
                </div>
              </article>
            );
          })}
        </section>
      ) : (
        <section className="notes-empty">
          <div><NotebookPen size={25} /></div>
          <h2>{query || filter !== "all" ? "没有符合条件的记录" : "还没有重点与笔记"}</h2>
          <p>{query || filter !== "all" ? "调整搜索词或筛选条件再看看。" : "在词库中点亮星标，或为单词写下笔记，它们会自动汇集到这里。"}</p>
          <Link to="/decks" className="button button-primary"><BookOpen size={16} /> 去词库标记</Link>
        </section>
      )}
    </div>
  );
}
