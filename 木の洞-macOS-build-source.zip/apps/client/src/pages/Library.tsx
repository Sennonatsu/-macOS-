import { ArrowRight, BookOpen, ChevronDown, Download, Edit3, FileAudio, FolderPlus, NotebookPen, Pause, Play, Plus, Search, Star, Trash2, Upload, X } from "lucide-react";
import { useMemo, useRef, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useAppState } from "@/services/AppState";
import { exportWordsCsv, materializeImportedWord, parseWordsCsv, type DuplicateMode } from "@/services/csv";
import { mapAnkiRecord, parseAnkiPackage, resolveAnkiMedia, type AnkiFieldMapping, type AnkiImportData } from "@/services/anki";
import { createId } from "@/services/storage";
import { normalizeAudioLookupKey } from "@/services/tts";
import { getDeckStats } from "@/services/deckStats";
import type { Deck, LibraryMenu, WordCard } from "@/types";

export default function Library() {
  const { words, decks, reviews, settings, dueCount, newCount, upsertWord, removeWord, addDeck, updateDeck, removeDeck, saveLocalAsset, localAssets } = useAppState();
  const [query, setQuery] = useState("");
  const [selectedDeck, setSelectedDeck] = useState<string | null>(null);
  const [sort, setSort] = useState<"recent" | "name" | "created" | "progress">("recent");
  const [showWords, setShowWords] = useState(false);
  const [editingDeck, setEditingDeck] = useState<Deck | null>(null);
  const [importData, setImportData] = useState<{ rows: ReturnType<typeof parseWordsCsv>; duplicates: WordCard[] } | null>(null);
  const [ankiImportData, setAnkiImportData] = useState<AnkiImportData | null>(null);
  const [ankiMapping, setAnkiMapping] = useState<AnkiFieldMapping | null>(null);
  const [ankiTargetDeckId, setAnkiTargetDeckId] = useState<string>("");
  const [ankiCreateDecks, setAnkiCreateDecks] = useState(true);
  const [ankiDuplicateMode, setAnkiDuplicateMode] = useState<"skip" | "overwrite" | "merge">("merge");
  const [ankiBusy, setAnkiBusy] = useState(false);
  const [ankiNotice, setAnkiNotice] = useState("");
  const [showCreate, setShowCreate] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const requestedMenuId = params.get("menu");
  const activeMenu = settings.libraryMenus.find((menu) => menu.id === requestedMenuId);
  const menuDecks = activeMenu ? decks.filter((deck) => deck.menuId === activeMenu.id) : decks;
  const activeMenuLanguage = activeMenu?.language ?? "ja";

  const sortedDecks = useMemo(() => {
    const list = [...menuDecks];
    if (sort === "name") return list.sort((a, b) => a.name.localeCompare(b.name, "zh-CN"));
    if (sort === "created") return list.sort((a, b) => b.createdAt.localeCompare(a.createdAt));
    if (sort === "progress") return list.sort((a, b) => getDeckStats(b, words, reviews).progress - getDeckStats(a, words, reviews).progress);
    return list.sort((a, b) => String(b.lastStudiedAt ?? b.updatedAt ?? b.createdAt).localeCompare(String(a.lastStudiedAt ?? a.updatedAt ?? a.createdAt)));
  }, [menuDecks, sort, words, reviews]);

  const activeDeck = selectedDeck ? decks.find((deck) => deck.id === selectedDeck) : null;
  const deckWords = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    const menuDeckIds = new Set(menuDecks.map((deck) => deck.id));
    return words.filter((word) => {
      const inScope = activeDeck ? word.deckIds.includes(activeDeck.id) : !activeMenu || word.deckIds.some((deckId) => menuDeckIds.has(deckId));
      return inScope && (!normalized || [word.word, word.kana, word.meaning, word.note ?? "", ...word.tags].some((value) => value.toLowerCase().includes(normalized)));
    });
  }, [activeDeck, activeMenu, menuDecks, query, words]);

  async function handleFile(file: File) {
    if (file.name.toLowerCase().endsWith(".apkg") || file.name.toLowerCase().endsWith(".colpkg")) {
      try {
        setAnkiBusy(true);
        const parsed = await parseAnkiPackage(file, activeMenuLanguage);
        setAnkiImportData(parsed);
        setAnkiMapping(parsed.mapping);
        setAnkiTargetDeckId(activeDeck?.id ?? "");
        setAnkiNotice("");
      } catch (error) {
        setAnkiNotice(error instanceof Error ? error.message : "无法解析这个 Anki 文件。");
      } finally {
        setAnkiBusy(false);
      }
      return;
    }
    const deckId = activeDeck?.id ?? menuDecks[0]?.id ?? decks[0]?.id;
    if (!deckId) return;
    const language = decks.find((deck) => deck.id === deckId)?.language ?? "ja";
    const rows = parseWordsCsv(await file.text(), deckId, language);
    const duplicates = rows.map((row) => words.find((word) => word.word === row.word && (word.language ?? "ja") === (row.language ?? language))).filter((word): word is WordCard => Boolean(word));
    setImportData({ rows, duplicates });
  }

  function mappedAnkiRows() {
    if (!ankiImportData || !ankiMapping) return [];
    return ankiImportData.records
      .map((record) => ({ record, value: mapAnkiRecord(record, ankiMapping) }))
      .filter(({ value }) => value.word.trim());
  }

  async function finishAnkiImport() {
    if (!ankiImportData || !ankiMapping) return;
    setAnkiBusy(true);
    try {
      const rows = mappedAnkiRows();
      const deckMap = new Map<string, string>();
      const defaultDeck = activeDeck ?? decks.find((deck) => deck.id === ankiTargetDeckId) ?? menuDecks[0] ?? decks.find((deck) => (deck.language ?? "ja") === activeMenuLanguage);
      for (const { value } of rows) {
        const language = value.language;
        let deckId = ankiTargetDeckId || defaultDeck?.id || "";
        if (ankiCreateDecks) {
          const key = `${language}::${value.deckName}`;
          if (!deckMap.has(key)) {
            const existing = decks.find((deck) => deck.name.trim().toLocaleLowerCase() === value.deckName.trim().toLocaleLowerCase() && (deck.language ?? "ja") === language);
            const created = existing ?? await addDeck(value.deckName || "Anki 导入", undefined, settings.libraryMenus.find((menu) => (menu.language ?? "ja") === language)?.id ?? null, language);
            if (created) deckMap.set(key, created.id);
          }
          deckId = deckMap.get(key) ?? deckId;
        }
        if (!deckId) {
          const created = await addDeck(`${value.language === "en" ? "English" : "日语"} Anki 导入`, undefined, undefined, language);
          deckId = created?.id ?? "";
        }
        if (!deckId) continue;
        const existing = words.find((word) => word.word.trim().toLocaleLowerCase() === value.word.trim().toLocaleLowerCase() && (word.language ?? "ja") === value.language);
        if (existing && ankiDuplicateMode === "skip") continue;
        const incoming = {
          word: value.word,
          kana: value.kana,
          meaning: value.meaning || "（待补充）",
          partOfSpeech: "",
          example: value.example,
          exampleTranslation: value.exampleTranslation,
          tags: [...new Set(value.tags)],
          deckIds: [...new Set([...(existing?.deckIds ?? []), deckId])],
          language: value.language,
          note: "",
          favorite: false,
        };
        const prepared = existing && ankiDuplicateMode === "merge"
          ? {
              ...existing,
              ...incoming,
              word: existing.word,
              kana: existing.kana || incoming.kana,
              meaning: existing.meaning || incoming.meaning,
              example: existing.example || incoming.example,
              exampleTranslation: existing.exampleTranslation || incoming.exampleTranslation,
              tags: [...new Set([...existing.tags, ...incoming.tags])],
              deckIds: [...new Set([...existing.deckIds, deckId])],
            }
          : materializeImportedWord(incoming, existing, ankiDuplicateMode === "overwrite" ? "overwrite" : "copy");
        await upsertWord(prepared);
        const soundName = value.sounds[0];
        const asset = soundName ? resolveAnkiMedia(ankiImportData, soundName) : undefined;
        if (asset?.supported) {
          const lookupKey = normalizeAudioLookupKey(value.word);
          const oldAsset = localAssets.find((item) => item.kind === "word-audio" && item.language === value.language && item.lookupKey === lookupKey);
          await saveLocalAsset({
            id: oldAsset?.id ?? createId(),
            kind: "word-audio",
            name: asset.filename,
            mimeType: asset.mimeType,
            data: asset.data,
            language: value.language,
            lookupKey,
            importedAt: new Date().toISOString(),
          });
        }
      }
      setAnkiImportData(null);
      setAnkiMapping(null);
      setAnkiNotice(`已将 ${rows.length} 个 Anki 单词直接导入“我的词库”。${ankiCreateDecks ? `按 ${ankiImportData.deckNames.length} 个牌组归入词库。` : ""}`);
    } finally {
      setAnkiBusy(false);
    }
  }

  async function finishImport(mode: DuplicateMode) {
    if (!importData) return;
    const existingMap = new Map(words.map((word) => [`${word.language ?? "ja"}::${word.word}`, word]));
    await Promise.all(importData.rows.map((row) => {
      const existing = existingMap.get(`${row.language ?? "ja"}::${row.word}`);
      if (existing && mode === "skip") return Promise.resolve();
      return upsertWord(materializeImportedWord(row, existing, mode));
    }));
    setImportData(null);
  }

  function downloadCsv() {
    downloadWordList(deckWords, activeDeck?.name ?? "all");
  }

  function downloadWordList(exportWords: WordCard[], name: string) {
    const blob = new Blob([exportWordsCsv(exportWords)], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    const safeName = name.replace(/[\\/:*?"<>|]/g, "-").trim() || "词库";
    link.download = `木の洞-${safeName}.csv`;
    link.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 0);
  }

  return (
    <div className="page-stack library-page">
      <section className="page-heading library-heading">
        <div><p className="eyebrow">词库</p><h1>{activeMenu ? `${activeMenu.name}词库` : "我的词库"}</h1><p className="muted">{activeMenu ? `这里显示归入“${activeMenu.name}”子菜单的词库。` : "按照自己的节奏，整理正在学习的内容。"}</p></div>
        <div className="heading-actions"><button className="button button-secondary" onClick={() => setShowCreate(true)}><FolderPlus size={17} /> 新建词库</button><Link to={activeDeck ? `/add-word?deck=${encodeURIComponent(activeDeck.id)}` : `/add-word?language=${activeMenuLanguage}`} className="button button-primary"><Plus size={17} /> 添加单词</Link></div>
      </section>
      <section className="library-toolbar"><div className="search-box"><Search size={17} /><input placeholder={activeDeck ? `在「${activeDeck.name}」中搜索` : "搜索单词、读音、中文、标签或笔记"} value={query} onChange={(event) => { setQuery(event.target.value); setShowWords(true); }} />{query && <button onClick={() => setQuery("")} aria-label="清除搜索"><X size={15} /></button>}</div><div className="select-control"><select className="sort-select" value={sort} onChange={(event) => setSort(event.target.value as typeof sort)}><option value="recent">最近使用</option><option value="name">名称排序</option><option value="created">创建时间</option><option value="progress">学习进度</option></select><ChevronDown size={15} aria-hidden="true" /></div><button className="icon-text-button" onClick={() => fileRef.current?.click()}><Upload size={16} /> 导入</button><button className="icon-text-button" onClick={downloadCsv}><Download size={16} /> 导出</button><input ref={fileRef} type="file" accept=".csv,.apkg,.colpkg,text/csv,application/octet-stream" hidden onChange={(event) => { const file = event.target.files?.[0]; if (file) void handleFile(file); event.target.value = ""; }} /></section>
      {ankiBusy && !ankiImportData && <p className="asset-notice"><FileAudio size={14} /> 正在解析 Anki 词库，请稍候…</p>}
      {ankiNotice && !ankiImportData && <p className="asset-notice">{ankiNotice}</p>}

      {!showWords && <section className="deck-list">{sortedDecks.map((deck) => <DeckCard key={deck.id} deck={deck} menuName={settings.libraryMenus.find((menu) => menu.id === deck.menuId)?.name} stats={getDeckStats(deck, words, reviews)} onOpen={() => navigate(`/decks/${encodeURIComponent(deck.id)}`)} onStudy={() => { setSelectedDeck(deck.id); navigate(`/study?deck=${encodeURIComponent(deck.id)}`); }} onEdit={() => setEditingDeck(deck)} onExport={() => downloadWordList(words.filter((word) => word.deckIds.includes(deck.id)), deck.name)} onDelete={async (deleteWords) => { await removeDeck(deck.id, deleteWords); if (selectedDeck === deck.id) setSelectedDeck(null); }} />)}{!sortedDecks.length && <div className="empty-library"><BookOpen size={26} /><h3>{activeMenu ? `“${activeMenu.name}”下还没有词库` : "还没有词库"}</h3><p>{activeMenu ? "点击“新建词库”，它会自动归入当前子菜单。" : "创建第一个词库，开始建立自己的语言记忆系统。"}</p></div>}</section>}

      {showWords && <section className="word-browser"><div className="word-browser-heading"><div><button className="back-link inline-back" onClick={() => { setShowWords(false); setQuery(""); }}><ArrowRight size={15} className="rotate-back" /> 返回词库</button><h2>{activeDeck?.name ?? "全部单词"}</h2><p className="muted">{deckWords.length} 个单词 · 支持搜索、重点标记和笔记</p></div><div className="browser-stats"><span>待复习 <strong>{activeDeck ? getDeckStats(activeDeck, words, reviews).due : dueCount}</strong></span><span>新词 <strong>{activeDeck ? getDeckStats(activeDeck, words, reviews).unseen : newCount}</strong></span></div></div><div className="word-table-wrap"><table className="word-table"><thead><tr><th>单词</th><th>中文</th><th>词库</th><th>状态</th><th>下次复习</th><th /></tr></thead><tbody>{deckWords.map((word) => <WordRow key={word.id} word={word} decks={decks} onEdit={() => navigate(`/add-word?id=${word.id}`)} onDelete={() => { if (window.confirm(`删除「${word.word}」？`)) void removeWord(word.id); }} onToggleFavorite={() => void upsertWord({ ...word, favorite: !word.favorite })} onToggleSuspend={() => void upsertWord({ ...word, status: word.status === "SUSPENDED" ? "NEW" : "SUSPENDED" })} />)}</tbody></table>{!deckWords.length && <div className="empty-library"><Search size={26} /><h3>没有找到匹配的单词</h3><p>试试搜索日语、假名、中文、标签或笔记。</p></div>}</div></section>}

      {showCreate && <DeckModal title="新建词库" menus={settings.libraryMenus} defaultMenuId={activeMenu?.id ?? null} defaultLanguage={activeMenuLanguage} onClose={() => setShowCreate(false)} onSave={async (deck) => { await addDeck(deck.name, deck.description, deck.menuId, deck.language); setShowCreate(false); }} />}
      {editingDeck && <DeckModal title="编辑词库" deck={editingDeck} menus={settings.libraryMenus} languageLocked={words.some((word) => word.deckIds.includes(editingDeck.id))} onClose={() => setEditingDeck(null)} onSave={async (deck) => { await updateDeck(deck); setEditingDeck(null); }} />}
      {importData && <ImportModal rows={importData.rows.length} duplicates={importData.duplicates.length} onClose={() => setImportData(null)} onChoose={(mode) => void finishImport(mode)} />}
      {ankiImportData && ankiMapping && <AnkiImportModal data={ankiImportData} mapping={ankiMapping} onMappingChange={setAnkiMapping} targetDeckId={ankiTargetDeckId} decks={decks} createDecks={ankiCreateDecks} onTargetDeckChange={setAnkiTargetDeckId} onCreateDecksChange={setAnkiCreateDecks} duplicateMode={ankiDuplicateMode} onDuplicateModeChange={setAnkiDuplicateMode} busy={ankiBusy} onClose={() => setAnkiImportData(null)} onImport={() => void finishAnkiImport()} />}
    </div>
  );
}

function DeckCard({ deck, menuName, stats, onOpen, onStudy, onEdit, onExport, onDelete }: { deck: Deck; menuName?: string; stats: ReturnType<typeof getDeckStats>; onOpen: () => void; onStudy: () => void; onEdit: () => void; onExport: () => void; onDelete: (deleteWords: boolean) => Promise<void> }) {
  const [confirmOpen, setConfirmOpen] = useState(false);
  const cover = deck.coverDataUrl ? <img src={deck.coverDataUrl} alt="" /> : <div className="cover-fallback"><BookOpen size={22} /><strong>{deck.name.slice(0, 3)}</strong></div>;
  return <><article className="deck-card" onClick={onOpen}><div className="deck-card-main"><div className="deck-cover">{cover}</div><div className="deck-card-info"><div className="deck-card-title-row"><div><span className="deck-menu-label">{menuName ? `${menuName}词库 · ` : ""}{deck.language === "en" ? "English" : "日本語"}</span><h2>{deck.name}</h2></div><button className="icon-button" onClick={(event) => { event.stopPropagation(); onEdit(); }} aria-label="编辑词库"><Edit3 size={15} /></button></div><p className="deck-total">共 {stats.total} 词</p><div className="deck-progress"><span style={{ width: `${stats.progress}%` }} /></div><div className="deck-stats"><span><i className="status-dot green" />掌握 <strong>{stats.mature}</strong></span><span><i className="status-dot blue" />已学 <strong>{stats.learned}</strong></span><span className="deck-unseen">未学 {stats.unseen}</span></div></div></div><div className="deck-card-bottom"><div className="deck-secondary-stats"><span>待复习 <strong>{stats.due}</strong></span><span>今日新词 <strong>{stats.todayNew}</strong></span><span className="estimate">预计学完需 <strong>{stats.estimatedDays} 天</strong></span></div><div className="deck-card-actions"><button className="delete-quiet" onClick={(event) => { event.stopPropagation(); onExport(); }} aria-label={`导出${deck.name}词库`} title="导出此词库"><Download size={14} /></button><button className="delete-quiet" onClick={(event) => { event.stopPropagation(); setConfirmOpen(true); }} aria-label="删除词库"><Trash2 size={14} /></button><button className="button button-primary compact" onClick={(event) => { event.stopPropagation(); onStudy(); }}>学习 <ArrowRight size={15} /></button></div></div></article>{confirmOpen && <div className="modal-backdrop"><div className="modal-card"><div className="modal-header"><div><p className="eyebrow">删除词库</p><h2>确定删除「{deck.name}」吗？</h2></div><button className="icon-button" onClick={() => setConfirmOpen(false)} aria-label="关闭"><X size={18} /></button></div><p className="modal-copy">这个词库包含 {stats.total} 个单词。你可以只删除分类，或连同只属于它的单词一起删除。</p><div className="import-actions"><button className="button button-secondary" onClick={() => { setConfirmOpen(false); void onDelete(false); }}>只删除分类</button><button className="button button-danger" onClick={() => { setConfirmOpen(false); void onDelete(true); }}>分类和单词一起删除</button></div></div></div>}</>;
}

function WordRow({ word, decks, onEdit, onDelete, onToggleFavorite, onToggleSuspend }: { word: WordCard; decks: Deck[]; onEdit: () => void; onDelete: () => void; onToggleFavorite: () => void; onToggleSuspend: () => void }) {
  const names = word.deckIds.map((id) => decks.find((deck) => deck.id === id)?.name).filter(Boolean);
  return <tr><td><div className="word-cell"><strong>{word.word}</strong><span>{word.kana}</span>{word.note?.trim() && <NotebookPen size={12} className="note-icon" />}</div></td><td>{word.meaning}</td><td><div className="tag-list">{names.slice(0, 2).map((name) => <span key={name}>{name}</span>)}</div></td><td><span className={`status-badge ${word.status.toLowerCase()}`}>{libraryStatusLabel(word)}</span></td><td className="due-cell">{word.dueDate ? new Date(word.dueDate).toLocaleDateString("zh-CN", { month: "short", day: "numeric" }) : "新词"}</td><td><div className="row-actions"><button className={word.favorite ? "active-favorite" : ""} onClick={onToggleFavorite} aria-label={word.favorite ? "取消重点" : "设为重点"} title={word.favorite ? "取消重点" : "设为重点"}><Star size={15} fill={word.favorite ? "currentColor" : "none"} /></button><button onClick={onEdit} aria-label={word.note?.trim() ? "编辑笔记" : "添加笔记"} title={word.note?.trim() ? "编辑笔记" : "添加笔记"}><Edit3 size={15} /></button><button onClick={onToggleSuspend} aria-label={word.status === "SUSPENDED" ? "恢复学习" : "暂停学习"}>{word.status === "SUSPENDED" ? <Play size={15} /> : <Pause size={15} />}</button><button onClick={onDelete} aria-label="删除"><Trash2 size={15} /></button></div></td></tr>;
}

function libraryStatusLabel(word: WordCard) {
  const cycle = Math.min(7, word.reviewCycle ?? word.repetitions);
  if (word.status === "NEW" && cycle === 0) return "新词";
  if (cycle > 0) return `第 ${cycle} 周期`;
  return ({ NEW: "新词", LEARNING: "学习中", RELEARNING: "重学", REVIEW: "复习中", MATURE: "已掌握", SUSPENDED: "已暂停" } as Record<string, string>)[word.status];
}

function DeckModal({
  title,
  deck,
  menus,
  defaultMenuId = null,
  defaultLanguage = "ja",
  languageLocked = false,
  onClose,
  onSave,
}: {
  title: string;
  deck?: Deck;
  menus: LibraryMenu[];
  defaultMenuId?: string | null;
  defaultLanguage?: "ja" | "en";
  languageLocked?: boolean;
  onClose: () => void;
  onSave: (deck: Deck) => Promise<void>;
}) {
  const [form, setForm] = useState<Deck>(
    deck ?? {
      id: `deck-${Date.now()}`,
      name: "",
      language: defaultLanguage,
      menuId: defaultMenuId,
      dailyNewLimit: 20,
      dailyReviewLimit: 50,
      dailyGroupCount: 5,
      wordsPerGroup: 10,
      order: "due_first",
      learningMode: "TYPE_ANSWER",
      reviewMode: "TYPE_ANSWER",
      autoSpeak: false,
      voice: "natural",
      createdAt: new Date().toISOString(),
      lastStudiedAt: null,
    },
  );
  const coverRef = useRef<HTMLInputElement>(null);
  const language = form.language ?? "ja";
  const compatibleMenus = menus.filter(
    (menu) => (menu.language ?? "ja") === language,
  );
  const set = <K extends keyof Deck>(key: K, value: Deck[K]) =>
    setForm((current) => ({ ...current, [key]: value }));

  function changeLanguage(nextLanguage: "ja" | "en") {
    const nextMenus = menus.filter(
      (menu) => (menu.language ?? "ja") === nextLanguage,
    );
    setForm((current) => ({
      ...current,
      language: nextLanguage,
      menuId: nextMenus.some((menu) => menu.id === current.menuId)
        ? current.menuId
        : nextMenus[0]?.id ?? null,
      learningMode: "TYPE_ANSWER",
      reviewMode: "TYPE_ANSWER",
    }));
  }

  function readCover(file: File) {
    const reader = new FileReader();
    reader.onload = () => set("coverDataUrl", String(reader.result));
    reader.readAsDataURL(file);
  }

  return (
    <div className="modal-backdrop">
      <div className="modal-card deck-modal">
        <div className="modal-header">
          <div>
            <p className="eyebrow">词库设置</p>
            <h2>{title}</h2>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="关闭">
            <X size={18} />
          </button>
        </div>
        <div className="deck-form">
          <div className="form-grid">
            <label className="field">
              <span>学习语言</span>
              <select
                value={language}
                disabled={languageLocked}
                onChange={(event) =>
                  changeLanguage(event.target.value as "ja" | "en")
                }
              >
                <option value="ja">日语</option>
                <option value="en">英语</option>
              </select>
              {languageLocked && (
                <small className="field-hint">
                  已有单词后将固定语言，避免复习数据混用。
                </small>
              )}
            </label>
            <label className="field">
              <span>所属子菜单</span>
              <select
                value={form.menuId ?? ""}
                onChange={(event) =>
                  set("menuId", event.target.value || null)
                }
              >
                <option value="">未分类</option>
                {compatibleMenus.map((menu) => (
                  <option key={menu.id} value={menu.id}>
                    {menu.name.endsWith("词库")
                      ? menu.name
                      : `${menu.name}词库`}
                  </option>
                ))}
              </select>
              {!compatibleMenus.length && (
                <small className="field-hint">
                  请先在左侧新建一个
                  {language === "en" ? "英语" : "日语"}子菜单。
                </small>
              )}
            </label>
          </div>
          <label className="field">
            <span>
              名称<em>*</em>
            </span>
            <input
              autoFocus
              value={form.name}
              onChange={(event) => set("name", event.target.value)}
              placeholder={
                language === "en"
                  ? "例如：English Core 1000"
                  : "例如：新标准日本语初级上册"
              }
            />
          </label>
          <div className="cover-upload">
            <button
              className="cover-preview"
              onClick={() => coverRef.current?.click()}
            >
              {form.coverDataUrl ? (
                <img src={form.coverDataUrl} alt="" />
              ) : (
                <>
                  <Upload size={17} />
                  <span>选择封面</span>
                </>
              )}
            </button>
            <input
              ref={coverRef}
              hidden
              type="file"
              accept="image/*"
              onChange={(event) => {
                const file = event.target.files?.[0];
                if (file) readCover(file);
              }}
            />
            <span>可以上传教材封面，也可以使用自动生成的默认封面。</span>
          </div>
          <div className="form-grid">
            <label className="field">
              <span>每日新词</span>
              <input
                type="number"
                min={0}
                value={form.dailyNewLimit}
                onChange={(event) =>
                  set(
                    "dailyNewLimit",
                    Math.max(0, Number(event.target.value) || 0),
                  )
                }
              />
            </label>
            <label className="field">
              <span>每日最大复习</span>
              <input
                type="number"
                min={1}
                max={9999}
                value={form.dailyReviewLimit}
                onChange={(event) =>
                  set("dailyReviewLimit", Number(event.target.value))
                }
              />
            </label>
            <label className="field">
              <span>每天学习组数</span>
              <input
                type="number"
                min={1}
                max={50}
                value={form.dailyGroupCount}
                onChange={(event) =>
                  set(
                    "dailyGroupCount",
                    Math.max(1, Number(event.target.value)),
                  )
                }
              />
            </label>
            <label className="field">
              <span>每组词数</span>
              <input
                type="number"
                min={1}
                max={100}
                value={form.wordsPerGroup}
                onChange={(event) =>
                  set("wordsPerGroup", Math.max(1, Number(event.target.value)))
                }
              />
            </label>
            <label className="field">
              <span>学习顺序</span>
              <select
                value={form.order}
                onChange={(event) =>
                  set("order", event.target.value as Deck["order"])
                }
              >
                <option value="due_first">到期优先</option>
                <option value="new_first">新词优先</option>
                <option value="random">随机</option>
              </select>
            </label>
            <label className="field">
              <span>默认声音</span>
              <select
                value={form.voice}
                onChange={(event) =>
                  set("voice", event.target.value as Deck["voice"])
                }
              >
                <option value="natural">自然发音</option>
                <option value="female">女性声音</option>
                <option value="male">男性声音</option>
              </select>
            </label>
            <label className="field toggle-field">
              <span>学习时自动播放</span>
              <input
                type="checkbox"
                checked={form.autoSpeak}
                onChange={(event) => set("autoSpeak", event.target.checked)}
              />
            </label>
          </div>
        </div>
        <div className="import-actions">
          <button className="button button-secondary" onClick={onClose}>
            取消
          </button>
          <button
            className="button button-primary"
            disabled={!form.name.trim()}
            onClick={() => void onSave(form)}
          >
            保存词库
          </button>
        </div>
      </div>
    </div>
  );
}

function ImportModal({ rows, duplicates, onClose, onChoose }: { rows: number; duplicates: number; onClose: () => void; onChoose: (mode: DuplicateMode) => void }) {
  return <div className="modal-backdrop"><div className="modal-card"><div className="modal-header"><div><p className="eyebrow">导入 CSV</p><h2>确认导入内容</h2></div><button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button></div><p className="modal-copy">发现 <strong>{rows}</strong> 条有效记录，其中 <strong>{duplicates}</strong> 条与现有单词重复。</p><div className="import-actions"><button className="button button-secondary" onClick={() => onChoose("skip")}>跳过重复</button><button className="button button-secondary" onClick={() => onChoose("overwrite")}>覆盖重复</button><button className="button button-primary" onClick={() => onChoose("copy")}>全部创建</button></div></div></div>;
}

function AnkiImportModal({
  data,
  mapping,
  onMappingChange,
  targetDeckId,
  decks,
  createDecks,
  onTargetDeckChange,
  onCreateDecksChange,
  duplicateMode,
  onDuplicateModeChange,
  busy,
  onClose,
  onImport,
}: {
  data: AnkiImportData;
  mapping: AnkiFieldMapping;
  onMappingChange: (mapping: AnkiFieldMapping) => void;
  targetDeckId: string;
  decks: Deck[];
  createDecks: boolean;
  onTargetDeckChange: (id: string) => void;
  onCreateDecksChange: (value: boolean) => void;
  duplicateMode: "skip" | "overwrite" | "merge";
  onDuplicateModeChange: (mode: "skip" | "overwrite" | "merge") => void;
  busy: boolean;
  onClose: () => void;
  onImport: () => void;
}) {
  const rows = data.records.filter((record) => {
    const wordField = mapping.word || data.fieldNames[0];
    return Boolean(wordField && record.fields[wordField]?.trim());
  });
  const audioCount = rows.filter((record) => record.sounds.some((sound) => Boolean(resolveAnkiMedia(data, sound)?.supported))).length;
  const fieldOptions = <option value="">不导入</option>;
  const mappingFields: Array<[keyof AnkiFieldMapping, string]> = [
    ["word", "单词"],
    ["kana", "假名 / 读音"],
    ["meaning", "中文释义"],
    ["example", "例句"],
    ["exampleTranslation", "例句翻译"],
    ["audio", "音频字段"],
  ];
  return (
    <div className="modal-backdrop">
      <div className="modal-card anki-import-modal">
        <div className="modal-header">
          <div><p className="eyebrow">导入 Anki 词库</p><h2>检测到 Anki 词库</h2></div>
          <button className="icon-button" onClick={onClose} aria-label="关闭"><X size={18} /></button>
        </div>
        <div className="anki-import-summary">
          <div><strong>{data.fileName}</strong><span>{data.deckNames.length} 个牌组 · {rows.length} 个笔记</span></div>
          <div className="anki-import-stats"><span>音频 <b>{audioCount}</b></span><span>图片 <b>{data.imageCount}</b></span><span>标签 <b>{new Set(data.records.flatMap((record) => record.tags)).size}</b></span></div>
        </div>
        <p className="modal-copy">字段已根据名称自动识别。确认后会直接写入“我的词库”，Anki 音频会保存到木の洞本地音频资源中。</p>
        <div className="anki-mapping-grid">
          {mappingFields.map(([key, label]) => <label className="field" key={key}><span>{label}</span><select value={mapping[key]} onChange={(event) => onMappingChange({ ...mapping, [key]: event.target.value })}>{fieldOptions}{data.fieldNames.map((name) => <option value={name} key={name}>{name}</option>)}</select></label>)}
        </div>
        <div className="anki-import-options">
          <label className="field"><span>导入到</span><select disabled={createDecks} value={targetDeckId} onChange={(event) => onTargetDeckChange(event.target.value)}><option value="">自动新建 Anki 词库</option>{decks.map((deck) => <option key={deck.id} value={deck.id}>{deck.name} · {deck.language === "en" ? "英语" : "日语"}</option>)}</select></label>
          <label className="checkbox-row"><input type="checkbox" checked={createDecks} onChange={(event) => onCreateDecksChange(event.target.checked)} /><span>按 Anki 牌组分别归入词库</span></label>
          <label className="field"><span>重复单词</span><select value={duplicateMode} onChange={(event) => onDuplicateModeChange(event.target.value as typeof duplicateMode)}><option value="merge">合并缺失内容</option><option value="skip">跳过已有单词</option><option value="overwrite">用 Anki 内容更新</option></select></label>
        </div>
        {data.unsupportedAudioCount > 0 && <p className="field-hint">有 {data.unsupportedAudioCount} 个媒体文件格式可能无法播放，其他内容仍会继续导入。</p>}
        <div className="import-actions"><button className="button button-secondary" onClick={onClose} disabled={busy}>取消</button><button className="button button-primary" onClick={onImport} disabled={busy || !mapping.word}>{busy ? "正在导入…" : `开始导入 ${rows} 个单词`}</button></div>
      </div>
    </div>
  );
}
