# 木の洞桌面版发布说明

## 架构

- UI 与学习逻辑：继续复用 `apps/client` React Web App。
- 桌面运行时：Tauri 2，窗口默认 `1200 × 800`，最小 `900 × 650`。
- 木の叶账号：Rust 本地后端 + SQLite。
- 密码：Argon2id 加盐散列，不保存明文。
- 快速登录：刷新凭据只保存在 Windows Credential Manager 或 macOS Keychain。
- 学习数据：每个 `user_id` 使用独立 IndexedDB，账号之间不能互相读取。
- 迁移：AES-GCM-256 加密 `.kino` 迁移包，PBKDF2-SHA256 派生密钥。
- AI TTS：Rust 后端代理 OpenAI、ElevenLabs、Google Cloud TTS、Azure Speech 和自定义 HTTPS API；密钥保存在系统钥匙串。
- TTS 缓存键：`user_id + provider + language + voice + speed + text` 的 SHA-256。

本版本按用户要求为单机版，不包含云端同步。木の叶账号及学习数据只存在当前电脑。

## 开发

需要 Node.js 22、pnpm 10、Rust stable，以及 Tauri 2 对应平台依赖。

```bash
pnpm install --frozen-lockfile
pnpm desktop:dev
```

正式前端构建：

```bash
pnpm --filter client build:desktop
```

`desktop:dev` 只用于开发调试。安装完成的正式 App 不需要 Node.js、pnpm、
localhost、VS Code 或开发服务器。

## Windows 本地测试包

先安装：

- Node.js 22 LTS
- pnpm 10
- Rust stable
- Visual Studio 2022 Build Tools 中的 “Desktop development with C++”
- Windows 10/11 SDK
- Microsoft Edge WebView2 Runtime

然后在项目根目录运行：

```powershell
pnpm install --frozen-lockfile
pnpm desktop:build:test:windows
```

生成：

- `release/local-test/木の洞-Setup-Unsigned.exe`
- `release/local-test/木の洞-Portable-Windows-Unsigned.zip`

这些文件没有代码签名，只用于自己的电脑测试。Windows SmartScreen
可能显示未知发布者；对外发布请使用下方正式签名工作流。

## macOS 本地测试包

先安装 Xcode Command Line Tools、Node.js 22、pnpm 10 和 Rust stable：

```bash
xcode-select --install
pnpm install --frozen-lockfile
pnpm desktop:build:test:macos
```

脚本会同时编译 Apple Silicon 与 Intel，生成：

- `release/local-test/木の洞-Unsigned.dmg`

该 DMG 仅用于本机测试，未经过 Developer ID 签名与 Apple 公证。对外发布请
使用下方正式签名工作流。

没有本地 Mac 时，也可以在 GitHub Actions 中手动运行
`.github/workflows/macos-self-use.yml`。该工作流使用 GitHub 的 macOS
Runner 生成同样的 Universal 自用版，不需要 Apple 签名证书。

## Windows 正式包

发布工作流生成：

- `木の洞-Setup.exe`
- `木の洞-Portable-Windows.zip`

仓库 Secret：

- `WINDOWS_CERTIFICATE_PFX_BASE64`：代码签名 PFX 的 Base64。
- `WINDOWS_CERTIFICATE_PASSWORD`：PFX 密码。

签名脚本位于 `src-tauri/scripts/sign-windows.ps1`，使用 SHA-256 与 DigiCert 时间戳。

## macOS Universal 正式包

发布工作流同时编译 Apple Silicon 与 Intel 架构，生成：

- `木の洞.dmg`

仓库 Secret：

- `APPLE_CERTIFICATE`
- `APPLE_CERTIFICATE_PASSWORD`
- `APPLE_SIGNING_IDENTITY`
- `APPLE_ID`
- `APPLE_APP_SPECIFIC_PASSWORD`
- `APPLE_TEAM_ID`

`APPLE_CERTIFICATE` 必须是 Developer ID Application `.p12` 文件的 Base64。工作流会先将证书导入临时 Keychain，再启用 hardened runtime、Developer ID 签名和 Apple 公证。

## 触发正式构建

推荐将源码推送到 GitHub 私有仓库，然后：

1. 打开 `Settings → Secrets and variables → Actions`。
2. 填入 Windows 与 macOS 签名 Secrets。
3. 打开 `Actions → 木の洞桌面正式版 → Run workflow`。
4. 构建完成后下载 `木の洞-Windows` 和 `木の洞-macOS-Universal`。

也可以推送 `desktop-v*` 标签自动构建并创建 Release：

```bash
git tag desktop-v1.0.0
git push origin desktop-v1.0.0
```

没有完整签名凭据时，正式工作流会明确失败，避免误发未签名安装包。

签名证书、证书密码和 Apple App 专用密码只能保存到仓库 Secrets，
不要放进源码，也不要通过聊天发送。

## 网页数据迁移

1. 在原网页版打开“设置 → 网页数据迁移”。
2. 设置至少 8 位迁移密码并导出 `.kino` 文件。
3. 安装木の洞桌面版并登录目标木の叶账号。
4. 打开同一设置区域，选择 `.kino` 文件并输入相同密码。
5. 导入会按 ID 合并词库、单词、复习记录、笔记与设置。

外部字体和音频素材不写入迁移包，以避免单个迁移文件过大；请在目标设备重新导入。

## 更新检测

桌面端已提供版本检查命令。发布服务器就绪后，在编译环境设置：

```text
KINODOU_UPDATE_MANIFEST_URL=https://example.com/kinodou/release.json
```

清单格式参见 `src-tauri/release-manifest.example.json`。下载地址必须使用 HTTPS，正式更新包应继续沿用相同签名身份。
