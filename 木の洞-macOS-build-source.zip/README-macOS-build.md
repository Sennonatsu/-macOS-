# 木の洞 macOS 构建包

当前项目已经接入 Tauri 桌面壳，产品名为「木の洞」，窗口尺寸、最小尺寸和 macOS 图标配置都已写入 `src-tauri/tauri.conf.json`。

## 在 macOS 上生成通用 DMG

需要在 macOS 上安装 Xcode Command Line Tools、Rust、Node.js 和 pnpm，然后在项目根目录执行：

```bash
pnpm install --frozen-lockfile
pnpm desktop:build --target universal-apple-darwin --bundles dmg
```

构建成功后，通用 Apple Silicon + Intel 的 DMG 位于：

```text
src-tauri/target/universal-apple-darwin/release/bundle/dmg/
```

当前 App 图标使用：

```text
src-tauri/icons/icon.icns
```

它是白底、居中的黑色树洞与叶子标记，不使用带宣传文字或黄色背景的图片。

## 说明

本构建包不包含用户的本地词库数据。词库、学习进度和设置会在用户自己的 macOS 应用数据目录中保存；更新 App 本体时不应删除该目录。
