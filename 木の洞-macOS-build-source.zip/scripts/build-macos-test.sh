#!/usr/bin/env bash
set -euo pipefail

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "此脚本只能在 macOS 上运行。" >&2
  exit 1
fi

project_root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$project_root"

rustup target add aarch64-apple-darwin x86_64-apple-darwin
pnpm desktop:build --target universal-apple-darwin --bundles dmg

release_directory="$project_root/release/local-test"
mkdir -p "$release_directory"

dmg_path="$(find src-tauri/target/universal-apple-darwin/release/bundle/dmg -name '*.dmg' -print -quit)"
if [[ -z "$dmg_path" ]]; then
  echo "没有找到生成的 DMG。" >&2
  exit 1
fi

cp "$dmg_path" "$release_directory/木の洞-Unsigned.dmg"

echo
echo "构建完成（仅供本机测试，未签名）："
echo "  release/local-test/木の洞-Unsigned.dmg"
