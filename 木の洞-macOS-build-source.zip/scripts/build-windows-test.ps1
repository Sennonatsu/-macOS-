$ErrorActionPreference = "Stop"

if ($env:OS -ne "Windows_NT") {
  throw "此脚本只能在 Windows 10/11 上运行。"
}

$projectRoot = Split-Path -Parent $PSScriptRoot
Set-Location $projectRoot

$env:KINODOU_ALLOW_UNSIGNED = "1"

pnpm desktop:build --bundles nsis
if ($LASTEXITCODE -ne 0) {
  throw "木の洞 Windows 测试版构建失败。"
}

$releaseDirectory = Join-Path $projectRoot "release\local-test"
New-Item -ItemType Directory -Force $releaseDirectory | Out-Null

$setup = Get-ChildItem "src-tauri\target\release\bundle\nsis\*.exe" |
  Select-Object -First 1
if (-not $setup) {
  throw "没有找到生成的 NSIS 安装包。"
}

$appExecutable = "src-tauri\target\release\kinodou.exe"
if (-not (Test-Path $appExecutable)) {
  throw "没有找到生成的木の洞程序。"
}

Copy-Item $setup.FullName (Join-Path $releaseDirectory "木の洞-Setup-Unsigned.exe") -Force
Copy-Item $appExecutable (Join-Path $releaseDirectory "木の洞.exe") -Force
Compress-Archive `
  -Path (Join-Path $releaseDirectory "木の洞.exe") `
  -DestinationPath (Join-Path $releaseDirectory "木の洞-Portable-Windows-Unsigned.zip") `
  -Force

Write-Host ""
Write-Host "构建完成（仅供本机测试，未签名）："
Write-Host "  release\local-test\木の洞-Setup-Unsigned.exe"
Write-Host "  release\local-test\木の洞-Portable-Windows-Unsigned.zip"
