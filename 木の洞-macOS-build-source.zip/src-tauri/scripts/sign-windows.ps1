param(
  [Parameter(Mandatory = $true, Position = 0)]
  [string]$BinaryPath
)

$ErrorActionPreference = "Stop"

if (-not $env:WINDOWS_CERTIFICATE_PATH -or -not $env:WINDOWS_CERTIFICATE_PASSWORD) {
  if ($env:KINODOU_ALLOW_UNSIGNED -eq "1") {
    Write-Warning "正在生成仅供本机测试的未签名木の洞程序：$BinaryPath"
    exit 0
  }
  throw "正式版签名需要 WINDOWS_CERTIFICATE_PATH 和 WINDOWS_CERTIFICATE_PASSWORD。"
}

$signTool = Get-Command signtool.exe -ErrorAction Stop
& $signTool.Source sign `
  /fd SHA256 `
  /td SHA256 `
  /tr "http://timestamp.digicert.com" `
  /f $env:WINDOWS_CERTIFICATE_PATH `
  /p $env:WINDOWS_CERTIFICATE_PASSWORD `
  $BinaryPath

if ($LASTEXITCODE -ne 0) {
  throw "Windows Authenticode 签名失败：$BinaryPath"
}
