mod accounts;
mod tts;

use accounts::{
    AccountError, AccountSummary, LoginInput, ProfileInput, RegisterInput, RegisterResult,
};
use serde::Serialize;
use std::path::PathBuf;
use tauri::{Manager, State};
use tts::{SaveTtsInput, SynthesizeInput, TtsAudioResult, TtsError, TtsProfile};

struct DesktopState {
    database_path: PathBuf,
    tts_cache_dir: PathBuf,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct RuntimeInfo {
    desktop: bool,
    product_name: &'static str,
    account_system_name: &'static str,
    version: String,
    platform: &'static str,
    cloud_sync_enabled: bool,
}

#[derive(Serialize, serde::Deserialize)]
#[serde(rename_all = "camelCase")]
struct UpdateManifest {
    version: String,
    notes: Option<String>,
    windows_url: Option<String>,
    macos_url: Option<String>,
    sha256: Option<String>,
}

#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
struct UpdateStatus {
    configured: bool,
    current_version: String,
    update_available: bool,
    manifest: Option<UpdateManifest>,
}

#[tauri::command]
fn desktop_runtime_info(app: tauri::AppHandle) -> RuntimeInfo {
    RuntimeInfo {
        desktop: true,
        product_name: "木の洞",
        account_system_name: "木の叶",
        version: app.package_info().version.to_string(),
        platform: std::env::consts::OS,
        cloud_sync_enabled: false,
    }
}

#[tauri::command]
async fn desktop_check_update(app: tauri::AppHandle) -> Result<UpdateStatus, String> {
    let current_version = app.package_info().version.to_string();
    let Some(url) = option_env!("KINODOU_UPDATE_MANIFEST_URL") else {
        return Ok(UpdateStatus {
            configured: false,
            current_version,
            update_available: false,
            manifest: None,
        });
    };
    if !url.starts_with("https://") {
        return Err("更新清单必须使用 HTTPS".into());
    }
    let manifest = reqwest::Client::new()
        .get(url)
        .send()
        .await
        .map_err(|error| format!("无法检查更新：{error}"))?
        .error_for_status()
        .map_err(|error| format!("更新服务返回错误：{error}"))?
        .json::<UpdateManifest>()
        .await
        .map_err(|error| format!("更新清单格式无效：{error}"))?;
    Ok(UpdateStatus {
        configured: true,
        update_available: manifest.version != current_version,
        current_version,
        manifest: Some(manifest),
    })
}

#[tauri::command]
fn konoha_register(
    state: State<'_, DesktopState>,
    input: RegisterInput,
) -> Result<RegisterResult, AccountError> {
    accounts::register(&state.database_path, input)
}

#[tauri::command]
fn konoha_login(
    state: State<'_, DesktopState>,
    input: LoginInput,
) -> Result<AccountSummary, AccountError> {
    accounts::login(&state.database_path, input)
}

#[tauri::command]
fn konoha_accounts(state: State<'_, DesktopState>) -> Result<Vec<AccountSummary>, AccountError> {
    accounts::list_accounts(&state.database_path)
}

#[tauri::command]
fn konoha_current_account(
    state: State<'_, DesktopState>,
) -> Result<Option<AccountSummary>, AccountError> {
    accounts::current_account(&state.database_path)
}

#[tauri::command]
fn konoha_switch_account(
    state: State<'_, DesktopState>,
    user_id: String,
) -> Result<AccountSummary, AccountError> {
    accounts::switch_account(&state.database_path, &user_id)
}

#[tauri::command]
fn konoha_logout(state: State<'_, DesktopState>) -> Result<(), AccountError> {
    accounts::logout(&state.database_path)
}

#[tauri::command]
fn konoha_remove_local_account(
    state: State<'_, DesktopState>,
    user_id: String,
) -> Result<(), AccountError> {
    accounts::remove_local_account(&state.database_path, &user_id)
}

#[tauri::command]
fn konoha_update_profile(
    state: State<'_, DesktopState>,
    user_id: String,
    input: ProfileInput,
) -> Result<AccountSummary, AccountError> {
    accounts::update_profile(&state.database_path, &user_id, input)
}

#[tauri::command]
fn konoha_change_password(
    state: State<'_, DesktopState>,
    user_id: String,
    current_password: String,
    new_password: String,
) -> Result<(), AccountError> {
    accounts::change_password(
        &state.database_path,
        &user_id,
        &current_password,
        &new_password,
    )
}

#[tauri::command]
fn konoha_reset_password(
    state: State<'_, DesktopState>,
    username: String,
    recovery_code: String,
    new_password: String,
) -> Result<(), AccountError> {
    accounts::reset_password(
        &state.database_path,
        &username,
        &recovery_code,
        &new_password,
    )
}

#[tauri::command]
fn konoha_delete_account(
    state: State<'_, DesktopState>,
    user_id: String,
    password: String,
) -> Result<(), AccountError> {
    accounts::delete_account(
        &state.database_path,
        &state.tts_cache_dir,
        &user_id,
        &password,
    )
}

#[tauri::command]
fn konoha_tts_profile(
    state: State<'_, DesktopState>,
    user_id: String,
) -> Result<TtsProfile, TtsError> {
    tts::load_profile(&state.database_path, &user_id)
}

#[tauri::command]
fn konoha_save_tts_profile(
    state: State<'_, DesktopState>,
    user_id: String,
    input: SaveTtsInput,
) -> Result<TtsProfile, TtsError> {
    tts::save_profile(&state.database_path, &user_id, input)
}

#[tauri::command]
async fn konoha_synthesize_tts(
    state: State<'_, DesktopState>,
    input: SynthesizeInput,
) -> Result<TtsAudioResult, TtsError> {
    tts::synthesize(&state.database_path, &state.tts_cache_dir, input).await
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .setup(|app| {
            let data_dir = app.path().app_data_dir()?;
            let cache_dir = app.path().app_cache_dir()?.join("tts");
            std::fs::create_dir_all(&data_dir)?;
            std::fs::create_dir_all(&cache_dir)?;
            let database_path = data_dir.join("kinoha.sqlite3");
            accounts::initialize(&database_path)
                .map_err(|error| std::io::Error::other(error.to_string()))?;
            app.manage(DesktopState {
                database_path,
                tts_cache_dir: cache_dir,
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            desktop_runtime_info,
            desktop_check_update,
            konoha_register,
            konoha_login,
            konoha_accounts,
            konoha_current_account,
            konoha_switch_account,
            konoha_logout,
            konoha_remove_local_account,
            konoha_update_profile,
            konoha_change_password,
            konoha_reset_password,
            konoha_delete_account,
            konoha_tts_profile,
            konoha_save_tts_profile,
            konoha_synthesize_tts
        ])
        .run(tauri::generate_context!())
        .expect("木の洞桌面应用启动失败");
}
