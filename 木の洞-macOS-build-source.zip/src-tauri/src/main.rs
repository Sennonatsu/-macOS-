fn main() {
    kinodou_lib::run();
}
