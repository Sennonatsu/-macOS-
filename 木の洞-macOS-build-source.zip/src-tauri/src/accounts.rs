use argon2::{
    password_hash::{PasswordHash, PasswordHasher, PasswordVerifier, SaltString},
    Argon2,
};
use chrono::{Duration, Utc};
use keyring::Entry;
use rand::rngs::OsRng;
use rusqlite::{params, Connection, OptionalExtension};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{fs, path::Path};
use uuid::Uuid;

const KEYRING_SERVICE: &str = "com.kinodou.desktop";

#[derive(Debug, thiserror::Error)]
pub enum AccountError {
    #[error("{0}")]
    Validation(String),
    #[error("木の叶号或密码不正确")]
    InvalidCredentials,
    #[error("这个木の叶号已经存在")]
    DuplicateUsername,
    #[error("这个邮箱已经绑定到其他木の叶账号")]
    DuplicateEmail,
    #[error("账号不存在")]
    NotFound,
    #[error("当前账号的快速登录状态已经过期，请重新登录")]
    SessionExpired,
    #[error("本地账号数据库操作失败")]
    Database(#[from] rusqlite::Error),
    #[error("系统钥匙串不可用：{0}")]
    Keyring(String),
    #[error("密码安全处理失败")]
    Password,
}

impl Serialize for AccountError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        serializer.serialize_str(&self.to_string())
    }
}

#[derive(Debug, Clone, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct AccountSummary {
    pub id: String,
    pub username: String,
    pub email: Option<String>,
    pub avatar_data_url: Option<String>,
    pub created_at: String,
    pub updated_at: String,
    pub last_login_at: Option<String>,
    pub active: bool,
    pub session_status: String,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct RegisterResult {
    pub account: AccountSummary,
    pub recovery_code: String,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct RegisterInput {
    pub username: String,
    pub password: String,
    pub email: Option<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct LoginInput {
    pub username: String,
    pub password: String,
    pub remember: bool,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct ProfileInput {
    pub email: Option<String>,
    pub avatar_data_url: Option<String>,
}

fn open(path: &Path) -> Result<Connection, AccountError> {
    let connection = Connection::open(path)?;
    connection.execute_batch(
        "PRAGMA foreign_keys = ON;
         PRAGMA journal_mode = WAL;
         PRAGMA busy_timeout = 5000;",
    )?;
    Ok(connection)
}

pub fn initialize(path: &Path) -> Result<(), AccountError> {
    let connection = open(path)?;
    connection.execute_batch(
        "CREATE TABLE IF NOT EXISTS users (
            id TEXT PRIMARY KEY,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            email TEXT UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            recovery_hash TEXT NOT NULL,
            avatar_data_url TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            last_login_at TEXT,
            failed_login_count INTEGER NOT NULL DEFAULT 0,
            locked_until TEXT
         );
         CREATE TABLE IF NOT EXISTS local_sessions (
            id TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            refresh_hash TEXT NOT NULL UNIQUE,
            expires_at TEXT NOT NULL,
            created_at TEXT NOT NULL,
            last_used_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
         );
         CREATE INDEX IF NOT EXISTS idx_local_sessions_user_id
            ON local_sessions(user_id);
         CREATE TABLE IF NOT EXISTS app_state (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at TEXT NOT NULL
         );
         CREATE TABLE IF NOT EXISTS tts_profiles (
            user_id TEXT PRIMARY KEY,
            provider TEXT NOT NULL DEFAULT 'default',
            voice TEXT NOT NULL DEFAULT 'female',
            language TEXT NOT NULL DEFAULT 'ja',
            speed REAL NOT NULL DEFAULT 1.0,
            pitch REAL NOT NULL DEFAULT 1.0,
            style TEXT,
            custom_url TEXT,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
         );
         CREATE TABLE IF NOT EXISTS tts_cache (
            cache_key TEXT PRIMARY KEY,
            user_id TEXT NOT NULL,
            provider TEXT NOT NULL,
            language TEXT NOT NULL,
            voice TEXT NOT NULL,
            speed REAL NOT NULL,
            text_hash TEXT NOT NULL,
            mime_type TEXT NOT NULL,
            file_path TEXT NOT NULL,
            created_at TEXT NOT NULL,
            last_used_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
         );",
    )?;
    Ok(())
}

fn validate_username(username: &str) -> Result<String, AccountError> {
    let clean = username.trim();
    if !(4..=24).contains(&clean.chars().count())
        || !clean
            .chars()
            .all(|character| character.is_ascii_alphanumeric() || character == '_')
    {
        return Err(AccountError::Validation(
            "木の叶号需为 4–24 位数字、英文字母或下划线".into(),
        ));
    }
    Ok(clean.to_string())
}

fn validate_password(password: &str) -> Result<(), AccountError> {
    if password.chars().count() < 8
        || !password
            .chars()
            .any(|character| character.is_ascii_alphabetic())
        || !password.chars().any(|character| character.is_ascii_digit())
    {
        return Err(AccountError::Validation(
            "密码至少 8 位，并同时包含字母和数字".into(),
        ));
    }
    Ok(())
}

fn normalize_email(email: Option<String>) -> Result<Option<String>, AccountError> {
    let clean = email.unwrap_or_default().trim().to_lowercase();
    if clean.is_empty() {
        return Ok(None);
    }
    if clean.len() > 254 || !clean.contains('@') || clean.starts_with('@') || clean.ends_with('@') {
        return Err(AccountError::Validation("请输入有效邮箱".into()));
    }
    Ok(Some(clean))
}

fn password_hash(password: &str) -> Result<String, AccountError> {
    let salt = SaltString::generate(&mut OsRng);
    Argon2::default()
        .hash_password(password.as_bytes(), &salt)
        .map(|hash| hash.to_string())
        .map_err(|_| AccountError::Password)
}

fn verify_password(password: &str, hash: &str) -> Result<bool, AccountError> {
    let parsed = PasswordHash::new(hash).map_err(|_| AccountError::Password)?;
    Ok(Argon2::default()
        .verify_password(password.as_bytes(), &parsed)
        .is_ok())
}

fn token_hash(value: &str) -> String {
    format!("{:x}", Sha256::digest(value.as_bytes()))
}

fn keyring_entry(user_id: &str) -> Result<Entry, AccountError> {
    Entry::new(KEYRING_SERVICE, &format!("session-{user_id}"))
        .map_err(|error| AccountError::Keyring(error.to_string()))
}

fn active_user_id(connection: &Connection) -> Result<Option<String>, AccountError> {
    Ok(connection
        .query_row(
            "SELECT value FROM app_state WHERE key = 'active_user_id'",
            [],
            |row| row.get(0),
        )
        .optional()?)
}

fn set_active_user(connection: &Connection, user_id: Option<&str>) -> Result<(), AccountError> {
    if let Some(user_id) = user_id {
        connection.execute(
            "INSERT INTO app_state(key, value, updated_at)
             VALUES('active_user_id', ?1, ?2)
             ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
            params![user_id, Utc::now().to_rfc3339()],
        )?;
    } else {
        connection.execute("DELETE FROM app_state WHERE key = 'active_user_id'", [])?;
    }
    Ok(())
}

fn account_by_id(
    connection: &Connection,
    user_id: &str,
    active: bool,
) -> Result<AccountSummary, AccountError> {
    connection
        .query_row(
            "SELECT id, username, email, avatar_data_url, created_at, updated_at, last_login_at
             FROM users WHERE id = ?1",
            params![user_id],
            |row| {
                Ok(AccountSummary {
                    id: row.get(0)?,
                    username: row.get(1)?,
                    email: row.get(2)?,
                    avatar_data_url: row.get(3)?,
                    created_at: row.get(4)?,
                    updated_at: row.get(5)?,
                    last_login_at: row.get(6)?,
                    active,
                    session_status: "ready".into(),
                })
            },
        )
        .optional()?
        .ok_or(AccountError::NotFound)
}

fn create_session(
    connection: &Connection,
    user_id: &str,
    remember: bool,
) -> Result<(), AccountError> {
    let refresh = format!("{}{}", Uuid::new_v4().simple(), Uuid::new_v4().simple());
    let now = Utc::now();
    let expires = now
        + if remember {
            Duration::days(90)
        } else {
            Duration::hours(24)
        };
    connection.execute(
        "INSERT INTO local_sessions(id, user_id, refresh_hash, expires_at, created_at, last_used_at)
         VALUES(?1, ?2, ?3, ?4, ?5, ?5)",
        params![
            Uuid::new_v4().to_string(),
            user_id,
            token_hash(&refresh),
            expires.to_rfc3339(),
            now.to_rfc3339()
        ],
    )?;
    keyring_entry(user_id)?
        .set_password(&refresh)
        .map_err(|error| AccountError::Keyring(error.to_string()))?;
    set_active_user(connection, Some(user_id))?;
    Ok(())
}

pub fn register(path: &Path, input: RegisterInput) -> Result<RegisterResult, AccountError> {
    let username = validate_username(&input.username)?;
    validate_password(&input.password)?;
    let email = normalize_email(input.email)?;
    let connection = open(path)?;
    if connection
        .query_row(
            "SELECT 1 FROM users WHERE username = ?1 COLLATE NOCASE",
            params![username],
            |_| Ok(()),
        )
        .optional()?
        .is_some()
    {
        return Err(AccountError::DuplicateUsername);
    }
    if let Some(ref email_value) = email {
        if connection
            .query_row(
                "SELECT 1 FROM users WHERE email = ?1 COLLATE NOCASE",
                params![email_value],
                |_| Ok(()),
            )
            .optional()?
            .is_some()
        {
            return Err(AccountError::DuplicateEmail);
        }
    }
    let id = Uuid::new_v4().to_string();
    let recovery_code = format!(
        "{}-{}-{}",
        &Uuid::new_v4().simple().to_string()[0..6],
        &Uuid::new_v4().simple().to_string()[0..6],
        &Uuid::new_v4().simple().to_string()[0..6]
    )
    .to_uppercase();
    let now = Utc::now().to_rfc3339();
    connection.execute(
        "INSERT INTO users(
           id, username, email, password_hash, recovery_hash, created_at, updated_at, last_login_at
         ) VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?6, ?6)",
        params![
            id,
            username,
            email,
            password_hash(&input.password)?,
            password_hash(&recovery_code)?,
            now
        ],
    )?;
    create_session(&connection, &id, true)?;
    Ok(RegisterResult {
        account: account_by_id(&connection, &id, true)?,
        recovery_code,
    })
}

pub fn login(path: &Path, input: LoginInput) -> Result<AccountSummary, AccountError> {
    let username = validate_username(&input.username)?;
    let connection = open(path)?;
    let row: Option<(String, String, i64, Option<String>)> = connection
        .query_row(
            "SELECT id, password_hash, failed_login_count, locked_until
             FROM users WHERE username = ?1 COLLATE NOCASE",
            params![username],
            |row| Ok((row.get(0)?, row.get(1)?, row.get(2)?, row.get(3)?)),
        )
        .optional()?;
    let (user_id, stored_hash, failed_count, locked_until) =
        row.ok_or(AccountError::InvalidCredentials)?;
    if locked_until
        .as_deref()
        .and_then(|value| chrono::DateTime::parse_from_rfc3339(value).ok())
        .is_some_and(|value| value.with_timezone(&Utc) > Utc::now())
    {
        return Err(AccountError::Validation(
            "登录失败次数过多，请稍后再试".into(),
        ));
    }
    if !verify_password(&input.password, &stored_hash)? {
        let next_count = failed_count + 1;
        let lock_until = if next_count >= 5 {
            Some((Utc::now() + Duration::minutes(5)).to_rfc3339())
        } else {
            None
        };
        connection.execute(
            "UPDATE users SET failed_login_count = ?1, locked_until = ?2 WHERE id = ?3",
            params![next_count, lock_until, user_id],
        )?;
        return Err(AccountError::InvalidCredentials);
    }
    let now = Utc::now().to_rfc3339();
    connection.execute(
        "UPDATE users SET last_login_at = ?1, updated_at = ?1,
                          failed_login_count = 0, locked_until = NULL
         WHERE id = ?2",
        params![now, user_id],
    )?;
    connection.execute(
        "DELETE FROM local_sessions WHERE user_id = ?1",
        params![user_id],
    )?;
    create_session(&connection, &user_id, input.remember)?;
    account_by_id(&connection, &user_id, true)
}

pub fn list_accounts(path: &Path) -> Result<Vec<AccountSummary>, AccountError> {
    let connection = open(path)?;
    let active_id = active_user_id(&connection)?;
    let mut statement = connection.prepare(
        "SELECT DISTINCT u.id, u.username, u.email, u.avatar_data_url,
                u.created_at, u.updated_at, u.last_login_at, s.expires_at
         FROM users u
         JOIN local_sessions s ON s.user_id = u.id
         ORDER BY COALESCE(u.last_login_at, u.created_at) DESC",
    )?;
    let now = Utc::now();
    let rows = statement.query_map([], |row| {
        let id: String = row.get(0)?;
        let expires_at: String = row.get(7)?;
        let expired = chrono::DateTime::parse_from_rfc3339(&expires_at)
            .map(|value| value.with_timezone(&Utc) <= now)
            .unwrap_or(true);
        Ok(AccountSummary {
            active: active_id.as_deref() == Some(id.as_str()),
            id,
            username: row.get(1)?,
            email: row.get(2)?,
            avatar_data_url: row.get(3)?,
            created_at: row.get(4)?,
            updated_at: row.get(5)?,
            last_login_at: row.get(6)?,
            session_status: if expired { "expired" } else { "ready" }.into(),
        })
    })?;
    rows.collect::<Result<Vec<_>, _>>()
        .map_err(AccountError::from)
}

pub fn current_account(path: &Path) -> Result<Option<AccountSummary>, AccountError> {
    let connection = open(path)?;
    let Some(user_id) = active_user_id(&connection)? else {
        return Ok(None);
    };
    drop(connection);
    match switch_account(path, &user_id) {
        Ok(account) => Ok(Some(account)),
        Err(AccountError::SessionExpired) => {
            let connection = open(path)?;
            set_active_user(&connection, None)?;
            Ok(None)
        }
        Err(error) => Err(error),
    }
}

pub fn switch_account(path: &Path, user_id: &str) -> Result<AccountSummary, AccountError> {
    let connection = open(path)?;
    let refresh = keyring_entry(user_id)?
        .get_password()
        .map_err(|_| AccountError::SessionExpired)?;
    let valid: Option<String> = connection
        .query_row(
            "SELECT id FROM local_sessions
             WHERE user_id = ?1 AND refresh_hash = ?2 AND expires_at > ?3
             ORDER BY last_used_at DESC LIMIT 1",
            params![user_id, token_hash(&refresh), Utc::now().to_rfc3339()],
            |row| row.get(0),
        )
        .optional()?;
    let session_id = valid.ok_or(AccountError::SessionExpired)?;
    connection.execute(
        "UPDATE local_sessions SET last_used_at = ?1 WHERE id = ?2",
        params![Utc::now().to_rfc3339(), session_id],
    )?;
    set_active_user(&connection, Some(user_id))?;
    account_by_id(&connection, user_id, true)
}

pub fn logout(path: &Path) -> Result<(), AccountError> {
    let connection = open(path)?;
    set_active_user(&connection, None)
}

pub fn remove_local_account(path: &Path, user_id: &str) -> Result<(), AccountError> {
    let connection = open(path)?;
    connection.execute(
        "DELETE FROM local_sessions WHERE user_id = ?1",
        params![user_id],
    )?;
    let _ = keyring_entry(user_id)?.delete_credential();
    if active_user_id(&connection)?.as_deref() == Some(user_id) {
        set_active_user(&connection, None)?;
    }
    Ok(())
}

pub fn update_profile(
    path: &Path,
    user_id: &str,
    input: ProfileInput,
) -> Result<AccountSummary, AccountError> {
    let email = normalize_email(input.email)?;
    if input
        .avatar_data_url
        .as_ref()
        .is_some_and(|avatar| avatar.len() > 2_800_000)
    {
        return Err(AccountError::Validation("头像文件不能超过 2 MB".into()));
    }
    let connection = open(path)?;
    let result = connection.execute(
        "UPDATE users SET email = ?1, avatar_data_url = ?2, updated_at = ?3 WHERE id = ?4",
        params![
            email,
            input.avatar_data_url,
            Utc::now().to_rfc3339(),
            user_id
        ],
    );
    match result {
        Ok(0) => Err(AccountError::NotFound),
        Ok(_) => account_by_id(&connection, user_id, true),
        Err(error) if error.to_string().contains("UNIQUE") => Err(AccountError::DuplicateEmail),
        Err(error) => Err(AccountError::Database(error)),
    }
}

pub fn change_password(
    path: &Path,
    user_id: &str,
    current_password: &str,
    new_password: &str,
) -> Result<(), AccountError> {
    validate_password(new_password)?;
    let connection = open(path)?;
    let stored: String = connection
        .query_row(
            "SELECT password_hash FROM users WHERE id = ?1",
            params![user_id],
            |row| row.get(0),
        )
        .optional()?
        .ok_or(AccountError::NotFound)?;
    if !verify_password(current_password, &stored)? {
        return Err(AccountError::InvalidCredentials);
    }
    connection.execute(
        "UPDATE users SET password_hash = ?1, updated_at = ?2 WHERE id = ?3",
        params![
            password_hash(new_password)?,
            Utc::now().to_rfc3339(),
            user_id
        ],
    )?;
    Ok(())
}

pub fn reset_password(
    path: &Path,
    username: &str,
    recovery_code: &str,
    new_password: &str,
) -> Result<(), AccountError> {
    validate_password(new_password)?;
    let username = validate_username(username)?;
    let connection = open(path)?;
    let row: Option<(String, String)> = connection
        .query_row(
            "SELECT id, recovery_hash FROM users WHERE username = ?1 COLLATE NOCASE",
            params![username],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .optional()?;
    let (user_id, recovery_hash) = row.ok_or(AccountError::InvalidCredentials)?;
    if !verify_password(recovery_code.trim(), &recovery_hash)? {
        return Err(AccountError::InvalidCredentials);
    }
    connection.execute(
        "UPDATE users SET password_hash = ?1, updated_at = ?2 WHERE id = ?3",
        params![
            password_hash(new_password)?,
            Utc::now().to_rfc3339(),
            user_id
        ],
    )?;
    Ok(())
}

pub fn delete_account(
    path: &Path,
    cache_dir: &Path,
    user_id: &str,
    password: &str,
) -> Result<(), AccountError> {
    let connection = open(path)?;
    let stored: String = connection
        .query_row(
            "SELECT password_hash FROM users WHERE id = ?1",
            params![user_id],
            |row| row.get(0),
        )
        .optional()?
        .ok_or(AccountError::NotFound)?;
    if !verify_password(password, &stored)? {
        return Err(AccountError::InvalidCredentials);
    }
    let mut cache_statement =
        connection.prepare("SELECT file_path FROM tts_cache WHERE user_id = ?1")?;
    let cache_paths = cache_statement
        .query_map(params![user_id], |row| row.get::<_, String>(0))?
        .collect::<Result<Vec<_>, _>>()?;
    drop(cache_statement);
    for path in cache_paths {
        if Path::new(&path).starts_with(cache_dir) {
            let _ = fs::remove_file(path);
        }
    }
    connection.execute("DELETE FROM users WHERE id = ?1", params![user_id])?;
    let _ = keyring_entry(user_id)?.delete_credential();
    if active_user_id(&connection)?.as_deref() == Some(user_id) {
        set_active_user(&connection, None)?;
    }
    Ok(())
}
