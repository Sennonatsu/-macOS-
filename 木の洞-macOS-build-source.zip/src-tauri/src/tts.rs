use base64::{engine::general_purpose::STANDARD, Engine};
use chrono::Utc;
use keyring::Entry;
use reqwest::{header, Client};
use rusqlite::{params, Connection, OptionalExtension};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use std::{fs, path::Path};

const KEYRING_SERVICE: &str = "com.kinodou.desktop";

#[derive(Debug, thiserror::Error)]
pub enum TtsError {
    #[error("{0}")]
    Validation(String),
    #[error("请先为当前 TTS Provider 配置 API Key")]
    MissingKey,
    #[error("TTS 服务请求失败：{0}")]
    Upstream(String),
    #[error("本地 TTS 缓存操作失败")]
    Storage,
    #[error("系统钥匙串不可用：{0}")]
    Keyring(String),
}

impl Serialize for TtsError {
    fn serialize<S>(&self, serializer: S) -> Result<S::Ok, S::Error>
    where
        S: serde::Serializer,
    {
        serializer.serialize_str(&self.to_string())
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct TtsProfile {
    pub provider: String,
    pub voice: String,
    pub language: String,
    pub speed: f64,
    pub pitch: f64,
    pub style: Option<String>,
    pub custom_url: Option<String>,
    #[serde(default)]
    pub has_api_key: bool,
}

impl Default for TtsProfile {
    fn default() -> Self {
        Self {
            provider: "default".into(),
            voice: "female".into(),
            language: "ja".into(),
            speed: 1.0,
            pitch: 1.0,
            style: None,
            custom_url: None,
            has_api_key: false,
        }
    }
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SaveTtsInput {
    pub profile: TtsProfile,
    pub api_key: Option<String>,
}

#[derive(Debug, Deserialize)]
#[serde(rename_all = "camelCase")]
pub struct SynthesizeInput {
    pub user_id: String,
    pub text: String,
    pub language: String,
    pub voice: Option<String>,
    pub speed: Option<f64>,
}

#[derive(Debug, Serialize)]
#[serde(rename_all = "camelCase")]
pub struct TtsAudioResult {
    pub source: String,
    pub data_url: Option<String>,
    pub mime_type: Option<String>,
    pub cache_key: Option<String>,
}

fn connection(path: &Path) -> Result<Connection, TtsError> {
    Connection::open(path).map_err(|_| TtsError::Storage)
}

fn key_entry(user_id: &str, provider: &str) -> Result<Entry, TtsError> {
    Entry::new(KEYRING_SERVICE, &format!("tts-{user_id}-{provider}"))
        .map_err(|error| TtsError::Keyring(error.to_string()))
}

fn validate_profile(profile: &TtsProfile) -> Result<(), TtsError> {
    if ![
        "default",
        "openai",
        "elevenlabs",
        "google",
        "azure",
        "custom",
    ]
    .contains(&profile.provider.as_str())
    {
        return Err(TtsError::Validation("不支持的 TTS Provider".into()));
    }
    if !["ja", "en"].contains(&profile.language.as_str()) {
        return Err(TtsError::Validation("TTS 语言只能为日语或英语".into()));
    }
    if !(0.5..=1.5).contains(&profile.speed) {
        return Err(TtsError::Validation("语速需在 0.5–1.5 之间".into()));
    }
    if profile.provider == "custom"
        && !profile
            .custom_url
            .as_deref()
            .is_some_and(|value| value.starts_with("https://"))
    {
        return Err(TtsError::Validation(
            "自定义 TTS API 必须使用 HTTPS 地址".into(),
        ));
    }
    Ok(())
}

pub fn load_profile(path: &Path, user_id: &str) -> Result<TtsProfile, TtsError> {
    let connection = connection(path)?;
    let mut profile = connection
        .query_row(
            "SELECT provider, voice, language, speed, pitch, style, custom_url
             FROM tts_profiles WHERE user_id = ?1",
            params![user_id],
            |row| {
                Ok(TtsProfile {
                    provider: row.get(0)?,
                    voice: row.get(1)?,
                    language: row.get(2)?,
                    speed: row.get(3)?,
                    pitch: row.get(4)?,
                    style: row.get(5)?,
                    custom_url: row.get(6)?,
                    has_api_key: false,
                })
            },
        )
        .optional()
        .map_err(|_| TtsError::Storage)?
        .unwrap_or_default();
    profile.has_api_key = profile.provider == "default"
        || key_entry(user_id, &profile.provider)
            .and_then(|entry| {
                entry
                    .get_password()
                    .map_err(|error| TtsError::Keyring(error.to_string()))
            })
            .is_ok();
    Ok(profile)
}

pub fn save_profile(
    path: &Path,
    user_id: &str,
    input: SaveTtsInput,
) -> Result<TtsProfile, TtsError> {
    validate_profile(&input.profile)?;
    let connection = connection(path)?;
    connection
        .execute(
            "INSERT INTO tts_profiles(
               user_id, provider, voice, language, speed, pitch, style, custom_url, updated_at
             ) VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9)
             ON CONFLICT(user_id) DO UPDATE SET
               provider = excluded.provider,
               voice = excluded.voice,
               language = excluded.language,
               speed = excluded.speed,
               pitch = excluded.pitch,
               style = excluded.style,
               custom_url = excluded.custom_url,
               updated_at = excluded.updated_at",
            params![
                user_id,
                input.profile.provider,
                input.profile.voice,
                input.profile.language,
                input.profile.speed,
                input.profile.pitch,
                input.profile.style,
                input.profile.custom_url,
                Utc::now().to_rfc3339()
            ],
        )
        .map_err(|_| TtsError::Storage)?;
    if let Some(key) = input.api_key.map(|value| value.trim().to_string()) {
        if !key.is_empty() {
            key_entry(user_id, &input.profile.provider)?
                .set_password(&key)
                .map_err(|error| TtsError::Keyring(error.to_string()))?;
        }
    }
    load_profile(path, user_id)
}

fn cache_key(
    user_id: &str,
    provider: &str,
    language: &str,
    voice: &str,
    speed: f64,
    text: &str,
) -> String {
    format!(
        "{:x}",
        Sha256::digest(
            format!("{user_id}|{provider}|{language}|{voice}|{speed:.2}|{text}").as_bytes()
        )
    )
}

fn xml_escape(value: &str) -> String {
    value
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&apos;")
}

async fn request_audio(
    profile: &TtsProfile,
    api_key: &str,
    text: &str,
    language: &str,
    voice: &str,
    speed: f64,
) -> Result<(Vec<u8>, String), TtsError> {
    let client = Client::builder()
        .https_only(true)
        .build()
        .map_err(|error| TtsError::Upstream(error.to_string()))?;
    let response = match profile.provider.as_str() {
        "openai" => {
            client
                .post("https://api.openai.com/v1/audio/speech")
                .bearer_auth(api_key)
                .json(&serde_json::json!({
                    "model": "gpt-4o-mini-tts",
                    "input": text,
                    "voice": voice,
                    "speed": speed,
                    "response_format": "mp3"
                }))
                .send()
                .await
        }
        "elevenlabs" => {
            client
                .post(format!(
                    "https://api.elevenlabs.io/v1/text-to-speech/{}",
                    voice
                ))
                .header("xi-api-key", api_key)
                .header(header::ACCEPT, "audio/mpeg")
                .json(&serde_json::json!({
                    "text": text,
                    "model_id": "eleven_multilingual_v2",
                    "voice_settings": {
                        "stability": 0.5,
                        "similarity_boost": 0.75,
                        "speed": speed
                    }
                }))
                .send()
                .await
        }
        "google" => {
            client
                .post(format!(
                    "https://texttospeech.googleapis.com/v1/text:synthesize?key={}",
                    api_key
                ))
                .json(&serde_json::json!({
                    "input": { "text": text },
                    "voice": {
                        "languageCode": if language == "en" { "en-US" } else { "ja-JP" },
                        "name": voice
                    },
                    "audioConfig": {
                        "audioEncoding": "MP3",
                        "speakingRate": speed,
                        "pitch": profile.pitch
                    }
                }))
                .send()
                .await
        }
        "azure" => {
            let region = profile
                .custom_url
                .as_deref()
                .filter(|value| !value.is_empty())
                .unwrap_or("eastus");
            let locale = if language == "en" { "en-US" } else { "ja-JP" };
            let rate = format!("{:+.0}%", (speed - 1.0) * 100.0);
            client
                .post(format!(
                    "https://{}.tts.speech.microsoft.com/cognitiveservices/v1",
                    region
                ))
                .header("Ocp-Apim-Subscription-Key", api_key)
                .header("X-Microsoft-OutputFormat", "audio-24khz-48kbitrate-mono-mp3")
                .header(header::CONTENT_TYPE, "application/ssml+xml")
                .body(format!(
                    "<speak version=\"1.0\" xml:lang=\"{locale}\"><voice name=\"{}\"><prosody rate=\"{rate}\">{}</prosody></voice></speak>",
                    xml_escape(voice),
                    xml_escape(text)
                ))
                .send()
                .await
        }
        "custom" => {
            let url = profile
                .custom_url
                .as_deref()
                .ok_or_else(|| TtsError::Validation("缺少自定义 TTS API 地址".into()))?;
            client
                .post(url)
                .bearer_auth(api_key)
                .json(&serde_json::json!({
                    "text": text,
                    "language": language,
                    "voice": voice,
                    "speed": speed,
                    "pitch": profile.pitch,
                    "style": profile.style
                }))
                .send()
                .await
        }
        _ => return Err(TtsError::Validation("该 Provider 使用设备默认配音".into())),
    }
    .map_err(|error| TtsError::Upstream(error.to_string()))?;

    if !response.status().is_success() {
        let status = response.status();
        let message = response.text().await.unwrap_or_default();
        return Err(TtsError::Upstream(format!(
            "{} {}",
            status,
            message.chars().take(180).collect::<String>()
        )));
    }

    if profile.provider == "google" {
        let body: serde_json::Value = response
            .json()
            .await
            .map_err(|error| TtsError::Upstream(error.to_string()))?;
        let encoded = body
            .get("audioContent")
            .and_then(|value| value.as_str())
            .ok_or_else(|| TtsError::Upstream("Google TTS 未返回音频".into()))?;
        let bytes = STANDARD
            .decode(encoded)
            .map_err(|_| TtsError::Upstream("Google TTS 音频格式无效".into()))?;
        return Ok((bytes, "audio/mpeg".into()));
    }

    let mime = response
        .headers()
        .get(header::CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("audio/mpeg")
        .split(';')
        .next()
        .unwrap_or("audio/mpeg")
        .to_string();
    let bytes = response
        .bytes()
        .await
        .map_err(|error| TtsError::Upstream(error.to_string()))?
        .to_vec();
    Ok((bytes, mime))
}

pub async fn synthesize(
    database_path: &Path,
    cache_dir: &Path,
    input: SynthesizeInput,
) -> Result<TtsAudioResult, TtsError> {
    let text = input.text.trim();
    if text.is_empty() || text.chars().count() > 1000 {
        return Err(TtsError::Validation(
            "朗读内容不能为空，且不能超过 1000 个字符".into(),
        ));
    }
    let profile = load_profile(database_path, &input.user_id)?;
    if profile.provider == "default" {
        return Ok(TtsAudioResult {
            source: "browser".into(),
            data_url: None,
            mime_type: None,
            cache_key: None,
        });
    }
    let language = if input.language == "en" { "en" } else { "ja" };
    let voice = input.voice.as_deref().unwrap_or(&profile.voice);
    let speed = input.speed.unwrap_or(profile.speed).clamp(0.5, 1.5);
    let key = cache_key(
        &input.user_id,
        &profile.provider,
        language,
        voice,
        speed,
        text,
    );
    let connection = connection(database_path)?;
    let cached: Option<(String, String)> = connection
        .query_row(
            "SELECT file_path, mime_type FROM tts_cache
             WHERE cache_key = ?1 AND user_id = ?2",
            params![key, input.user_id],
            |row| Ok((row.get(0)?, row.get(1)?)),
        )
        .optional()
        .map_err(|_| TtsError::Storage)?;
    if let Some((path, mime)) = cached {
        if let Ok(bytes) = fs::read(&path) {
            let _ = connection.execute(
                "UPDATE tts_cache SET last_used_at = ?1 WHERE cache_key = ?2",
                params![Utc::now().to_rfc3339(), key],
            );
            return Ok(TtsAudioResult {
                source: "cache".into(),
                data_url: Some(format!("data:{mime};base64,{}", STANDARD.encode(bytes))),
                mime_type: Some(mime),
                cache_key: Some(key),
            });
        }
    }
    let api_key = key_entry(&input.user_id, &profile.provider)?
        .get_password()
        .map_err(|_| TtsError::MissingKey)?;
    let (bytes, mime) = request_audio(&profile, &api_key, text, language, voice, speed).await?;
    fs::create_dir_all(cache_dir).map_err(|_| TtsError::Storage)?;
    let path = cache_dir.join(format!("{key}.audio"));
    fs::write(&path, &bytes).map_err(|_| TtsError::Storage)?;
    let now = Utc::now().to_rfc3339();
    connection
        .execute(
            "INSERT INTO tts_cache(
               cache_key, user_id, provider, language, voice, speed,
               text_hash, mime_type, file_path, created_at, last_used_at
             ) VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?10)
             ON CONFLICT(cache_key) DO UPDATE SET
               file_path = excluded.file_path,
               mime_type = excluded.mime_type,
               last_used_at = excluded.last_used_at",
            params![
                key,
                input.user_id,
                profile.provider,
                language,
                voice,
                speed,
                format!("{:x}", Sha256::digest(text.as_bytes())),
                mime,
                path.to_string_lossy(),
                now
            ],
        )
        .map_err(|_| TtsError::Storage)?;
    Ok(TtsAudioResult {
        source: "provider".into(),
        data_url: Some(format!("data:{mime};base64,{}", STANDARD.encode(bytes))),
        mime_type: Some(mime),
        cache_key: Some(key),
    })
}
